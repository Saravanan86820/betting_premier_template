import React from 'react';

// import InsertAd from ''

import InsertAd from '../pages/components/ad/InsertAd';

import '../index.css';


function Add() {


    return (

        <>
            <div className="match" id="match-add">
                <div className="match-content1">
                    <div className="slidebar-ads">
                        <div className='js-bet-ad-insert'>
                            <InsertAd/>

                        </div>
                    {/* <a href="/blog/bet365-games/" >
                    <img  src="/assets/image/common/bet365-addrun.svg" alt="bet365" width="273"  height="455"  className="slidebar-ads-image" loading="lazy"/>
                    </a> */}
                    
                    </div>
                </div>
            </div>


        </>
    );
}

export default Add;