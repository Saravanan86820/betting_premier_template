import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { useLocation } from "react-router-dom";

// import FeatureMatch from "../../sidebar/FeaturedMatch";
import Topleagues from "../../sidebar/Topleagues";
// import Alleagues from "../../sidebar/Alleagues";
import Add from "../../sidebar/Add";
import RecentBlog from "../../sidebar/RecentBlog";


import Leaguebanner from "../components/football/Leaguebanner";
import Matches from "../components/football/Matches";
// import Leagueinfo from "../../pages/components/Leagueinfo";
import LeagueStanded from "../components/football/LeagueStanded";


// ice hockey
import IceHockeyLeagueList from "../../pages/components/ice-hockey/IceHockeyLeagueList";
import IceHockeyMatches from "../../pages/components/ice-hockey/IceHockeyMatches";
import IceHockeyStanding from "../../pages/components/ice-hockey/IceHockeyStanding";

// baseball code
import BaseballLeagueList from "../components/baseball/BaseballLeague";
import BaseBallMatches from "../../pages/components/baseball/BaseBallMatches";
import BaseballStanding from "../../pages/components/baseball/BaseballStanding";

// baseketball code
import BasketballLeague from "../components/basketball/BasketballLeague";
import BasketBallMatches from "../../pages/components/basketball/BasketBallMatches";
import BasketballStanding from "../../pages/components/basketball/BasketballStanding";

// volleyball code
import VolleyBallLeague from "../components/volleyball/VolleyBallLeague";
import VolleyBallMatches from "../../pages/components/volleyball/VolleyBallMatches";
import VolleyballStanding from "../../pages/components/volleyball/VolleyballStanding";


// handball code
import HandBallLeague from "../components/handball/HandBallLeague";
import HandBallMatches from "../../pages/components/handball/HandBallMatches";
// rugby code
import RugbyLeague from "../components/rugby/RugbyLeague";
import RugbyMatches from "../../pages/components/rugby/RugbyMatches";
import NewTopLeagues from '../../sidebar/NewTopLeagues';
import RugbyStanding from '../components/rugby/RugbyStandings';
import HandBallStanding from '../components/handball/HandBallStandings';


function Leaguelist() {

  const [selectedSeason, setSelectedSeason] = useState(null);
  const [activeTab, setActiveTab] = useState("matches");
  const [isMobile, setIsMobile] = useState(window.innerWidth <= 1200);
  const location = useLocation();
  // const slug = location.pathname.split("/").find((segment) => segment);

  const slug = location.pathname.split("/")[1];

  useEffect(() => {
    const handleResize = () => setIsMobile(window.innerWidth <= 1200);
    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, []);

  return (
    <>
      <div className="mvp-main-box-cont" id="more-blog-section">

        <div className="main-box-container">
          <div className="container-league-page">

            <div className="column-league large">

              {slug === "football" &&
                <>
                <Leaguebanner setSelectedSeason={setSelectedSeason} selectedSeason={selectedSeason}/>

                {/* --- Desktop Layout --- */}
                {!isMobile && (
                  <div className="container-league-detail">
                    <div className="column-league-detail small league_cont">
                      {selectedSeason && <Matches selectedSeason={selectedSeason} slug={slug} />}
                    </div>
                    <div className="column-league-detail large league_cont">
                      {selectedSeason && <LeagueStanded selectedSeason={selectedSeason} />}
                    </div>
                  </div>
                )}

                {/* --- Mobile Layout (Tab View) --- */}
                {isMobile && (
                  <div className="league-tabs">
                    <div className="league-tabs__header">
                
                
                      <div className="tab_buttons">
                        <button

                        className={`tab_button ${activeTab === "matches" ? "active" : ""}`}
                        onClick={() => setActiveTab("matches")}
                        >
                        
                          <span className="tab--name"> Matches  </span>
                        </button>
                        <button

                          className={`tab_button ${activeTab === "standings" ? "active" : ""}`}
                        onClick={() => setActiveTab("standings")}
                        >
                        
                          <span className="tab--name"> Standings  </span>
                        </button>

                    </div>


                    </div>
                
                    <div className="league-tabs__content">
                      {activeTab === "matches" && selectedSeason && (
                        <Matches selectedSeason={selectedSeason} slug={slug} />
                      )}
                      {activeTab === "standings" && selectedSeason && (
                        <LeagueStanded selectedSeason={selectedSeason} />
                      )}
                    </div>
                  </div>
                )}
                </>

              }

              {slug === "ice-hockey" &&
                <>
                  <IceHockeyLeagueList setSelectedSeason={setSelectedSeason} selectedSeason={selectedSeason} />

                  {!isMobile && (
                    <div className='container-league-detail'>
                    <div className='column-league-detail small  league_cont'>
                      {selectedSeason && <IceHockeyMatches selectedSeason={selectedSeason} slug={slug} />}
                    </div>
                    <div className='column-league-detail large  league_cont'>
                      {selectedSeason && <IceHockeyStanding selectedSeason={selectedSeason} />}
                  </div>
                  </div>

                  )}

                  {isMobile && (
                  <div className="league-tabs">
                    <div className="league-tabs__header">
                
                
                      <div className="tab_buttons">
                        <button

                        className={`tab_button ${activeTab === "matches" ? "active" : ""}`}
                        onClick={() => setActiveTab("matches")}
                        >
                        
                          <span className="tab--name"> Matches  </span>
                        </button>
                        <button

                          className={`tab_button ${activeTab === "standings" ? "active" : ""}`}
                        onClick={() => setActiveTab("standings")}
                        >
                        
                          <span className="tab--name"> Standings  </span>
                        </button>

                    </div>


                    </div>
                
                    <div className="league-tabs__content">
                      {activeTab === "matches" && selectedSeason && (
                        <IceHockeyMatches selectedSeason={selectedSeason} slug={slug} />
                      )}
                      {activeTab === "standings" && selectedSeason && (
                        <IceHockeyStanding selectedSeason={selectedSeason} />
                      )}
                    </div>
                  </div>
                )}



                  
                </>
              }
              {slug === "baseball" &&
                <>
                  <BaseballLeagueList setSelectedSeason={setSelectedSeason} selectedSeason={selectedSeason} />

                  {!isMobile && (
                    <div className='container-league-detail'>
                    <div className='column-league-detail small  league_cont'>
                      {selectedSeason && <BaseBallMatches selectedSeason={selectedSeason} slug={slug} />}
                    </div>
                    <div className='column-league-detail large  league_cont'>
                      {selectedSeason && <BaseballStanding selectedSeason={selectedSeason} />}
                    </div>
                  </div>
                  )}

                  {isMobile && (
                  <div className="league-tabs">
                    <div className="league-tabs__header">
                
                
                      <div className="tab_buttons">
                        <button

                        className={`tab_button ${activeTab === "matches" ? "active" : ""}`}
                        onClick={() => setActiveTab("matches")}
                        >
                        
                          <span className="tab--name"> Matches  </span>
                        </button>
                        <button

                          className={`tab_button ${activeTab === "standings" ? "active" : ""}`}
                        onClick={() => setActiveTab("standings")}
                        >
                        
                          <span className="tab--name"> Standings  </span>
                        </button>

                    </div>


                    </div>
                
                    <div className="league-tabs__content">
                      {activeTab === "matches" && selectedSeason && (
                        <BaseBallMatches selectedSeason={selectedSeason} slug={slug} />
                      )}
                      {activeTab === "standings" && selectedSeason && (
                        <BaseballStanding selectedSeason={selectedSeason} />
                      )}
                    </div>
                  </div>
                )}
                      
                </>
              }
              {slug === "basketball" &&
                <>
                  <BasketballLeague setSelectedSeason={setSelectedSeason} selectedSeason={selectedSeason} />


                  {!isMobile && (

                    <div className='container-league-detail'>
                    <div className='column-league-detail small  league_cont'>
                      {selectedSeason && <BasketBallMatches selectedSeason={selectedSeason} slug={slug} />}
                    </div>
                    <div className='column-league-detail large  league_cont'>
                      {selectedSeason && <BasketballStanding selectedSeason={selectedSeason} />}

                    </div>
                    </div>
                  )}

                  {isMobile && (
                  <div className="league-tabs">
                    <div className="league-tabs__header">
                
                
                      <div className="tab_buttons">
                        <button

                        className={`tab_button ${activeTab === "matches" ? "active" : ""}`}
                        onClick={() => setActiveTab("matches")}
                        >
                        
                          <span className="tab--name"> Matches  </span>
                        </button>
                        <button

                          className={`tab_button ${activeTab === "standings" ? "active" : ""}`}
                        onClick={() => setActiveTab("standings")}
                        >
                        
                          <span className="tab--name"> Standings  </span>
                        </button>

                    </div>


                    </div>
                
                    <div className="league-tabs__content">
                      {activeTab === "matches" && selectedSeason && (
                        <BasketBallMatches selectedSeason={selectedSeason} slug={slug} />
                      )}
                      {activeTab === "standings" && selectedSeason && (
                        <BasketballStanding selectedSeason={selectedSeason} />
                      )}
                    </div>
                  </div>
                )}
                  

                </>
              }
              {
                slug === "rugby" &&
                <>
                  <RugbyLeague setSelectedSeason={setSelectedSeason} selectedSeason={selectedSeason} />

                  {!isMobile && (
                    <div className='container-league-detail'>
                    <div className='column-league-detail small  league_cont'>
                      {selectedSeason && <RugbyMatches selectedSeason={selectedSeason} slug={slug} />}
                    </div>
                    <div className='column-league-detail large  league_cont'>
                      {selectedSeason && <RugbyStanding selectedSeason={selectedSeason} />}

                    </div>
                    </div>
                  )}

                  {isMobile && (
                  <div className="league-tabs">
                    <div className="league-tabs__header">
                
                
                      <div className="tab_buttons">
                        <button

                        className={`tab_button ${activeTab === "matches" ? "active" : ""}`}
                        onClick={() => setActiveTab("matches")}
                        >
                        
                          <span className="tab--name"> Matches  </span>
                        </button>
                        <button

                          className={`tab_button ${activeTab === "standings" ? "active" : ""}`}
                        onClick={() => setActiveTab("standings")}
                        >
                        
                          <span className="tab--name"> Standings  </span>
                        </button>

                    </div>


                    </div>
                
                    <div className="league-tabs__content">
                      {activeTab === "matches" && selectedSeason && (
                        <RugbyMatches selectedSeason={selectedSeason} slug={slug} />
                      )}
                      {activeTab === "standings" && selectedSeason && (
                        <RugbyStanding selectedSeason={selectedSeason} />
                      )}
                    </div>
                  </div>
                )}
                  
                </>
              }
              {
                slug === "volleyball" &&
                <>
                  <VolleyBallLeague setSelectedSeason={setSelectedSeason} selectedSeason={selectedSeason} />

                  {!isMobile && (
                    
                    <div className='container-league-detail'>
                    <div className='column-league-detail small  league_cont'>
                      {selectedSeason && <VolleyBallMatches selectedSeason={selectedSeason} slug={slug} />}
                    </div>
                    <div className='column-league-detail large  league_cont'>
                      {selectedSeason && <VolleyballStanding selectedSeason={selectedSeason} />}

                    </div>
                    </div>
                  )}

                  {isMobile && (
                  <div className="league-tabs">
                    <div className="league-tabs__header">
                
                
                      <div className="tab_buttons">
                        <button

                        className={`tab_button ${activeTab === "matches" ? "active" : ""}`}
                        onClick={() => setActiveTab("matches")}
                        >
                        
                          <span className="tab--name"> Matches  </span>
                        </button>
                        <button

                          className={`tab_button ${activeTab === "standings" ? "active" : ""}`}
                        onClick={() => setActiveTab("standings")}
                        >
                        
                          <span className="tab--name"> Standings  </span>
                        </button>

                    </div>


                    </div>
                
                    <div className="league-tabs__content">
                      {activeTab === "matches" && selectedSeason && (
                        <VolleyBallMatches selectedSeason={selectedSeason} slug={slug} />
                      )}
                      {activeTab === "standings" && selectedSeason && (
                        <VolleyballStanding selectedSeason={selectedSeason} />
                      )}
                    </div>
                  </div>
                )}
                  
                </>
              }
              {
                slug === "handball" &&
                <>
                  <HandBallLeague setSelectedSeason={setSelectedSeason} selectedSeason={selectedSeason} />

                  {!isMobile && (
                    
                    <div className='container-league-detail'>
                    <div className='column-league-detail small  league_cont'>
                      {selectedSeason && <HandBallMatches selectedSeason={selectedSeason} slug={slug} />}
                    </div>
                    <div className='column-league-detail large  league_cont'>
                      {selectedSeason && <HandBallStanding selectedSeason={selectedSeason} />}

                    </div>
                    </div>
                  )}

                  {isMobile && (
                  <div className="league-tabs">
                    <div className="league-tabs__header">
                
                
                      <div className="tab_buttons">
                        <button

                        className={`tab_button ${activeTab === "matches" ? "active" : ""}`}
                        onClick={() => setActiveTab("matches")}
                        >
                        
                          <span className="tab--name"> Matches  </span>
                        </button>
                        <button

                          className={`tab_button ${activeTab === "standings" ? "active" : ""}`}
                        onClick={() => setActiveTab("standings")}
                        >
                        
                          <span className="tab--name"> Standings  </span>
                        </button>

                    </div>


                    </div>
                
                    <div className="league-tabs__content">
                      {activeTab === "matches" && selectedSeason && (
                        <HandBallMatches selectedSeason={selectedSeason} slug={slug} />
                      )}
                      {activeTab === "standings" && selectedSeason && (
                        <HandBallStanding selectedSeason={selectedSeason} />
                      )}
                    </div>
                  </div>
                )}



                </>
              }
              



            </div>

            <div className="column-league small">

              <div className="container-slide">
                {/* <FeatureMatch /> */}
                <RecentBlog />
                <Add />
              </div>
            </div>
          </div>
        </div>

      </div>
    </>
  );
}

export default Leaguelist;