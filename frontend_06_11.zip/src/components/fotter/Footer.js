import React from "react";
import "./Footer.css"; // optional if you have styles

const Footer = () => {
return ( 
<footer className="footer">
    <div className="footer__top">
        <img src="/assets/image/nav/logo.svg" alt="Betting Premier Logo" className="footer__logo" /> 
        <nav className="footer__nav">
            <a href="#">Latest</a>
            <a href="#">Football</a> 
            <a href="#">Ice Hockey</a> 
            <a href="#">Baseball</a> 
            <a href="#">BasketBall</a> 
            <a href="#">VolleyBall</a> 
        </nav>
        <p className="footer__copyright">
            Copyright © {new Date().getFullYear()} BettingPremier
        </p>
    </div>

    <div className="footer__bottom">
    <p>
      18+ Only. Please gamble responsibly!{" "}
      <strong>
        BeGambleAware<span style={{ fontSize: "0.6em" }}>.org</span>
      </strong>{" "}
      &nbsp; 18+ | Erlaubt (White-list) | Suchtrisiken | Hilfe unter buwei.de
      (ENG: Allowed (white list) | Risk of addiction | Help at buwei.de.)
    </p>
  </div>
</footer>


);
};

export default Footer;
