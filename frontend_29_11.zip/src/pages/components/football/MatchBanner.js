import React, { useEffect, useState } from "react";
// import './MatchBanner.css';

import '../Components.css';

import { Helmet } from 'react-helmet';
// import { useParams } from 'react-router-dom';
import LocalTime from "../../../utility/LocalTime";
const HtmlToReactParser = require('html-to-react').Parser;
import { Link, useParams, useLocation } from 'react-router-dom';

import MatchTab from "./MatchTab";
import Oddsdata from "./Oddsdata";

import SkeletonMatchPage from "../../loader/SkeletonMatchPage";
import useSportsList from "../../../components/content/useSportsList";

function MatchBanner() {
  const { id } = useParams();
    const location1 = useLocation();
  const slug = location1.pathname.split("/")[1];
  const [gameData, setGameMatch] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const gameAPI = `/api/sports/football/game/${id}`;

  useEffect(() => {
    fetch(gameAPI, { method: 'POST' })
      .then(response => response.json())
      .then(json => {

        //console.log('Fetched match data:', json);
        if (json['status'] !== 'true') {
          return;
        }

        if (json && json['data']) {
          setGameMatch(json['data']); // Store the entire game data
        } else {
          setError('Game not found');
        }
        setLoading(false);
      })

      .catch(err => {
        console.error('Error fetching match season:', err);
        setLoading(false);
      });
  }, [id]);

  // validate response
  if (loading)
    return  <SkeletonMatchPage />;
  if (error)
    return <div>{error}</div>;
  if (!gameData)
    return <div>No game data available.</div>;

  const resultHtml = result(gameData['full_status'], gameData['result'], gameData['time']);
  const homeHtml = gameData['home'] ? team(gameData['home']) : '';
  const awayHtml = gameData['away'] ? team(gameData['away']) : '';


  // const resultHtml1 = location(gameData['halftime'], gameData['fulltime'], gameData['extratime'] , gameData['goals']);

  //console.log(homeTeam.icon);


  const resultData = JSON.parse(gameData.result);

  const goaltimehome = resultData.goals && resultData.goals.home !== null ? resultData.goals.home : "";
  const goaltimeaway = resultData.goals && resultData.goals.away !== null ? resultData.goals.away : "";
  const fulltimehome = resultData.fulltime && resultData.fulltime.home !== null ? resultData.fulltime.home : "";
  const fulltimeaway = resultData.fulltime && resultData.fulltime.away !== null ? resultData.fulltime.away : "";
  const halftimehome = resultData.halftime && resultData.halftime.home !== null ? resultData.halftime.home : "";
  const halftimeaway = resultData.halftime && resultData.halftime.away !== null ? resultData.halftime.away : "";
  const extratimehome = resultData.extratime && resultData.extratime.home !== null ? resultData.extratime.home : "";
  const extratimeaway = resultData.extratime && resultData.extratime.away !== null ? resultData.extratime.away : "";
  const penaltyhome = resultData.penalty && resultData.penalty.home !== null ? resultData.penalty.home : "";
  const penaltyaway = resultData.penalty && resultData.penalty.away !== null ? resultData.penalty.away : "";


  const location = JSON.parse(gameData.location);
  const locationcity = location.city && location.city !== null ? location.city : "-";
  const locationname = location.name && location.name !== null ? location.name : "-";

  const moreinfo = JSON.parse(gameData.more_info);
  const referee = moreinfo.referee && moreinfo.referee !== null ? moreinfo.referee : "-";

  const hometime = gameData.time;
  const utctime = LocalTime(hometime);
  // console.log("resultData", utctime);
  let defaultImage = '/bet-assets/site/image/default-football.svg';

  const homeTeamIcon = gameData.home ? gameData.home.icon : defaultImage;
  const awayTeamIcon = gameData.away ? gameData.away.icon : defaultImage;

  const homeProvd_id = gameData.home ? gameData.home.provd_id : '';
  const awayProvd_id = gameData.away ? gameData.away.provd_id : '';

  const homeTeam = gameData.home || {};
  const awayTeam = gameData.away || {};


  const league = gameData.league || {};
  const leagueName = league.display_name;
  const leagueLink = `/football/${league.name}/${league.id}`;
  

  // location
  const venueID = gameData.venue_id ? gameData.venue_id : null;


  const bgimage = homeTeam.icon ? homeTeam.icon : awayTeam.icon;

  const status = gameData.status;
  //  console.log("status", status);

  const homeName = homeTeam.display_name;
  const awayName = awayTeam.display_name;
 

 

  return (
    <>
      <Helmet>
        <title>{`${gameData.name} Game Summary`}</title>
        <meta name="description" content={`Catch up on the ${gameData.name} result, including score, summary, and post-match analysis. Hear from the coaches, players, and more.`} />
      </Helmet>
      
      <div className="game-container" key={gameData['id']} id="game-banner-top">
        <div className="breadcrumb">
          <Link to={`/${slug}`} className="breadcrumb__link">
            {useSportsList(slug)}
          </Link>
          <span className="breadcrumb__separator">{">"}</span>
          <Link to={leagueLink} className="breadcrumb__link">
            {leagueName}
          </Link>
          <span className="breadcrumb__separator">{">"}</span>
          <h1 className="breadcrumb__current">{gameData.name}</h1>
        </div>


        <div className="league-main-container bg-image-color">
          {/* <div className="league-main-bg" style={{ backgroundImage: `url(${bgimage})` }}></div> */}
          <div className="Next-match-container" >
            <div className="Next-match-section-one"></div>
            <div className="Next-match-section-two">
              {homeHtml}
              {resultHtml}
              {awayHtml}
            </div>
            <div className="Next-match-section-one">
              <div className="match-banner__details">
  <div className="match-banner__detail-item">
    <img src="/bet-assets/site/image/event.png" alt="Date" className="match-banner__detail-icon" />
    <span>{utctime.date}</span>/<span>{utctime.time}</span>
    
    
  </div>


  <div className="match-banner__detail-item">
    <Link to={leagueLink} className="detail-items">
      <img src="/bet-assets/site/image/trophy.png" alt="League" className="match-banner__detail-icon" />
      <span>{leagueName}</span>
    </Link>
    
  </div>

  <div className="match-banner__detail-item">
    {venueID ? (
      <Link to={`/football/venue/${venueID}`} className="detail-items">
      <img src="/bet-assets/site/image/venue.png" alt="Venue" className="match-banner__detail-icon" />
      <span>{locationname}</span>
      </Link>
    ) : (
      <div className="detail-items">
      <img src="/bet-assets/site/image/venue.png" alt="Venue" className="match-banner__detail-icon" />
      <span>{locationname}</span>
      </div>
    )}
  </div>
</div>
            </div>
          </div>
        </div>

        <div className="league-main-container-two">
        <div className='container-match-detail'>


          <div className='column-match-detail small'>

            <div className="referee-card">
                <div className="referee-card__icon">
                  <img src="/bet-assets/site/image/referee.png" alt="referee_icon" />
                 </div>
                <div className="referee-card__info">
                      <div className="referee-card__role">Referee</div>
                      <div className="referee-card__name">{referee}</div>
                </div>
            </div>

            <div className="cards-section__card">
  <div className="cards-section__card-header">
    <img src="/bet-assets/site/image/goal_status.png" alt="Goal_status" />
    <div className="cards-section__card-title">Goal Stats</div>
  </div>

  <div className="cards-section__divider"></div>

  <div className="cards-section__card-content">
    <div className="cards-section__card-item">
      <div className="cards-section__card-label">
        <img src="/bet-assets/site/image/goal.png" alt="Goals" />
        <span>Goals</span>
      </div>
      <span className="cards-section__card-value"><span> {goaltimehome} </span> -  <span> {goaltimeaway} </span></span>
    </div>

    <div className="cards-section__card-item">
      <div className="cards-section__card-label">
        <img src="/bet-assets/site/image/halftime.png" alt="Halftime" />
        <span>Halftime</span>
      </div>
      <span className="cards-section__card-value"><span> {halftimehome} </span> -  <span> {halftimeaway} </span></span>
    </div>

    <div className="cards-section__card-item">
      <div className="cards-section__card-label">
        <img src="/bet-assets/site/image/fulltime.png" alt="Fulltime" />
        <span>Fulltime</span>
      </div>
      <span className="cards-section__card-value"> <span> {fulltimehome} </span> -  <span>  {fulltimeaway} </span></span>
    </div>

    <div className="cards-section__card-item">
      <div className="cards-section__card-label">
        <img src="/bet-assets/site/image/extratime.png" alt="Extratime" style={{width:27,height:28}}/>
        <span>Extratime</span>
      </div>
      <span className="cards-section__card-value"><span>  {extratimehome}  </span> -  <span>  {extratimeaway}  </span>  </span>
    </div>

    <div className="cards-section__card-item">
      <div className="cards-section__card-label">
        <img src="/bet-assets/site/image/penalty.png" alt="Penalty Icon" style={{width:28,height:35}}/>
        <span>Penalty</span>
      </div>
      <span className="cards-section__card-value"> <span>  {penaltyhome} </span> -  <span>   {penaltyaway}  </span></span>
    </div>
  </div>
</div>

          </div>


          <div className='column-match-detail large'>
              <MatchTab homeTeamIcon={homeTeamIcon} awayTeamIcon={awayTeamIcon} id={id} homeProvd_id={homeProvd_id} awayProvd_id={awayProvd_id} homeName={homeName} awayName={awayName} />
              <Oddsdata id={id} status={status} />   
          </div>
        </div>




          

        </div>
      </div>

      

      {/* <Lineups  homeTeamIcon={homeTeamIcon} id={id} awayTeamIcon={awayTeamIcon}/> */}

    </>
  );

  /**
   * generate result html
   * @param {Object} fullStatus 
   * @param {Object} result 
   *  @param {string|number} time 
   * @returns {JSX.Element} 
   */
  function result(fullStatus, result, time) {
    fullStatus = JSON.parse(fullStatus);
    result = JSON.parse(result);
    time = LocalTime(time);

    let scoreHtml = '';

    let penaltyHome = '';
    let penaltyAway = '';

    if (result['penalty']['home'] !== null && result['penalty']['away'] !== null) {
      penaltyHome = `(${result['penalty']['home']})`;
      penaltyAway = `(${result['penalty']['away']})`;
    }
    if (result['goals'] && result['goals']['home'] !== null && result['goals']['away'] !== null) {
      scoreHtml = `${result['goals']['home']} ${penaltyHome} <span class="livedata-score-arrow">-</span> ${result['goals']['away']} ${penaltyAway}`;
    } else {
      if (result['halftime']['home'] !== null && result['halftime']['away'] !== null)
        scoreHtml = `${result['halftime']['home']} <span class="livedata-score-arrow">-</span> ${result['halftime']['away']}`;
      if (result['fulltime']['home'] !== null && result['fulltime']['away'] !== null)
        scoreHtml = `${result['fulltime']['home']}  ${penaltyHome} <span class="livedata-score-arrow">-</span> ${result['fulltime']['away']} ${penaltyAway}`;
      if (result['extratime']['home'] !== null && result['extratime']['away'] !== null)
        scoreHtml = `${result['extratime']['home']} ${penaltyHome} <span class="livedata-score-arrow">-</span> ${result['extratime']['away']} ${penaltyAway}`;
    }


    return (
      <div className="next-match-item">
        <h2 className="livedata-score">
          {new HtmlToReactParser().parse(scoreHtml)}
        </h2>
        <p className="matchscore">{fullStatus['long']}</p>
        
      </div>
    );
  }

  /**
   * generate team html
   * @param {Object} data 
   * @returns {JSX.Element} 
   */
  function team(data) {
    return (
      <div className="next-match-item">
        <div className="next-match-title">
          <div className="match-image">
            <img src={data['icon'] ? data['icon'] : defaultImage} className="small-images" alt={data['name']} width="70" height="70" onError={(e) => { e.target.src = defaultImage; }} loading="lazy" />
          </div>
          <h3 className="match-title">{data['display_name']}</h3>
        </div>
      </div>
    );
  }
}

export default MatchBanner;