import React from "react";
import '../../index.css';
import { Helmet } from 'react-helmet';
// import FeatureMatch from "../../sidebar/FeaturedMatch";
import Topleagues from "../../sidebar/Topleagues";
import Alleagues from "../../sidebar/Alleagues";
import Add from "../../sidebar/Add";
// import Scorematch from "../../pages/home/Scorematch";
// import Scorematch, { ScorematchB, ScorematchC, ScorematchD } from "../../pages/home/Scorematch";

import ScoreLopp from "../../pages/home/ScoreLopp";

import { useParams, Link } from 'react-router-dom';
import { useLocation } from "react-router-dom";


function Football() {

  const location = useLocation();
  const slug = location.pathname.split("/")[1];

  return (
    <>

      <Helmet>
        <title>Football News, Fixtures, Scores & Updates</title>
        <meta
          name="description" content=" Your one-stop destination for football news, fixtures, Standings, scores, and updates. Get the latest from the world of football, all in one place."
        />
      </Helmet>
      <div className="mvp-main-box-cont">
        <div className="container-scorelist container-betting-tools">
          <div className="container-score">

            <div className="column-score large">
              <div className="football-page-container" id="football-page">
                {/* <Scorematch />
                <ScorematchB />
                <ScorematchC />
                <ScorematchD /> */}

                <ScoreLopp />

                {/* {slug === "football" && <p>Welcome to the Football Page!</p>}
                {slug === "basketball" && <p>Welcome to the Basketball Page!</p>} */}
              </div>
            </div>

            <div className="column-score small">

              <div className="container-slide">

                {/* <FeatureMatch /> */}
                <Topleagues />
                <Add />
                <Alleagues />

              </div>

            </div>
          </div>
        </div>
      </div>
    </>
  );
}

export default Football;