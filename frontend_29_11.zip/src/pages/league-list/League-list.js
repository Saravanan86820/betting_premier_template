import React, { useState, useEffect } from "react";
import { useLocation } from "react-router-dom";

import Add from "../../sidebar/Add";
import RecentBlog from "../../post/blog/RecentBlog";

import LeagueHeader from "./LeagueHeader";
import LeagueStand from "./LeagueStand";
import LeagueMatches from "./LeagueMatches";

function LeagueList() {
  const [selectedSeason, setSelectedSeason] = useState(null);
  const [activeTab, setActiveTab] = useState("matches");
  const [isMobile, setIsMobile] = useState(window.innerWidth <= 1200);

  const location = useLocation();
  const slug = location.pathname.split("/")[1];

  // Auto resize listener
  useEffect(() => {
    const handleResize = () => setIsMobile(window.innerWidth <= 1200);
    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, []);


  return (
    <div className="mvp-main-box-cont" id="more-blog-section">
      <div className="main-box-container">
        <div className="container-league-page">
          {/* LEFT COLUMN */}
          <div className="column-league large">
            <LeagueHeader
              setSelectedSeason={setSelectedSeason}
              selectedSeason={selectedSeason}
            />

            {/* DESKTOP VIEW */}
            {!isMobile && (
              <div className="container-league-detail">
                <div className="column-league-detail small league_cont">
                  {selectedSeason && (
                    <LeagueMatches selectedSeason={selectedSeason} slug={slug} />
                  )}
                </div>

                <div className="column-league-detail large league_cont">
                  {selectedSeason && (
                    // <div> league</div>
                    <LeagueStand selectedSeason={selectedSeason} slug={slug} />
                  )}
                </div>
              </div>
            )}

            {/* MOBILE VIEW (TABS) */}
            {isMobile && (
              <div className="league-tabs">
                <div className="league-tabs__header">
                  <div className="tab_buttons">
                    {/* MATCH TAB */}
                    <button
                      className={`tab_button ${activeTab === "matches" ? "active" : ""
                        }`}
                      onClick={() => setActiveTab("matches")}
                    >
                      <img
                        src={`/bet-assets/site/image/games/${slug}.png`}
                        alt={slug}
                        width="20"
                        height="20"
                        className="league-imageflex"
                        loading="lazy"
                      />
                      <span className="tab--name">Game</span>
                    </button>

                    {/* STANDINGS TAB */}
                    <button
                      className={`tab_button ${activeTab === "standings" ? "active" : ""
                        }`}
                      onClick={() => setActiveTab("standings")}
                    >
                      <img
                        src="/bet-assets/site/image/trophy1.png"
                        alt="Standings"
                        width="25"
                        height="25"
                        className="league-imageflex"
                        loading="lazy"
                      />
                      <span className="tab--name">Standings</span>
                    </button>
                  </div>
                </div>

                <div className="league-tabs__content">
                  {activeTab === "matches" && selectedSeason && (
                    <LeagueMatches selectedSeason={selectedSeason} slug={slug} />
                  )}

                  {activeTab === "standings" && selectedSeason && (
                    <LeagueStand selectedSeason={selectedSeason} slug={slug} />
                  )}
                </div>
              </div>
            )}
          </div>

          {/* RIGHT COLUMN */}
          <div className="column-league small">
            <div className="container-slide">
              <Add />
              <RecentBlog />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default LeagueList;
