import React, { useEffect, useState, useRef } from "react";
import { useParams, Link } from 'react-router-dom';
import '../components/Components.css';
import LocalTime from "../../utility/LocalTime";
import IndividualMatch from "./IndividualMatch";
import SkeletonLeagueGame from "../loader/SkeletonLeagueGame";

function LeagueMatches({ selectedSeason, slug }) {
  const errorMessage = 'Data not available right now';
  let { id: matchId } = useParams();
  let [matches, setMatches] = useState([]);
  let [isError, setIsError] = useState(false);
  let [error, setError] = useState(null);
  let [fullMatch, setFullMatch] = useState(null);
  let [loading, setLoading] = useState(false);


  useEffect(() => {
    if (!selectedSeason) return;

    // Clear or reset logic before fetching new data
    setMatches([]);
    setFullMatch(null); // Reset the match details
    setIsError(false);
    setError(null);
    setLoading(true); // Set loading state

    const gameAPI = `/api/sports/${slug}/season/${selectedSeason['id']}/game`;

    // console.log('Current gameseason:', gameAPI);

    setLoading(true);

    fetch(gameAPI, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ type: 'recent' }) })
      .then(response => response.json())
      .then(respData => {

        // console.log("respData :",respData);

        if (!respData['status'] || respData['status'] !== 'true' || respData['data'].length === 0) {
          console.error('Somthing wrong with the API response', respData);
          setIsError(true);
          return;
        }

        const currentTimeUTC = Math.floor(new Date().getTime() / 1000);
        // console.log(currentTimeUTC);
        let selectedMatches = [];
        let scheduleData = respData['data'];
        let lastmatches = scheduleData
          .filter(game => game['time'] < currentTimeUTC)
          .sort((a, b) => b.time - a.time)
          .slice(0, 5);

        // console.log("lastmatches",lastmatches);

        // upcoming matches
        selectedMatches = scheduleData
          .filter(game => game['time'] > currentTimeUTC)
          .sort((a, b) => a.time - b.time)
          .slice(0, 10);

        // console.log(selectedMatches);
        if (selectedMatches.length > 0)
          selectedMatches = [...selectedMatches, ...lastmatches];
        else
          selectedMatches = selectedMatches
            .concat(scheduleData
              .filter(game => game['time'] < currentTimeUTC)
              .sort((a, b) => b['time'] - a['time'])
              .slice(0, 10 - selectedMatches.length));
        // console.log("selectedMatches",selectedMatches);
        setMatches(selectedMatches);
        setLoading(false);
      })

      .catch(error => {
        setIsError(true);
        console.error('Error fetching match data:', error);
        setLoading(false);
      });
  }, [selectedSeason]);

  useEffect(() => {
    if (matches.length > 0) {
      matches.forEach(match => fetchGameDetails(match.id));
    }
  }, [matches]);

  if (error) {
    return <div>Error: {error}</div>;
  }

  return (
    <div className="league-main-container">
      <div className="league-main-row">
        <div className="league-center-title">
          <div className="imageflex">
            <div className="league-heading-sub">
              <img src={`/bet-assets/site/image/games/${slug}.png`} alt="League" width="20" height="20" className="league-imageflex" loading="lazy" />
              <h4>Game</h4>
            </div>
            <div className="league-heading-divider"></div>
          </div>
        </div>

        <div className="league-match-data-single">
          {loading && <SkeletonLeagueGame />}
          {isError && <div className="error-message">{errorMessage}</div>}

          {fullMatch && Object.keys(fullMatch).length > 0 ? (
            Object.keys(fullMatch).map((matchId) => (
              
              <IndividualMatch
                key={matchId}
                match={fullMatch[matchId]}
                slug={slug}
              />
            ))
          ) : (
            // <SkeletonLeagueGame />
            <div className="error-message">No data available</div>
          )}

          {!isError && moreBtn()}
        </div>
      </div>
    </div >
  );


  /**
   * 
   * @param {*} matchId 
   */
  function fetchGameDetails(matchId) {
    const LeagueGame = `/api/sports/${slug}/game/${matchId}`;

    // console.log('LeagueGame games:', LeagueGame);

    fetch(LeagueGame, { method: 'POST' })
      .then(response => response.json())
      .then(json => {
        if (json && json.data) {
          //  console.log("Match ID:", matchId);
          // console.log("Match Data:", json.data);
          setFullMatch(prevState => ({
            ...prevState,
            [matchId]: json.data,
          }));
        } else {
          const errorMessage = `Game data not found for match ${matchId}`;
          console.error(errorMessage); // Log error to console
          // setError(errorMessage);
        }
      })
      .catch(error => {
        const errorMessage = `Error fetching game data for match ${matchId}`;
        console.error(errorMessage, error); // Log error details to console
        // setError(errorMessage);
      });
  }


  /**
   * more button
   * @returns {JSX.Element}
   */
  function moreBtn() {
    return (
      <div className="more-match">
        <Link to={`/${slug}/matches/${selectedSeason['id']}`} className="game-button">
          More Games
        </Link>
      </div>
    );
  }
}


export default LeagueMatches;
