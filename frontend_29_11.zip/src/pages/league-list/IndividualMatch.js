import React from "react";
import { Link } from "react-router-dom";
import LocalTime from "../../utility/LocalTime";

export default function IndividualMatch({ match, slug }) {
    const defaultImage = "/bet-assets/site/image/defaulticon.svg";
    // console.log('match detail', match);
    // Common URL generation
    const gamesurl = match.name
        ? match.name.replace(/\s+/g, "-")
            .replace(/\//g, "-")
            .replace(/-+/g, "-")
            .toLowerCase()
        : "";
    const gameurlslug = `${gamesurl}/${match.id}`;

    // Common parsed data
    const time = LocalTime(match.time);
    const gamestatus = JSON.parse(match.full_status);
    const result = JSON.parse(match.result);

    // Common status class generator
    const getStatusClass = (status) => {
        return status.short === "FT" ? "status-finished"
            : status.short === "NS" ? "status-notstarted"
                : "";
    };

    // Common team row component
    const TeamRow = ({ team, score, defaultImage }) => (
        team && (
            <div className="accordion-sub-inner">
                <div className="span-image-live">
                    <img
                        src={team.icon || defaultImage}
                        alt={team.name}
                        loading="lazy"
                        width="25"
                        height="25"
                        onError={(e) => (e.target.src = defaultImage)}
                    />
                    {team.display_name}
                </div>
                <div className="span-live-count">{score}</div>
            </div>
        )
    );

    // Common hockey row component
    const HockeyRow = ({ team, periods, total, defaultImage }) => (
        team && (
            <div className="accordion-sub-inner">
                <div className="span-image-live">
                    <img
                        src={team.icon || defaultImage}
                        alt={team.name}
                        className="image-live"
                        loading="lazy"
                        width="25"
                        height="25"
                        onError={(e) => (e.target.src = defaultImage)}
                    />
                    {team.display_name}
                </div>
                <div className="icehockey--match-flex-score">
                    <div className="hockey-score-row">
                        <div className="hockey-score-list">
                            {periods.map((p, idx) => (
                                <div key={idx} className="hockey-score">{p}</div>
                            ))}
                            <div className="hockey-score score--bold">{total}</div>
                        </div>
                    </div>
                </div>
            </div>
        )
    );

    // Common match header component
    const MatchHeader = ({ time, gamestatus }) => (
        <div className="league-rows-iteam-time">
            <span className="match-date">{time.date}</span>
            <span className="match-date">{time.time}</span>
            <span className={`match-status ${getStatusClass(gamestatus)}`}>
                {gamestatus.short}
            </span>
        </div>
    );

    // Common card header component
    const CardHeader = ({ time, gamestatus }) => (
        <div className="match-card__header">
            <div className="match-card__meta">
                <div className="match-card__time">{time.date}</div>
                <div className="match-card__time">{time.time}</div>
                <div className={`match-status ${getStatusClass(gamestatus)}`}>
                    {gamestatus.short}
                </div>
            </div>
        </div>
    );

    // Common team display component for cards
    const CardTeam = ({ team, scores, totalScore, defaultImage }) => (
        <div className={`match-card__${team === match.home ? 'home' : 'away'}`}>
            {team && team.name && (
                <div className="match-card__team">
                    <img
                        src={team.icon || defaultImage}
                        alt={team.name}
                        className="match-card__team-logo"
                        width="20"
                        height="20"
                        loading="lazy"
                        onError={(e) => (e.target.src = defaultImage)}
                    />
                    <span className="match-card__team-name">{team.display_name}</span>
                </div>
            )}
            <div className="match-card__scoreboard">
                <div className="match-card__innings">
                    {scores.map((score, index) => (
                        <div className="match-card__inning" key={index}>
                            {score}
                        </div>
                    ))}
                    <div className="match-card__total">{totalScore}</div>
                </div>
            </div>
        </div>
    );

    // FOOTBALL, RUGBY, HANDBALL 
    if (["football", "rugby", "handball"].includes(slug)) {
        const homeScore = slug === "football"
            ? (result.fulltime?.home !== null ? result.fulltime.home : "-")
            : (result.home ?? "-");
        const awayScore = slug === "football"
            ? (result.fulltime?.away !== null ? result.fulltime.away : "-")
            : (result.away ?? "-");

        return (
            <Link
                to={`/${slug}/game/${gameurlslug}`}
                className="accordion-flex"
                key={match.id}
                data-id={match.id}
            >
                <div className="accordion-flex-iteam accordion-flex-grow">
                    <div className="accordion-flex-iteam full-width">
                        <MatchHeader time={time} gamestatus={gamestatus} />
                    </div>
                </div>

                <div className="accordion-flex-iteam accordion-flex-grow-big">
                    <div className="accordion-sub-iteam">
                        <TeamRow team={match.home} score={homeScore} defaultImage={defaultImage} />
                        <TeamRow team={match.away} score={awayScore} defaultImage={defaultImage} />
                    </div>
                </div>
            </Link>
        );
    }

    // ICE HOCKEY
    if (slug === "ice-hockey") {
        const moreinfo = JSON.parse(match.more_info);
        const periods = moreinfo.periods;

        const getPeriodScores = (period) => {
            if (!period) return ["-", "-"];
            const [h, a] = period.split("-");
            return [h || "-", a || "-"];
        };

        const [firstH, firstA] = getPeriodScores(periods.first);
        const [secondH, secondA] = getPeriodScores(periods.second);
        const [thirdH, thirdA] = getPeriodScores(periods.third);
        const [otH, otA] = getPeriodScores(periods.overtime);
        const [penH, penA] = getPeriodScores(periods.penalties);

        const homeScore = result.home ?? "-";
        const awayScore = result.away ?? "-";

        return (
            <Link
                to={`/${slug}/game/${gameurlslug}`}
                className="accordion-flex"
                key={match.id}
            >
                <div className="accordion-flex-iteam accordion-flex-grow">
                    <div className="accordion-flex-iteam full-width">
                        <MatchHeader time={time} gamestatus={gamestatus} />
                    </div>
                </div>

                <div className="accordion-flex-iteam accordion-flex-grow-big">
                    <div className="accordion-sub-iteam">
                        <HockeyRow
                            team={match.home}
                            periods={[firstH, secondH, thirdH, otH, penH]}
                            total={homeScore}
                            defaultImage={defaultImage}
                        />
                        <HockeyRow
                            team={match.away}
                            periods={[firstA, secondA, thirdA, otA, penA]}
                            total={awayScore}
                            defaultImage={defaultImage}
                        />
                    </div>
                </div>
            </Link>
        );
    }

    // BASEBALL, BASKETBALL, VOLLEYBALL - Card layout
    if (["baseball", "basketball", "volleyball"].includes(slug)) {
        let homeScores = [];
        let awayScores = [];
        let homeTotal = "-";
        let awayTotal = "-";

        if (slug === "baseball") {
            const inningsKeys = Object.keys(result.home.innings);
            const homeInnings = result.home.innings;
            const awayInnings = result.away.innings;

            homeScores = inningsKeys.map(inning =>
                homeInnings[inning] === null ? "-" : homeInnings[inning] ?? "0"
            );
            awayScores = inningsKeys.map(inning =>
                awayInnings[inning] === null ? "-" : awayInnings[inning] ?? "0"
            );
            homeTotal = result.home.total !== null ? result.home.total : "-";
            awayTotal = result.away.total !== null ? result.away.total : "-";
        }

        if (slug === "basketball") {
            const quarters = ["quarter_1", "quarter_2", "quarter_3", "quarter_4", "over_time"];
            const getQuarterValue = (team, key) => team?.[key] !== null ? team[key] : "-";

            homeScores = quarters.map(q => getQuarterValue(result.home, q));
            awayScores = quarters.map(q => getQuarterValue(result.away, q));
            homeTotal = result.home?.total ?? "-";
            awayTotal = result.away?.total ?? "-";
        }

        if (slug === "volleyball") {
            const moreinfo = JSON.parse(match.more_info);
            const periods = moreinfo?.periods || {};
            const periodEntries = Object.entries(periods);

            homeScores = periodEntries.map(([_, value]) => value?.home != null ? value.home : "-");
            awayScores = periodEntries.map(([_, value]) => value?.away != null ? value.away : "-");
            homeTotal = result.home ?? "-";
            awayTotal = result.away ?? "-";
        }

        return (
            <Link
                to={`/${slug}/game/${gameurlslug}`}
                className={`match-card ${slug}`}
                key={match.id}
                data-id={match.id}
            >
                <CardHeader time={time} gamestatus={gamestatus} />

                <div className="match-card__body">
                    <div className="match-card__teams">
                        <CardTeam
                            team={match.home}
                            scores={homeScores}
                            totalScore={homeTotal}
                            defaultImage={defaultImage}
                        />
                        <CardTeam
                            team={match.away}
                            scores={awayScores}
                            totalScore={awayTotal}
                            defaultImage={defaultImage}
                        />
                    </div>
                </div>
            </Link>
        );
    }

    return null;
}