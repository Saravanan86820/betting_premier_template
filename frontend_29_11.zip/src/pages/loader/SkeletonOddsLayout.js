import React from "react";
import "./Loader.css";

export default function SkeletonOddsLayout() {
  return (
    <div className="odds-skeleton">

      {/* Sidebar */}
      <div className="sidebar-skeleton">
        <div className="search-skeleton skeleton"></div>

        <div className="list">
          <div className="item skeleton"></div>
          <div className="item skeleton"></div>
          <div className="item skeleton"></div>
          <div className="item skeleton"></div>
          <div className="item skeleton"></div>
          <div className="item skeleton"></div>
        </div>
      </div>

      {/* Right Section */}
      <div className="content-skeleton">

        <div className="header-row">
          <div className="bookmaker skeleton"></div>
          <div className="updated skeleton"></div>
        </div>

        <div className="cards-row">
          <div className="card skeleton"></div>
          <div className="card skeleton"></div>
          <div className="card skeleton"></div>
        </div>

      </div>

    </div>
  );
}
