// Database configuration
const DB_NAME = 'BetDataDB';          // Name of the IndexedDB database
const DB_VERSION = 251125;            // Database version; update this to force schema upgrade
const STORE_NAME = 'DataStore';       // Single generic object store for storing all kinds of data (key-value pairs)

// Utility function to check if IndexedDB is available in the environment
export function isIndexedDBAvailable() {
  return typeof indexedDB !== 'undefined';
}

// Opens the IndexedDB database and ensures the required store exists.
// Upgrades DB schema if version changes; creates object store if missing.
export function openDB() {
  return new Promise((resolve, reject) => {
    if (!isIndexedDBAvailable()) {
      reject(new Error('IndexedDB is not supported')); // Handle unsupported browsers
      return;
    }

    // Attempt to open the database
    const request = indexedDB.open(DB_NAME, DB_VERSION);

    // Fires if the database cannot be opened (permissions, browser support, etc)
    request.onerror = () => reject(new Error('Failed to open IndexedDB'));

    // Fires when the DB is successfully opened
    request.onsuccess = () => resolve(request.result);

    // Fires if the DB needs to be upgraded (new version) or if newly created
    request.onupgradeneeded = (event) => {
      const db = event.target.result;
      // Create object store if it doesn't already exist
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        db.createObjectStore(STORE_NAME, { keyPath: 'key' }); // keyPath 'key' for easy key-based access
      }
    };
  });
}

// Saves a value in the DB under a specific key (e.g., 'country_list')
// Overwrites data for that key if already exists
export function setToDB(key, value) {
  return new Promise(async (resolve, reject) => {
    if (!isIndexedDBAvailable()) {
      resolve(); // No-op if DB is not supported
      return;
    }

    try {
      const db = await openDB();
      // Defensive: verify store exists
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        reject(new Error(`Object store ${STORE_NAME} does not exist in DB.`));
        return;
      }
      // Start a readwrite transaction
      const tx = db.transaction(STORE_NAME, 'readwrite');
      const store = tx.objectStore(STORE_NAME);
      // Store the value using the provided key
      store.put({ key, value });

      tx.oncomplete = () => resolve(); // Complete transaction
      tx.onerror = () => reject(new Error(`Failed to save data for key ${key}`)); // Transaction error
    } catch (error) {
      reject(error); // Handle async errors
    }
  });
}

// Retrieves the value stored under the specified key in the DB
// Returns 'null' if not found or if DB is unavailable
export function getFromDB(key) {
  return new Promise(async (resolve, reject) => {
    if (!isIndexedDBAvailable()) {
      resolve(null); // Fallback for unsupported environments
      return;
    }

    try {
      const db = await openDB();
      // Defensive: verify store exists
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        reject(new Error(`Object store ${STORE_NAME} does not exist in DB.`));
        return;
      }
      // Start a readonly transaction
      const tx = db.transaction(STORE_NAME, 'readonly');
      const store = tx.objectStore(STORE_NAME);
      // Get the record by its key
      const request = store.get(key);
      request.onsuccess = () => {
        if (request.result) {
          resolve(request.result.value); // Return stored value if found
        } else {
          resolve(null); // Key not found: return null
        }
      };
      request.onerror = () => reject(new Error(`Failed to get data for key ${key}`)); // Transaction error
    } catch (error) {
      reject(error); // Async error
    }
  });
}
