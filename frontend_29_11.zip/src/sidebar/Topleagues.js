import React, { useState, useEffect } from "react";
import './NewTopLeagues.css';
import { useLocation, Link } from 'react-router-dom';

import useTopLeagueList from "../components/country/useTopLeagueList";
import TopLeaguesSkeleton from "../pages/loader/TopLeaguesSkeleton";

const Topleagues = () => {
    const location = useLocation();
    const slug = location.pathname.split("/")[1];
    const dynamicSlug = slug || "football";

    const {leagueData, loading, error} = useTopLeagueList(dynamicSlug);


    return (
        <div className="top-leagues-section" id="top-league">
            <div className="top-leagues-section__header">
                <h2>Top Leagues</h2>
                <div className="top-leagues-section__divider"></div>
            </div>

            {
                loading ? (
                    <TopLeaguesSkeleton />
                ) : error ? (
                    <p className="error-text">{error}</p>
                ) : (
                    <div className="top-leagues-section__top-leagues">
                        {leagueData.map((league, index) => (
                            <div key={index} className="top-leagues-section__league">
                                <Link to={league.link}>
                                    <img
                                        src={league.icon}
                                        alt={league.alt || league.league_name}
                                        className={`top-leagues-section__league-logo ${dynamicSlug}`}
                                        loading="lazy"
                                    />
                                    <span className="top-leagues-section__league-name">
                                        {league.league_name}
                                    </span>
                                </Link>
                            </div>
                        ))}
                    </div>
                )
            }
        </div>
    );
};

export default Topleagues;