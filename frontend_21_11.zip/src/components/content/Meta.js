import React, { useState, useEffect } from 'react';
import { Helmet } from "react-helmet";

/**
 * Fetch and display meta data for a specific page
 * @param {Object} props 
 * @returns 
 */
export default function Meta(props) {
  const pageName = props.pageName;
  const api = `/api/widget/${pageName}-page-meta`;
  const [metaData, setMetaData] = useState({});
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // RUN FETCH INSIDE USEEFFECT!
  useEffect(() => {
    setLoading(true);    // show spinner every time pageName changes

    // get page meta data
    fetch(api, { method: 'POST' })
      .then(resp => resp.json())
      .then(respData => {
        if (respData.status !== 'true') throw new Error(respData.message);
        let data = respData.data[0];
        data = JSON.parse(data.data);
        setMetaData(data);
        setLoading(false);
      })
      .catch(error => {
        console.error('Error:', error);
        setLoading(false);
        setError(error);
      });
  }, [pageName]); // re-fetch only when pageName changes

  if (loading) return null;
  if (error) return <div>Meta Data Error: {error.message}</div>;

  return (
    <Helmet>
      <title>{metaData.title}</title>
      <meta name="description" content={metaData.desc} />
    </Helmet>
  );
}
