import React from "react";

import { useParams, Link } from 'react-router-dom';



function RugbyScore() {
    return (


        <>
            <div className="league-main-container bg-image-color">
                <div className="league-main-bg"></div>
                <div className="Next-match-container">
                    <div className="Next-match-section-one"></div>
                    <div className="Next-match-section-two">
                        <div className="next-match-item">
                            <div className="next-match-title">
                                <div className="match-image">
                                    <img src="/bet-assets/site/image/football/team/meerbusch-u19-24542-670e4f9b02c4e839.png" className="small-images" alt="league" />
                                </div>
                                <h3 className="match-title">Meerbusch </h3>
                            </div>
                        </div>
                        <div className="next-match-item">
                            <p className="matchscore"> Finished
                            </p>
                            <h2 className="livedata-score"> 2 <span className="livedata-score-arrow">-</span> 4 </h2>
                            <p><span className="live-date"> December 7, 2024 at 5:30 PM </span></p>
                        </div>
                        <div className="next-match-item">
                            <div className="next-match-title">
                                <div className="match-image">
                                    <img src="/bet-assets/site/image/football/team/schalke-04-u19-7967-670e4dc5ac61d690.png" className="small-images" alt="league" />
                                </div>
                                <h3 className="match-title">Schalke 04 U19</h3>
                            </div>
                        </div>
                    </div>
                    <div className="Next-match-section-one"></div>
                </div>
            </div>


            <div className="baseball-game-container">

                <div className="league-main-container-two">
                    <div className="game-status-row ">
                        <div className="game-status-row-list">
                            <div className="game-status-row-data">
                                <div className="league-center-title">
                                    <div className="imageflex">

                                        <img src="/assets/image/more-info.svg" alt="League" width="25" height="25" className="league-imageflex" loading="lazy" />

                                        <h4 className="league-heading-sub"> More Info baseball </h4>
                                    </div>
                                </div>
                                <div className="goal-center-details">
                                    <div className="goal-center-list">
                                        <div className="goal-center-data">

                                            <span className="goal--image" >
                                                <img src="/assets/image/match-location.svg" alt="League" width="25" height="25" loading="lazy" />
                                            </span>
                                            <span className="goal--text" >Location</span>
                                        </div>
                                        <div className="goal-center-data">
                                            <span> Stadio Pierluigi Penzo </span>
                                        </div>
                                    </div>
                                    <div className="goal-center-list">
                                        <div className="goal-center-data">


                                            <span className="goal--image" >
                                                <img src="/assets/image/match-city.svg" alt="League" width="25" height="25" loading="lazy" />
                                            </span>
                                            <span className="goal--text" >City</span>
                                        </div>
                                        <div className="goal-center-data">
                                            <span>Venice </span>
                                        </div>
                                    </div>
                                    <div className="goal-center-list">
                                        <div className="goal-center-data">

                                            <span className="goal--image" >
                                                <img src="/assets/image/match-referee.svg" alt="League" width="25" height="25" loading="lazy" />
                                            </span>
                                            <span className="goal--text" >Referee</span>
                                        </div>
                                        <div className="goal-center-data">
                                            <span> Daniele Doveri, Italy </span>
                                        </div>
                                    </div>
                                    <div className="goal-center-list">
                                        <div className="goal-center-data">


                                            <span className="goal--image" >
                                                <img src="/assets/image/match-date-time.svg" alt="League" width="25" height="25" loading="lazy" />
                                            </span>
                                            <span className="goal--text" >Date and Time</span>
                                        </div>
                                        <div className="goal-center-data">
                                            <span> December 8, 2024 at 10:30 PM</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="game-status-row-list">
                            <div className="game-status-row-data">
                                <div className="league-center-title">
                                    <div className="imageflex">

                                        <img src="/assets/image/goal-status.svg" alt="League" width="25" height="25" className="league-imageflex" loading="lazy" />

                                        <h4 className="league-heading-sub"> Goal Status </h4>
                                    </div>
                                </div>
                                <div className="goal-center-details">
                                    <div className="goal-center-list">
                                        <div className="goal-center-data">
                                            <span className="goal--image" >
                                                <img src="/assets/image/match-halftime.svg" alt="League" width="25" height="25" loading="lazy" />
                                            </span>
                                            <span className="goal--text" >periods.first</span>



                                        </div>
                                        <div className="goal-center-data text-game-left">
                                            <span> 26 </span> -  <span> 23 </span>
                                        </div>
                                    </div>
                                    <div className="goal-center-list">
                                        <div className="goal-center-data">

                                            <span className="goal--image" >
                                                <img src="/assets/image/match-mediumtime.svg" alt="League" width="25" height="25" loading="lazy" />
                                            </span>
                                            <span className="goal--text" >periods.second</span>

                                        </div>
                                        <div className="goal-center-data text-game-left">
                                            <span> 30 </span> -  <span> 26 </span>
                                        </div>
                                    </div>
                                    <div className="goal-center-list">
                                        <div className="goal-center-data">
                                            <span className="goal--image" >
                                                <img src="/assets/image/match-fulltime.svg" alt="League" width="25" height="25" loading="lazy" />
                                            </span>
                                            <span className="goal--text" >periods.overtime</span>

                                        </div>
                                        <div className="goal-center-data text-game-left">
                                            <span> 30 </span> -  <span>  21 </span>
                                        </div>
                                    </div>
                                    <div className="goal-center-list">
                                        <div className="goal-center-data">


                                            <span className="goal--image" >
                                                <img src="/assets/image/match-extratime.svg" alt="League" width="25" height="25" loading="lazy" />
                                            </span>
                                            <span className="goal--text" >periods,second_overtime</span>
                                        </div>
                                        <div className="goal-center-data text-game-left">
                                            <span>  27 </span> -  <span>  30  </span>
                                        </div>
                                    </div>


                                </div>

                            </div>
                        </div>
                    </div>

                </div>


            </div>

        </>


    );

}

export default RugbyScore;