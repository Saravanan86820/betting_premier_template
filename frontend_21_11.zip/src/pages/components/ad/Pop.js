import React, { useEffect } from "react";

let popupScriptLoaded = false; // Global flag

const Popup = () => {
  useEffect(() => {
    if (!popupScriptLoaded) {
      const script = document.createElement('script');
      script.src = '/direct/popup.js';
      script.async = true;
      document.body.appendChild(script);
      popupScriptLoaded = true; // Set the flag

      return () => {
        // Cleanup: Remove the script when the component unmounts
        // or flag might be set to false here, but that is not really needed in this case.
      };
    }
  }, []);

  return <></>;
};

export default Popup;