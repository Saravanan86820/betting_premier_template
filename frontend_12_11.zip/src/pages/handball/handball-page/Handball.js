import React from "react";
import '../../../index.css';

import HandballScorelist from "./HandballScorelist";


import Topleagues from "../../../sidebar/Topleagues";
import Alleagues from "../../../sidebar/Alleagues";
import NewTopLeagues from "../../../sidebar/NewTopLeagues";
// import Add from "../../sidebar/Add";

function Handball() {



  return (
    <>

      <div className="mvp-main-box-cont">
        <div className="container-scorelist container-betting-tools">
          <div className="container-score">

            <div className="column-score large">
              <div className="basketball-page-container" id="basketball-page">
                <HandballScorelist />
              </div>
            </div>

            <div className="column-score small">

              <div className="container-slide">

                {/* <FeatureMatch /> */}
                <NewTopLeagues sports="handball" />
                {/* <Add /> */}
                <Alleagues />

              </div>

            </div>
          </div>
        </div>
      </div>

    </>
  );

}

export default Handball;