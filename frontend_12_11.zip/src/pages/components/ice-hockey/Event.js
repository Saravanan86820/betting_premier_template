import React, { useState, useEffect } from "react";

const Event = ({ id, homeProvd_id, awayProvd_id, homeName, awayName }) => {

    const [event, setEvent] = useState([]);
    const [loading, setLoading] = useState(false);

    const eventAPI = `/api/sports/ice-hockey/game/${id}/stats`;

    // Helper function to convert minute to formatted time (MM:SS)
    //   const convertToFormattedTime = (minute) => {
    //     const totalSeconds = parseInt(minute) * 60; // Convert minutes to seconds
    //     const minutes = Math.floor(totalSeconds / 60);
    //     const seconds = totalSeconds % 60;
    //     return `${String(minutes).padStart(2, "0")}:${String(seconds).padStart(2, "0")}`;
    //   };
    // {convertToFormattedTime(event.minute)}

    // useEffect(() => {
    //     // Simulated API response
    //     const apiResponse = {
    //         status: "true",
    //         message: "",
    //         data: [
    //             {
    //                 id: 1,
    //                 game_id: 45130,
    //                 type: "events",
    //                 data: `[{"game_id":386870,"period":"P1","minute":"07","team":{"id":690,"name":"New Jersey Devils","logo":"https://media.api-sports.io/hockey/teams/690.png"},"players":["D. Mercer"],"assists":["N. Hischier","T. Meier"],"comment":null,"type":"goal"},{"game_id":386870,"period":"P1","minute":"15","team":{"id":1436,"name":"Seattle Kraken","logo":"https://media.api-sports.io/hockey/teams/1436.png"},"players":[],"assists":["C. Stephenson"],"comment":null,"type":"goal"},{"game_id":386870,"period":"P2","minute":"19","team":{"id":690,"name":"New Jersey Devils","logo":"https://media.api-sports.io/hockey/teams/690.png"},"players":["P. Cotter"],"assists":["D. Mercer","J. Kovacevic"],"comment":null,"type":"goal"},{"game_id":386870,"period":"P2","minute":"19","team":{"id":690,"name":"New Jersey Devils","logo":"https://media.api-sports.io/hockey/teams/690.png"},"players":["J. Siegenthaler"],"assists":[],"comment":"Cross-checking","type":"penalty"},{"game_id":386870,"period":"P2","minute":"19","team":{"id":690,"name":"New Jersey Devils","logo":"https://media.api-sports.io/hockey/teams/690.png"},"players":["B. Pesce"],"assists":[],"comment":"Fighting","type":"penalty"},{"game_id":386870,"period":"P2","minute":"19","team":{"id":1436,"name":"Seattle Kraken","logo":"https://media.api-sports.io/hockey/teams/1436.png"},"players":["B. Montour"],"assists":[],"comment":"Fighting","type":"penalty"},{"game_id":386870,"period":"P3","minute":"01","team":{"id":1436,"name":"Seattle Kraken","logo":"https://media.api-sports.io/hockey/teams/1436.png"},"players":["S. Wright"],"assists":["K. Kakko","J. McCann"],"comment":"Power-play","type":"goal"},{"game_id":386870,"period":"P3","minute":"02","team":{"id":690,"name":"New Jersey Devils","logo":"https://media.api-sports.io/hockey/teams/690.png"},"players":["O. Palat"],"assists":["J. Hughes","D. Hamilton"],"comment":null,"type":"goal"}]`,
    //                 updated: 1736228643,
    //             },
    //         ],
    //     };

    //     const rawData = apiResponse.data[0].data; // Stringified JSON
    //     const events = JSON.parse(rawData); // Parse the JSON string

    //     // Set the events state
    //     setEvent(events);
    //     console.log(events);
    // }, []);

    // const homekey = 690

    useEffect(() => {
        fetch(eventAPI, { method: 'POST' })
            .then(response => response.json())
            .then(respData => {

                let statsdata = null;

                if (respData['status'] !== 'true') {
                    return;
                }

                if (typeof respData['data'] !== 'object' || Object.keys(respData['data']).length === 0) {
                    return;
                }


                respData = respData['data'];
                for (const key in respData) {
                    if (!Object.prototype.hasOwnProperty.call(respData, key)) continue;
                    const item = respData[key];

                    if (item['type'] !== 'events') continue;
                    // console.log("eventAPI", item);
                    statsdata = item;
                    setLoading(true);
                }

              //  console.log(typeof statsdata);
                const statisticdata = statsdata ? JSON.parse(statsdata.data) : null;
              //  console.log("eventAPI", statisticdata);

                //   console.log("API response:", json);
                // console.log("lineupdata", statsdata);

                setEvent(statisticdata);  // Update lineups state
                setLoading(false);
            })
            .catch(err => {
                // console.error('Error fetching lineups:', err);
                setLoading(false);
            });
    }, [id]);

    if (loading) {
        return <div>Loading statistics...</div>;
    }

    if (!event || Object.keys(event).length === 0) return null;

    return (


        <div className="lineups-container">
            <div className="lineups-container-row">
                <div className="tab_buttons">
           
              <button
               
                className={`tab_button active`}
                onClick={() => handleTabClick(index)}
              >
                  <img
                    src={'/assets/image/event.png'}
                    width="18"
                    height="18"
                    className="league-imageflex"
                    loading="lazy"
                  />
                <span className="tab--name"> Events  </span>
              </button>
          </div>


                <div className="event">
         {/* Teams */}
         <div className="event__teams">
          <div className="event__team event__team--home">
            {homeName}
          </div>
          <div className="event__team event__team--away">
            {awayName}
          </div>
         </div>


        <div className="event__timeline">
          {event.map((e, index) => (
            <div className="event__row" data-id={e.team.id === Number(homeProvd_id)} key={`event-${index}`} >

                {e.type === "goal" ? (

                  <div className="event__item">
                    <div className="event__icon">
                      <img src="/assets/image/ice-hockey/ice-hockey.png" alt="Goal Icon" />
                    </div>
                    <div className="event__details">
                      <div className="event__player">{e.players.length > 0 && e.players ? e.players : "-"}</div>
                      <div className="event__assist">{e.assists.join(",") || "-"}</div>
                    </div>
                    <div className="event__time"> {e.minute} '</div>

                  </div>

                ) : e.type === "penalty" ? (

                  <div className="event__item">
                    <div className="event__icon">
                        <img src="/assets/image/event/goal.svg" alt="Penalty Icon" />
                    </div>
                    <div className="event__details">
                      <div className="event__player">{e.players.length > 0 && e.players ? e.players : "-"} </div>
                      <div className="event__assist"> {e.assists.join(",") || "-"}</div>
                    </div>
                    <div className="event__time"> {e.minute} </div>

                  </div>

                ) : null}



            </div>

          ))}





        </div>

      </div>

            </div>
        </div>


    );
};

export default Event;
