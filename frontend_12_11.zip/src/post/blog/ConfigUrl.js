const ConfigUrl = {
    API_BASE_URL: 'https://bettingpremier.ewallhost.com',
    // You can add other global settings here if needed
};

export default ConfigUrl;