import React, { useEffect, useState , useRef} from 'react';
import { Link } from 'react-router-dom'; // Import Link for routing if necessary
import './Navbar.css'; // Make sure to link to your CSS file

function Navbar() {

  const [showPopup, setShowPopup] = useState(false);
const [sidebarOpen, setSidebarOpen] = useState(false);

  // Close sidebar when clicking outside (only on mobile)
  useEffect(() => {
    const handleClickOutside = (e) => {
      const sidebar = document.querySelector(".sidebar");
      const hamburger = document.querySelector(".mobile-hamburger");
      if (
        sidebarOpen &&
        sidebar &&
        !sidebar.contains(e.target) &&
        !hamburger.contains(e.target)
      ) {
        setSidebarOpen(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, [sidebarOpen]);

  // Add or remove open class from existing sidebar
  useEffect(() => {
    const sidebar = document.querySelector(".sidebar");
    if (sidebar) {
      if (sidebarOpen) {
        sidebar.classList.add("sidebar--open");
      } else {
        sidebar.classList.remove("sidebar--open");
      }
    }
  }, [sidebarOpen]);
 
  return (

    <>
      <header className="header">

          {/* Mobile Hamburger Icon */}
  <button
    className="ham-icon"
    onClick={() => setSidebarOpen(!sidebarOpen)} // optional if you have sidebar toggle
  >


    <img
      src="/assets/image/hamburger.svg"
      alt="menu"
    />
  </button>


        {/* Logo */}
        <div className="header__img">
          <Link to="/">
            <img src="/assets/image/nav/logo.svg" alt="BettingPremier" width="150" height="50" loading="lazy" />
          </Link>
        </div>

      {/* Search */}
 {/* Search form (visible on desktop) */}
      <form
        role="search"
        method="get"
        action="https://bettingpremier.ewallhost.com/blog/"
        className="header__search-form desktop-search"
      >
        <div className="header__search">
          <img
            src="/assets/image/nav/search.svg"
            alt="search-icon"
            className="header__search-icon"
          />
          <input
            type="search"
            name="s"
            placeholder="Search..."
            className="header__search-input"
            required
          />
        </div>
      </form>

      

      {/* Popup for mobile search */}
      {showPopup && (
        <div className="mobile-search-popup">
          <div className="mobile-search-content">
            <form
              role="search"
              method="get"
              action="https://bettingpremier.ewallhost.com/blog/"
              className="mobile__search-form"
            >
              <img
                src="/assets/image/nav/search.svg"
                alt="search-icon"
                className="header__search-icon"
              />
              <input
                type="search"
                name="s"
                placeholder="Search..."
                className="header__search-input"
                autoFocus
                
              />
              <button
                type="button"
                className="close-btn"
                onClick={() => setShowPopup(false)}
              >
                ✕
              </button>
            </form>
          </div>
        </div>
      )}

      {/* Settings & Icons */}
      <div className="header__settings">

        {/* Mobile icon (click to open popup) */}
      <button
        className="mobile-search-icon"
        onClick={() => setShowPopup(true)}
      >
        <img
          src="/assets/image/nav/search.svg"
          alt="search"
          
        />
      </button>
        <a href="/blog/">
          <div className="header__items header__items--latest">
            <img src="/assets/image/nav/latest_new.svg" alt="latest" />
          </div>
        </a>

        {/* <a href="#">
          <div className="header__items header__items--setting">
            <img src="/assets/image/nav/setting.svg" alt="setting" />
          </div>
        </a>

        <div className="header__dark-mode-toggle">
          <img src="/assets/image/nav/dark-mode-toggle.svg" alt="dark-mode-toggle" />
        </div> */}
      </div>
    </header>

    {sidebarOpen && <div className="sidebar-overlay" onClick={() => setSidebarOpen(false)}></div>}

    </>
  );

}


export default Navbar;


