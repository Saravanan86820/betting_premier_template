import React from 'react';
import { Link } from "react-router-dom";
import LocalTime from '../../utility/LocalTime';
import './SimpleCard.css';

/**
 * Simple game card with basic details
 * @param {Object} props 
 * @returns 
 */
export default function SimpleCard(props) {
  const game = props.game || {};
  const sportsName = props.sports || 'default';

  let gameLinkName = game.name || '';
  if (!game.display_name && gameLinkName) {
    gameLinkName = gameLinkName.replace(/\s+/g, '-').replace(/\//g, '-').replace(/-+/g, '-').toLowerCase();
  }

  const gameLink = `/${sportsName}/game/${gameLinkName}/${game.id || ''}`;
  const localTime = game.time ? LocalTime(game.time) : '';

  let fullStatus = { long: '', short: '', elapsed: null, extra: null };
  try {
    if (game.full_status) fullStatus = JSON.parse(game.full_status);
  } catch { }

  const defaultImage = `/bet-assets/site/image/${sportsName}/default-icon.svg`;
  const homeTeam = game.home || {};
  const awayTeam = game.away || {};

  let homeResult = '-';
  let awayResult = '-';

  let homeData = null;
  let awayData = null;
  let inningsKeys = [];

  // Use objects for basketball quarters and overtime
  const homeQuarters = {
    quarter_1: '-',
    quarter_2: '-',
    quarter_3: '-',
    quarter_4: '-',
    over_time: '-',
  };

  const awayQuarters = {
    quarter_1: '-',
    quarter_2: '-',
    quarter_3: '-',
    quarter_4: '-',
    over_time: '-',
  };

  try {
    if (game.result) {
      const result = JSON.parse(game.result);

      // Baseball innings detection
      if (result.home?.innings && result.away?.innings) {
        homeData = result.home;
        awayData = result.away;

        inningsKeys = Object.keys(homeData.innings).sort((a, b) => {
          if (a === 'extra') return 1;
          if (b === 'extra') return -1;
          return parseInt(a) - parseInt(b);
        });

        homeResult = homeData.total != null ? homeData.total : '-';
        awayResult = awayData.total != null ? awayData.total : '-';
      }
      // Basketball quarters detection
      else if (result.home?.quarter_1 !== undefined) {
        Object.keys(homeQuarters).forEach(key => {
          homeQuarters[key] = result.home[key] != null ? result.home[key] : '-';
          awayQuarters[key] = result.away[key] != null ? result.away[key] : '-';
        });

        homeResult = result.home.total != null ? result.home.total : '-';
        awayResult = result.away.total != null ? result.away.total : '-';
      }
      // Soccer/hockey style detailed results
      else {
        if (result.home != null) {
          homeResult = result.home;
          awayResult = result.away;
        }
        if (result.fulltime) {
          if (result.halftime?.home != null) {
            homeResult = result.halftime.home;
            awayResult = result.halftime.away;
          }
          if (result.fulltime?.home != null) {
            homeResult = result.fulltime.home;
            awayResult = result.fulltime.away;
          }
          if (result.penalty?.home != null) {
            homeResult = `${homeResult} (${result.penalty.home})`;
            awayResult = `${awayResult} (${result.penalty.away})`;
          }
        }
      }
    }
  } catch {
    // Ignore parsing errors, default to '-'
  }

  return (
    <Link to={gameLink} key={game.id}>
      <div className="league-rows">
        <div className="league-rows-iteam-match1">
          <div className="league-rows-iteam-time">
              <span className="match-date">{localTime.date}</span>
              <span className="match-date">{localTime.time}</span>
            <span className={`match-status ${
              fullStatus.short === 'FT'
              ? 'status-finished'
              : fullStatus.short === 'NS'
              ? 'status-notstarted'
              : ''
            }`}>
              {fullStatus.short}
            </span>
          </div>
        </div>

        <div className="league-rows-iteam-match2">

          

          {/* Home Team Data */}
            {/* Baseball innings display */}
            {homeData ? (
              <div className="league-match-data">
            <div className="league-match-img baseball">
              <img
                src={homeTeam.icon || defaultImage}
                alt={homeTeam.display_name || 'home team'}
                className="league-live-img"
                onError={e => { e.target.src = defaultImage; }}
                loading="lazy"
                width="25"
                height="25"
              />
              <span>{homeTeam.display_name || '-'}</span>
            </div>
              <div className="icehockey--match-flex-score icehockey-home">
                <div className="baseball-score-row">
                  <div className="baseball-score-list">
                    {inningsKeys.map((inning, i) => (
                      <div className="baseball-score" key={i}>
                        {homeData.innings[inning] === null ? '-' : homeData.innings[inning] ?? '0'}
                      </div>
                    ))}
                  </div>
                  <div className="baseball-score-list">
                    <div className="baseball-score score--bold">{homeResult}</div>
                  </div>
                </div>
              </div>
              </div>
            )
              // Basketball quarters display
              : homeQuarters.quarter_1 !== '-' ? (
                <div className="league-match-data">
            <div className="league-match-img">
              <img
                src={homeTeam.icon || defaultImage}
                alt={homeTeam.display_name || 'home team'}
                className="league-live-img"
                onError={e => { e.target.src = defaultImage; }}
                loading="lazy"
                width="25"
                height="25"
              />
              <span>{homeTeam.display_name || '-'}</span>
            </div>
                <div className="icehockey--match-flex-score icehockey-home">
                  <div className="baseball-score-row">
                    <div className="baseball-score-list">
                      {Object.values(homeQuarters).map((score, i) => (
                        <div className="baseball-score" key={i}>{score}</div>
                      ))}
                    </div>
                    <div className="baseball-score-list">
                      <div className="baseball-score score--bold">{homeResult}</div>
                    </div>
                  </div>
                </div>
                </div>
              ) : (
                // Fallback: simple total score
                <div className="league-match-data">
            <div className="league-match-img">
              <img
                src={homeTeam.icon || defaultImage}
                alt={homeTeam.display_name || 'home team'}
                className="league-live-img"
                onError={e => { e.target.src = defaultImage; }}
                loading="lazy"
                width="25"
                height="25"
              />
              <span>{homeTeam.display_name || '-'}</span>
            </div>
                <div className="league-match-score">{homeResult}</div>
                </div>
              )}
          

          {/* Away Team Data */}
          

            {/* Baseball innings display */}
            {awayData ? (
              <div className="league-match-data">
            <div className="league-match-img baseball">
              <img
                src={awayTeam.icon || defaultImage}
                alt={awayTeam.display_name || 'away team'}
                className="league-live-img"
                onError={e => { e.target.src = defaultImage; }}
                loading="lazy"
                width="20"
                height="20"
              />
              <span>{awayTeam.display_name || '-'}</span>
            </div>
              <div className="icehockey--match-flex-score icehockey-away">
                <div className="baseball-score-row">
                  <div className="baseball-score-list">
                    {inningsKeys.map((inning, i) => (
                      <div className="baseball-score" key={i}>
                        {awayData.innings[inning] === null ? '-' : awayData.innings[inning] ?? '0'}
                      </div>
                    ))}
                  </div>
                  <div className="baseball-score-list">
                    <div className="baseball-score score--bold">{awayResult}</div>
                  </div>
                </div>
              </div>
              </div>
            )
              // Basketball quarters display
              : awayQuarters.quarter_1 !== '-' ? (
                <div className="league-match-data">
            <div className="league-match-img">
              <img
                src={awayTeam.icon || defaultImage}
                alt={awayTeam.display_name || 'away team'}
                className="league-live-img"
                onError={e => { e.target.src = defaultImage; }}
                loading="lazy"
                width="20"
                height="20"
              />
              <span>{awayTeam.display_name || '-'}</span>
            </div>
                <div className="icehockey--match-flex-score icehockey-away">
                  <div className="baseball-score-row">
                    <div className="baseball-score-list">
                      {Object.values(awayQuarters).map((score, i) => (
                        <div className="baseball-score" key={i}>{score}</div>
                      ))}
                    </div>
                    <div className="baseball-score-list">
                      <div className="baseball-score score--bold">{awayResult}</div>
                    </div>
                  </div>
                </div>
                </div>
              ) : (
                // Fallback: simple total score
                <div className="league-match-data">
            <div className="league-match-img">
              <img
                src={awayTeam.icon || defaultImage}
                alt={awayTeam.display_name || 'away team'}
                className="league-live-img"
                onError={e => { e.target.src = defaultImage; }}
                loading="lazy"
                width="20"
                height="20"
              />
              <span>{awayTeam.display_name || '-'}</span>
            </div>
                <div className="league-match-score">{awayResult}</div>
                </div>
              )}
          </div>
        </div>
      
    </Link>
  );
}
