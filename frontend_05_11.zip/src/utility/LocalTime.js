/**
 * Convert from timestamp (in seconds) to human-readable local date and time.
 * @param {string|number} timeStamp 
 * @returns {{ date: string, time: string }}
 */
export default function LocalTime(timeStamp) {
  const date = new Date(timeStamp * 1000); // convert to milliseconds

  // Format date part (e.g. 04 Nov 25)
  const formattedDate = date
    .toLocaleDateString('en-GB', {
      day: '2-digit',
      month: 'short',
      year: '2-digit'
    })
    .replace(',', '');

  // Format time part (e.g. 5:45 am)
  const formattedTime = date
    .toLocaleTimeString('en-US', {
      hour: 'numeric',
      minute: '2-digit',
      hour12: true
    })
    .toLowerCase();

  return {
    date: formattedDate,
    time: formattedTime
  };
}
