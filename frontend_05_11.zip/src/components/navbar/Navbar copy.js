import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom'; // Import Link for routing if necessary
import './Navbar.css'; // Make sure to link to your CSS file

function Navbar() {

  const [isSidenavOpen, setIsSidenavOpen] = useState(false);


  // Function to toggle the sidenav's visibility
  const toggleSidenav = () => {
    setIsSidenavOpen(!isSidenavOpen);
  };

  const [isScrolled, setIsScrolled] = useState(false);

  // Function to handle scroll event
  const handleScroll = () => {
    if (window.scrollY > 150) {
      setIsScrolled(true);
    } else {
      setIsScrolled(false);
    }
  };


  useEffect(() => {
    window.addEventListener('scroll', handleScroll);

    // Cleanup the event listener on component unmount
    return () => {
      window.removeEventListener('scroll', handleScroll);
    };
  }, []);

  const [openSubmenu, setOpenSubmenu] = useState(null);

  // Function to toggle the submenu
  const toggleSubmenu = (submenu) => {
    setOpenSubmenu(openSubmenu === submenu ? null : submenu);
  };

  return (

    <>
      <header className={`headerscroll ${isScrolled ? 'scroll-up' : ''}`}>
        <div id="mvp-bot-nav-wrap" className="lft headerscroll">
          <div className="mvp-main-box-cont">
            <div className="head_container">
              <div className="logo">
                <Link to="/">
                  <img src="/assets/image/common/logo.svg" alt="BettingPremier" width="150" height="50" loading="lazy" />
                </Link>
              </div>
              <div className="menu" id="myTopnav">
                <ul className="header-ul">


                  <li className="icon" onClick={toggleSidenav}>
                    &#9776;
                  </li>

                  <li className="header-li">
                    <a href="/blog/">
                      <img className="menu-item-icon" src="/assets/image/nav/latest.svg" alt="Latest" />
                      <span>Latest</span>
                    </a>
                  </li>


                  <li className="header-li  has-submenu">
                    <Link to="/football">
                      <img className="menu-item-icon" src="/assets/image/nav/football.svg" alt="Football" />
                      <span>Football</span>
                    </Link>
                    <ul className="submenu">

                      <li>    <a href="/blog/epl-live-stream/" > Premier League  </a> </li>
                      <li>    <a href="/blog/bundesliga-live-stream/" > Bundesliga </a> </li>
                      <li>    <a href="/blog/la-liga-live-stream/" > La Liga </a> </li>
                      <li>    <a href="/blog/serie-a-live-stream/" > Serie A </a> </li>
                      <li>    <a href="/blog/ligue-1-live-stream/" > Ligue 1 </a> </li>
                    </ul>
                  </li>

                  <li className="header-li">
                    <Link to="/ice-hockey">
                      <img className="menu-item-icon" src="/assets/image/nav/icehockey.svg" alt="Ice Hockey" />
                      <span>Hockey</span>
                    </Link>
                  </li>

                  <li className="header-li">
                    <Link to="/baseball">
                      <img className="menu-item-icon" src="/assets/image/nav/baseball.svg" alt="baseball" />
                      <span>Baseball</span>
                    </Link>

                  </li>
                  <li className="header-li  has-submenu">
                    <Link to="/basketball">
                      <img className="menu-item-icon" src="/assets/image/nav/basketball.svg" alt="basketball" />
                      <span>Basketball</span>
                    </Link>

                  </li>

                  <li className="header-li  has-submenu">
                    <a href="javascript:void(0);">
                      <img className="menu-item-icon" src="/assets/image/nav/majorleagues.svg" alt="Major Leagues" />
                      <span>Major Leagues</span>
                    </a>

                    <ul className="submenu">
                      <li>    <a href="/blog/mlb-live-stream/" > MLB  </a> </li>
                      <li>    <a href="/blog/nhl-live-stream/" > NHL </a> </li>
                      <li>    <a href="/blog/nba-live-stream-and-predictions/" > NBA </a> </li>
                      <li>    <a href="/blog/american-football/nfl-live-stream/" > NFL </a> </li>
                    </ul>
                  </li>

                  {/* <li className="header-li">
                    <Link to="/volleyball">
                      <img className="menu-item-icon" src="/assets/image/nav/volleyball.svg" alt="volleyball" />
                      <span>VOLLEYBALL</span>
                    </Link>
                  </li>
                  <li className="header-li">
                    <Link to="/rugby">
                      <img className="menu-item-icon" src="/assets/image/nav/rugby.svg" alt="rugby" />
                      <span>RUGBY</span>
                    </Link>
                  </li>
                  <li className="header-li">
                    <Link to="/handball">
                      <img className="menu-item-icon" src="/assets/image/nav/handball.svg" alt="handball" />
                      <span>HANDBALL</span>
                    </Link>
                  </li> */}


                  {/* 
                 
                 
                  <li className="header-li">
                    <Link to="/handball">
                      <img className="menu-item-icon" src="/assets/image/nav/handball.svg"  alt="handball" />
                      <span> HANDBALL </span>
                    </Link>
                  </li>
                  <li className="header-li">
                    <Link to="/volleyball">
                      <img className="menu-item-icon" src="/assets/image/nav/volleyball.svg"   alt="volleyball" />
                      <span> VOLLEYBALL </span>
                    </Link>
                  </li> */}


                  <li className="header-li has-submenu">
                    <Link to="">

                      <span>More</span>
                      <img className="menu-item-icon" src="/assets/image/nav/sportdown.svg" alt="majorleagues" />
                    </Link>
                    <ul className="submenu">

                      <li className="header-li">
                        <Link to="/volleyball">
                          <img className="menu-item-icon" src="/assets/image/nav/volleyball.svg" alt="volleyball" />
                          <span>VOLLEYBALL</span>
                        </Link>
                      </li>
                      <li className="header-li">
                        <Link to="/rugby">
                          <img className="menu-item-icon" src="/assets/image/nav/rugby.svg" alt="rugby" />
                          <span>RUGBY</span>
                        </Link>
                      </li>
                      <li className="header-li">
                        <Link to="/handball">
                          <img className="menu-item-icon" src="/assets/image/nav/handball.svg" alt="handball" />
                          <span>HANDBALL</span>
                        </Link>
                      </li>
                      <li><a href="/blog/category/betting/" >  Bet  Bet 365  </a> </li>
                      <li><a href="/blog/bet365-offers/" >  Bet Offers  </a> </li>
                      <li>  <a href="/blog/bet365-games/" >  Bet Games  </a> </li>
                      <li>  <a href="/blog/bet365-casino/" >   Bet Casino  </a></li>
                    </ul>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>

        <div
          id="mySidenav"
          className={`sidenav ${isSidenavOpen ? 'open' : ''}`}
          style={{ width: isSidenavOpen ? '100%' : '0' }}
        >

          <div className="mobile-navbar">
            <div className="mobile-logo">

              <img src="/assets/image/common/logo.svg" alt="BettingPremier" className="mobile-logo-img" />


              <button className="closebtn" onClick={toggleSidenav}>
                &times;
              </button>

            </div>

            <div className="mobile-nav-list">

              <ul className="nav-list-ul">
                <li className="nav-list-li">
                  <a href="/blog/">
                    <img className="menu-item-icon-m" src="/assets/image/nav/latest.svg" alt="Latest" /> <span className="navbar-text">Latest</span>
                  </a>
                </li>

                {/* <li className="nav-list-li">
                  <a href="/football">
                    <img className="menu-item-icon-m" src="/assets/image/nav/football.svg" alt="Football" /> <span className="navbar-text">Football</span>
                  </a>
                </li> */}

                <li className="nav-list-li submenu-mobile" data-attribute="football">

                  <div className="submenu-mobile-list" >
                    <a href="/football">

                      <span className="navbar-text mobile-text">  <img
                        className="menu-item-icon-m"
                        src="/assets/image/nav/football.svg"
                        alt="football"
                      /> Football</span>  </a>

                    <div onClick={() => toggleSubmenu('football')}>   <span className="submenu-icon--plus">{openSubmenu === 'football' ? '−' : '+'}</span></div>

                  </div>

                  {/* Submenu section */}
                  {openSubmenu === 'football' && (
                    <ul className="submenu-mobile">

                      <li className="submenu-mobile-li">     <a href="/blog/epl-live-stream/" > Premier League  </a>  </li>
                      <li className="submenu-mobile-li">  <a href="/blog/bundesliga-live-stream/" > Bundesliga </a>  </li>
                      <li className="submenu-mobile-li"> <a href="/blog/la-liga-live-stream/" > La Liga </a> </li>
                      <li className="submenu-mobile-li">  <a href="/blog/serie-a-live-stream/" > Serie A </a> </li>
                      <li className="submenu-mobile-li">  <a href="/blog/ligue-1-live-stream/" > Ligue 1 </a> </li>
                    </ul>
                  )}
                </li>

                <li className="nav-list-li">
                  <a href="/ice-hockey">
                    <img className="menu-item-icon-m" src="/assets/image/nav/icehockey.svg" alt="ice-Hockey" /> <span className="navbar-text">Ice Hockey </span>
                  </a>
                </li>
                <li className="nav-list-li">
                  <a href="/baseball">
                    <img className="menu-item-icon-m" src="/assets/image/nav/baseball.svg" alt="Baseball" /> <span className="navbar-text"> Baseball </span>
                  </a>
                </li>
                <li className="nav-list-li">
                  <a href="/basketball">
                    <img className="menu-item-icon-m" src="/assets/image/nav/basketball.svg" alt="basketball" /> <span className="navbar-text"> Basketball </span>
                  </a>
                </li>
                <li className="nav-list-li">
                  <a href="/volleyball">
                    <img className="menu-item-icon-m" src="/assets/image/nav/volleyball.svg" alt="basketball" /> <span className="navbar-text"> Volleyball </span>
                  </a>
                </li>
                <li className="nav-list-li submenu-mobile" data-attribute="majorLeagues">
                  <a href="#" className="submenu-mobile-list" onClick={() => toggleSubmenu('majorLeagues')}>


                    <span className="navbar-text mobile-text">  <img
                      className="menu-item-icon-m"
                      src="/assets/image/nav/sportdown.svg"
                      alt="Major Leagues"
                    /> More</span>

                    <span className="submenu-icon">{openSubmenu === 'majorLeagues' ? '−' : '+'}</span>
                  </a>

                  {/* Submenu section */}
                  {openSubmenu === 'majorLeagues' && (
                    <ul className="submenu-mobile">

                      <li className="submenu-mobile-li">
                        <a href="/blog/mlb-live-stream/">MLB</a>
                      </li>
                      <li className="submenu-mobile-li">
                        <a href="/blog/nhl-live-stream/">NHL</a>
                      </li>
                      <li className="submenu-mobile-li">
                        <a href="/blog/nba-live-stream-and-predictions/">NBA</a>
                      </li>
                      <li className="submenu-mobile-li">
                        <a href="/blog/american-football/nfl-live-stream/">NFL</a>
                      </li>
                      <li className="submenu-mobile-li">
                        <a href="/blog/bet365-offers/" >  Bet Offers  </a>
                      </li>
                      <li className="submenu-mobile-li">
                        <a href="/blog/bet365-games/" >  Bet Games  </a>
                      </li>
                      <li className="submenu-mobile-li">
                        <a href="/blog/bet365-casino/" >   Bet Casino  </a>
                      </li>
                    </ul>
                  )}
                </li>



              </ul>

            </div>
          </div>

        </div>
      </header>
    </>
  );

}


export default Navbar;