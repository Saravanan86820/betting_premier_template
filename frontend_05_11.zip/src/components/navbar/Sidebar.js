import React from "react";
import { useLocation, Link } from "react-router-dom";
import "./Navbar.css";

const Sidebar = () => {
    const location = useLocation();

  const sports = [
    { name: "Football", icon: "/assets/image/side-icons/football.svg", link: "/football", active: true },
    { name: "Ice Hockey", icon: "/assets/image/side-icons/ice-hockey.svg", link: "/ice-hockey" },
    { name: "Baseball", icon: "/assets/image/side-icons/baseball.svg", link: "/baseball" },
    { name: "BasketBall", icon: "/assets/image/side-icons/basketball.svg", link: "/basketball" },
    { name: "Rugby", icon: "/assets/image/side-icons/rugby.svg", link: "/rugby" },
    { name: "Volleyball", icon: "/assets/image/side-icons/volleyball.svg", link: "/volleyball" },
    { name: "Handball", icon: "/assets/image/side-icons/handball.svg", link: "/handball" },
  ];

  return (
    <div className="sidebar">
      {sports.map((sport, index) => {
        const isActive = location.pathname.startsWith(sport.link);
        return (
          <Link to={sport.link} key={index}>
            <div className={`sidebar__icons ${isActive ? "sidebar__icons--active" : ""}`}>
              <img src={sport.icon} alt={`${sport.name}-icon`} />
              <div className="sidebar__tooltip">{sport.name}</div>
            </div>
          </Link>
        );
      })}
    </div>
  );
};


export default Sidebar;
