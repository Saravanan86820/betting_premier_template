import React, { useState, useEffect } from "react";
import '../Components.css';


function Oddsdata({ id, status }) {

    const [data, setData] = useState(null);
    const [activeTab, setActiveTab] = useState(null);
    const [loading, setLoading] = useState(true);
    const [updatedTime, setUpdatedTime] = useState("");
    const [filterText, setFilterText] = useState(""); // New state for search
    const oddsAPI = `/api/sports/basketball/game/${id}/odds`;



    useEffect(() => {
        fetch(oddsAPI, { method: 'POST' })
            .then(response => response.json())
            .then(respData => {

                let oddsdata = null;

                if (respData['status'] !== 'true' || !respData['data']) {
                    setLoading(false);
                    return;
                }

                if (typeof respData['data'] !== 'object' || Object.keys(respData['data']).length === 0) {
                    return;
                }

                respData = respData['data'];
                for (const key in respData) {
                    if (!Object.prototype.hasOwnProperty.call(respData, key)) continue;
                    const item = respData[key];

                    if (item['type'] !== 'prematch') continue;
                    //    console.log("item", item);
                    oddsdata = item;

                }

                // console.log(typeof linedata);
                const oddsupdata = oddsdata ? JSON.parse(oddsdata.data) : null; // Ensure it's an array
                const oddsvalue = oddsupdata && oddsupdata?.[0]?.bets || null;


                //  console.log("lineupdata", oddsvalue);


                setData(oddsvalue);

                // Dynamically set activeTab to the first bet's id or fallback to 1
                if (oddsvalue && oddsvalue.length > 0) {
                    setActiveTab(oddsvalue[0]?.id);
                } 


                setUpdatedTime(oddsdata?.updated || "");
                setLoading(false);
            })
            .catch(err => {
                console.error('Error fetching odds:', err);
                setLoading(false);
            });
    }, [id]);

    if (loading) {
        return <div>Loading...</div>;
    }

    if (!data || Object.keys(data).length === 0) return null;

    const handleTabClick = (id) => {
        setActiveTab(id); // Set the clicked tab as active
    };

    const handleClick = () => {
        window.open('/direct/bet365-sports.html', '_blank');
    };

    // window.location.href = '/direct/bet365-sports.html';

    //Hide the finished match odds design.
    const normalizedStatus = status?.toUpperCase();

    // Check if status is 'FT', 'AET', or 'PEN'
    if (normalizedStatus === 'FT' || normalizedStatus === 'AOT' || normalizedStatus === 'AP') {
        return null; // Hide component
    }

    // Filter the data based on the search input
    const filteredData = data.filter(bet =>
        bet.name.toLowerCase().includes(filterText.toLowerCase())
    );

    return (
        <>

            <div className="odds-container">
                <div className="lineups-container-row">

                    {/* Header with Image and Heading */}
                    <div className="odds-container__header">
            <img
              src="/assets/image/odds.png"
              alt="League"
              width="25"
              height="25"
              className="league-imageflex"
              loading="lazy"
            />
            <h4 className="odds-heading">Odds</h4>
          </div>
            <div className="odds__divider"></div>
                    {/* serch code */}



                    {/* serch code */}

                    <div className="odds-section">
                        <div className="search-mobile">
                            <div className="search-bar-mobile">
                                <input
                                    id="search"
                                    type="text"
                                    placeholder="Search odds by name..."
                                    value={filterText}
                                    onChange={(e) => setFilterText(e.target.value)}
                                    className="search-input"
                                />
                               <span className="icon--bar1">
                  <svg viewBox="0 0 24 24" height="40px" width="40px">
                    <defs>
                      <linearGradient id="gradientColor2" x1="0%" y1="0%" x2="100%" y2="100%">
                        <stop offset="0%" style={{ stopColor: "rgba(0, 183, 74, 1)", stopOpacity: 1 }} />
                        <stop offset="100%" style={{ stopColor: "rgba(9, 142, 63, 1)", stopOpacity: 1 }} />
                      </linearGradient>
                    </defs>
                    <path
                      d="M11.5 9a2.5 2.5 0 000 5 2.5 2.5 0 000-5M20 4H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2m-3.21 14.21l-2.91-2.91c-.69.44-1.51.7-2.38.7C9 16 7 14 7 11.5S9 7 11.5 7a4.481 4.481 0 013.8 6.89l2.91 2.9-1.42 1.42z"
                      fill="url(#gradientColor2)"
                    />
                  </svg>


                </span>



                            </div>
                        </div>

                        <div className="match-odds-container">


                            <div className="odds-tabs">
                                <div className="odds-tabs-scroll">

                                    <div className="search-bar">
                                        <input
                                            id="search"
                                            type="text"
                                            placeholder="Search odds by name..."
                                            value={filterText}
                                            onChange={(e) => setFilterText(e.target.value)}
                                            className="search-input"
                                        />
                                        <span className="icon--bar">
                      <svg viewBox="0 0 24 24" height="40px" width="40px">

                        <defs>
                          <linearGradient id="gradientColor" x1="0%" y1="0%" x2="100%" y2="100%">
                            <stop offset="0%" style={{ stopColor: "rgba(0, 183, 74, 1)", stopOpacity: 1 }} />
                            <stop offset="100%" style={{ stopColor: "rgba(9, 142, 63, 1)", stopOpacity: 1 }} />
                          </linearGradient>
                        </defs>


                        <path
                          d="M11.5 9a2.5 2.5 0 000 5 2.5 2.5 0 000-5M20 4H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2m-3.21 14.21l-2.91-2.91c-.69.44-1.51.7-2.38.7C9 16 7 14 7 11.5S9 7 11.5 7a4.481 4.481 0 013.8 6.89l2.91 2.9-1.42 1.42z"
                          fill="url(#gradientColor)"
                        />
                      </svg>

                    </span>


                                    </div>


                                    <div className="tabs__container">

                                        {filteredData.length > 0 ? (

                                            filteredData.map((bet) => (
                                                <span
                                                    key={bet.id} data-id={bet.id}
                                                    className={`bet-type ${activeTab === bet.id ? 'active' : ''}`}
                                                    onClick={() => handleTabClick(bet.id)}
                                                >
                                                    {bet.name}
                                                </span>
                                            ))

                                        ) : (

                                            <div className="no-odds">No matching odds found.</div>
                                        )


                                        }
                                    </div>
                                </div>

                            </div>
                            {/* Tabs Content */}



                            <div className="tabs__content">


                                <div className="search-odds-container">
                                    <div className="search-odds-row  text--left">
                                        <img
                                            src="/assets/image/betslogo365.svg"
                                            alt="Bet 365"
                                            width="100"
                                            height="54"
                                            className="league-imageflex"
                                            loading="lazy"
                                        />
                                    </div>

                                    <div className="search-odds-row text--right">
                                        <div className="tabs__content-update">
                                            <span className="goal--image" >
                                                <img src="/assets/image/time.png" alt="League" width="20" height="20" loading="lazy" />
                                            </span>


                                            <span className="update-time">
                                                Updated on: {new Date(updatedTime * 1000).toLocaleDateString('en-US', {
                                                    year: 'numeric',
                                                    month: 'short',
                                                    day: 'numeric',
                                                })}{" "}
                                                at {new Date(updatedTime * 1000).toLocaleTimeString('en-US', {
                                                    hour: 'numeric',
                                                    minute: '2-digit',
                                                    hour12: true,
                                                })}
                                            </span>


                                        </div>

                                    </div>

                                </div>

                                <div className="tabs__content-list">

                                    {filteredData.map((bet) =>
                                        activeTab === bet.id ? (
                                            <div key={bet.id} className="tabs__panel">
                                                {bet.values.map((option, index) => (
                                                    <div className="odds-bet-row" key={index}>

                                                        <div className="button--odds" onClick={handleClick}>
                                                            <div className="button--value"> {option.value}  </div>
                                                            <div className="button--odds-text" >
                                                                <span className="odds-text"> {option.odd} </span>
                                                                <span className="odds-link" >
                                                                    <svg viewBox="0 0 24 24" fill="#3cf236ff" height="12px" width="12px" >
                                                                        <path d="M13 3l3.293 3.293-7 7 1.414 1.414 7-7L21 11V3z" />
                                                                        <path d="M19 19H5V5h7l-2-2H5c-1.103 0-2 .897-2 2v14c0 1.103.897 2 2 2h14c1.103 0 2-.897 2-2v-5l-2-2v7z" />
                                                                    </svg>
                                                                </span>
                                                            </div>
                                                        </div>
                                                    </div>
                                                ))}
                                            </div>
                                        ) : null
                                    )

                                    }
                                </div>

                            </div>




                        </div>


                    </div>
                    {/* end div */}


                </div>
            </div>
        </>
    );
}
export default Oddsdata;