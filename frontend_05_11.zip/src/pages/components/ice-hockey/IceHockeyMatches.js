import React, { useEffect, useState, useRef } from "react";
import { useParams, Link } from 'react-router-dom';
import '.././Components.css';

import LocalTime from "../../../utility/LocalTime";
const HtmlToReactParser = require('html-to-react').Parser;

function IceHockeyMatches({ selectedSeason, slug }) {
  const errorMessage = 'Data not available right now';
  let { id: matchId } = useParams();

  // console.log("slug",slug);

  let [matches, setMatches] = useState([]);
  let [isError, setIsError] = useState(false);
  let [error, setError] = useState(null);
  let [fullMatch, setFullMatch] = useState(null);
  let [loading, setLoading] = useState(false);


  useEffect(() => {
    if (!selectedSeason) return;

    // Clear or reset logic before fetching new data
    setMatches([]);
    setFullMatch(null); // Reset the match details

    setIsError(false);
    setError(null);
    setLoading(true); // Set loading state

    const gameAPI = `/api/sports/ice-hockey/season/${selectedSeason['id']}/game`;

   //  console.log('Current gameseason:', gameAPI);

    setLoading(true);

    fetch(gameAPI, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ type: 'recent' }) })
      .then(response => response.json())
      .then(respData => {
        if (!respData['status'] || respData['status'] !== 'true' || respData['data'].length === 0) {
          console.error('Somthing wrong with the API response', respData);
          setIsError(true);
          return;
        }

        const currentTimeUTC = Math.floor(new Date().getTime() / 1000);
        // console.log(currentTimeUTC);
        let selectedMatches = [];
        let scheduleData = respData['data'];
        let lastmatches = scheduleData
          .filter(game => game['time'] < currentTimeUTC)
          .sort((a, b) => b.time - a.time)
          .slice(0, 5);

        // console.log("lastmatches",lastmatches);

        // upcoming matches
        selectedMatches = scheduleData
          .filter(game => game['time'] > currentTimeUTC)
          .sort((a, b) => a.time - b.time)
          .slice(0, 10);

        // console.log(selectedMatches);
        if (selectedMatches.length > 0)
          selectedMatches = [...selectedMatches, ...lastmatches];
        else
          selectedMatches = selectedMatches
            .concat(scheduleData
              .filter(game => game['time'] < currentTimeUTC)
              .sort((a, b) => b['time'] - a['time'])
              .slice(0, 10 - selectedMatches.length));
        // console.log("selectedMatches",selectedMatches);
        setMatches(selectedMatches);
        setLoading(false);
      })

      .catch(error => {
        setIsError(true);
        console.error('Error fetching match data:', error);
        setLoading(false);
      });
  }, [selectedSeason]);

  useEffect(() => {
    if (matches.length > 0) {
      matches.forEach(match => fetchGameDetails(match.id));
    }
  }, [matches]);

  if (loading) {
    return <div>Loading...</div>;
  }

  if (error) {
    return <div>Error: {error}</div>;
  }

  // let defaultImage = '/assets/image/ice-hockey/d-ice-hockey.svg';
  let defaultImage = "/assets/image/ice-hockey/ice-coin3.png";


  return (


    <div className="league-main-container">

      <div className="league-main-row">
        <div className="league-center-title">
          <div className="imageflex"><div className="league-heading-sub">
            <img src="/assets/image/games/ice-hockey.png" alt="League" width="20" height="20" className="league-imageflex" loading="lazy" />
            <h4>Game</h4>
           </div>
            <div className="league-heading-divider"></div>
          </div>
        </div>

        <div className="league-match-data-single">

          {isError && <div className="error-message">{errorMessage}</div>}

          {fullMatch && Object.keys(fullMatch).length > 0 ? (
            Object.keys(fullMatch).map((matchId) => (
              individualMatch(fullMatch[matchId])
            ))
          ) : (
            <div className="error-message">No data available</div>
          )}

          {!isError && moreBtn()}
        </div>
      </div>
    </div >
  );

  function fetchGameDetails(matchId) {
    const LeagueGame = `/api/sports/ice-hockey/game/${matchId}`;

    // console.log('LeagueGame games:', LeagueGame);

    fetch(LeagueGame, { method: 'POST' })
      .then(response => response.json())
      .then(json => {
        if (json && json.data) {
          //  console.log("Match ID:", matchId);
          // console.log("Match Data:", json.data);
          setFullMatch(prevState => ({
            ...prevState,
            [matchId]: json.data,
          }));
        } else {
          const errorMessage = `Game data not found for match ${matchId}`;
          console.error(errorMessage); // Log error to console
          // setError(errorMessage);
        }
      })
      .catch(error => {
        const errorMessage = `Error fetching game data for match ${matchId}`;
        console.error(errorMessage, error); // Log error details to console
        // setError(errorMessage);
      });
  }

  /**
   * generate individual match markup
   * @param {Object} match
   * @returns {JSX.Element}
   */
  function individualMatch(match) {


    let result = JSON.parse(match['result']);
    let homeScore = result['home'] !== null
      ? result['home'] : '-';
    let awayScore = result['away'] !== null
      ? result['away'] : '-';

    // local time
    let time = LocalTime(match['time']);

    let gamestatus = JSON.parse(match['full_status']);

    const gamesurl = match['name'] ? match['name'].replace(/\s+/g, '-').replace(/\//g, '-').replace(/-+/g, '-').toLowerCase() : "";
    const idgame = match["id"] ? match["id"] : "";
    const gameurlslug = `${gamesurl}/${idgame}`;


    const moreinfo = JSON.parse(match['more_info']);
    const referee = moreinfo.referee && moreinfo.referee !== null ? moreinfo.referee : "-";
    const morescore = Object.keys(moreinfo.periods).length;
    // console.log("periods11", morescore);

    const periodFirst = moreinfo?.periods?.first || "-";
    const [periodFirstHome = "-", periodFirstAway = "-"] = periodFirst !== "-" ? periodFirst.split("-") : [];

    const periodSecond = moreinfo?.periods?.second || "-";
    const [periodSecondHome = "-", periodSecondAway = "-"] = periodSecond !== "-" ? periodSecond.split("-") : [];

    const periodThird = moreinfo?.periods?.third || "-";
    const [periodThirdHome = "-", periodThirdAway = "-"] = periodThird !== "-" ? periodThird.split("-") : [];

    const periodOvertime = moreinfo?.periods?.overtime || "-";
    const [periodOvertimeHome = "-", periodOvertimeAway = "-"] = periodOvertime !== "-" ? periodOvertime.split("-") : [];

    const periodPenaltiestime = moreinfo?.periods?.penalties || "-";
    const [periodPenaltiesHome = "-", periodPenaltiesAway = "-"] = periodPenaltiestime !== "-" ? periodPenaltiestime.split("-") : [];




    return (
      <Link to={`/${slug}/game/${gameurlslug}`} className="accordion-flex" key={match['id']} data-id={match['id']}>
        <div className="accordion-flex-iteam accordion-flex-grow">
          <div className="accordion-favriote-row">
            <div className="accordion-sub-inner1">
              <div className="match-date">
                <span className="live-date">{time.date}</span>
                <span className="live-date">{time.time}</span>
                <div className="match-status"> {gamestatus.short}</div>
              </div>
            </div>
          </div>
        </div>
        <div className="accordion-flex-iteam accordion-flex-grow-big">
          <div className="accordion-sub-iteam">
            {/* {new HtmlToReactParser().parse(homeTeam)}
            {new HtmlToReactParser().parse(awayTeam)} */}

            {match.home && match.home.name && (
              <div className="accordion-sub-inner">
                <div className="span-image-live">
                  <img
                    src={match.home.icon || defaultImage}
                    alt={match.home.name}
                    className="image-live img--error"
                    loading="lazy"
                    width="20"
                    height="20"
                    onError={(e) => { e.target.src = defaultImage; }}
                  />
                  {match.home.display_name}
                </div>
              </div>
            )}

            {match.away && match.away.name && (
              <div className="accordion-sub-inner">
                <div className="span-image-live">
                  <img
                    src={match.away.icon || defaultImage}
                    alt={match.away.name}
                    className="image-live"
                    loading="lazy"
                    width="20"
                    height="20"
                    onError={(e) => { e.target.src = defaultImage; }}
                  />
                  {match.away.display_name}
                </div>
              </div>
            )}
          </div>
        </div>
        <div className="accordion-flex-iteam accordion-flex-grow-big">
          <div className="icehockey--match-flex-score  icehockey-home">
            <div className="baseball-score-row">

              <div className="baseball-score-list">
                <div className="baseball-score">{periodFirstHome}</div>
                <div className="baseball-score"> {periodSecondHome} </div>
                <div className="baseball-score"> {periodThirdHome} </div>
                <div className="baseball-score"> {periodOvertimeHome} </div>
                <div className="baseball-score"> {periodPenaltiesHome} </div>
              </div>
              <div className="baseball-score-list">
                <div className="baseball-score score--bold"> {homeScore} </div>
              </div>
            </div>
          </div>
          <div className="icehockey--match-flex-score icehockey-away">
            <div className="baseball-score-row">
              <div className="baseball-score-list">
                <div className="baseball-score"> {periodFirstAway} </div>
                <div className="baseball-score"> {periodSecondAway} </div>
                <div className="baseball-score"> {periodThirdAway} </div>
                <div className="baseball-score"> {periodOvertimeAway} </div>
                <div className="baseball-score"> {periodPenaltiesAway} </div>
              </div>
              <div className="baseball-score-list">
                <div className="baseball-score score--bold"> {awayScore} </div>
              </div>
            </div>
          </div>
        </div>
      </Link>
    );
  }




  /**
   * more button
   * @returns {JSX.Element}
   */
  function moreBtn() {
    return (
      <div className="more-match">
        <Link to={`/${slug}/matches/${selectedSeason['id']}`} className="game-button">
          More Games
        </Link>
      </div>
    );
  }
}


// const addDefaultImg = () => { 
//   alert('The image could not be loaded.');
// };

// const addDefaultImg = (ev) => {
//   ev.target.src = "/assets/image/defaulticon.svg"; //onError={addDefaultImg}  onerror="myFunction()"    onerror="this.src='${defaultImage}'" Ensure this path is correct
// };

export default IceHockeyMatches;
