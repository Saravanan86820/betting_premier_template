import React, { useEffect, useState } from "react";
import '.././Components.css';

// import { useParams } from 'react-router-dom';
import LocalTime from "../../../utility/LocalTime";
const HtmlToReactParser = require('html-to-react').Parser;
import { Link, useParams } from 'react-router-dom';
import Oddsdata from "./Oddsdata";


function GameScore() {
  const { id } = useParams();
  const [gameData, setGameMatch] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const gameAPI = `/api/sports/handball/game/${id}`;

  useEffect(() => {
    fetch(gameAPI, { method: 'POST' })
      .then(response => response.json())
      .then(json => {

        //console.log('Fetched match data:', json);
        if (json['status'] !== 'true') {
          return;
        }

        if (json && json['data']) {
          setGameMatch(json['data']); // Store the entire game data
        } else {
          setError('Game not found');
        }
        setLoading(false);
      })

      .catch(err => {
        console.error('Error fetching match season:', err);
        setLoading(false);
      });
  }, [id]);

  // validate response
  if (loading)
    return <div>Loading...</div>;
  if (error)
    return <div>{error}</div>;
  if (!gameData)
    return <div>No game data available.</div>;

  const resultHtml = result(gameData['full_status'], gameData['result'], gameData['time']);
  const homeHtml = gameData['home'] ? team(gameData['home']) : '';
  const awayHtml = gameData['away'] ? team(gameData['away']) : '';


  // const resultHtml1 = location(gameData['halftime'], gameData['fulltime'], gameData['extratime'] , gameData['goals']);

  //console.log(homeTeam.icon);


  const resultData = JSON.parse(gameData.result);

    const location = gameData.location && gameData.location !== "" ? JSON.parse(gameData.location) : {};
  const locationCity = location.city && location.city !== "" ? location.city : "-";
  const locationName = location.name && location.name !== "" ? location.name : "-";


  const moreinfo = JSON.parse(gameData.more_info);
  const referee = moreinfo.referee && moreinfo.referee !== null ? moreinfo.referee : "-";

  const periods = moreinfo && moreinfo.periods || {};

  const firstPeriodAway = periods.first?.away || 0; // Default to 0 if data is unavailable
  const firstPeriodHome = periods.first?.home || 0;

  const secondPeriodAway = periods.second?.away || 0;
  const secondPeriodHome = periods.second?.home || 0;


  // console.log("periodsdata", periods);

  const hometime = gameData.time;
  const utctime = LocalTime(hometime);
  // console.log("resultData", utctime);
  let defaultImage = '/assets/image/handball/handball.svg';

  const homeTeamIcon = gameData.home ? gameData.home.icon : defaultImage;
  const awayTeamIcon = gameData.away ? gameData.away.icon : defaultImage;

  const homeProvd_id = gameData.home ? gameData.home.provd_id : '';
  const awayProvd_id = gameData.away ? gameData.away.provd_id : '';

  const homeTeam = gameData.home || {};
  const awayTeam = gameData.away || {};

  
  const league = gameData.league || {};
  const leagueName = league.display_name;
  const leagueLink = `/handball/${league.name}/${league.id}`;
  

  // location
  const venueID = gameData.venue_id ? gameData.venue_id : null;

  const bgimage = homeTeam.icon ? homeTeam.icon : awayTeam.icon;

  const status = gameData.status;
  //  console.log("status", status);

  const homeName = homeTeam.display_name;
  const awayName = awayTeam.display_name;


  return (
    <>

      <div className="game-container" key={gameData['id']} id="game-banner-top">
        <div className="breadcrumb">
                  <Link to="/handball" className="breadcrumb__link">
                    Handball
                  </Link>
                  <span className="breadcrumb__separator">{">"}</span>
                  <Link to={leagueLink} className="breadcrumb__link">
                    {leagueName}
                  </Link>
                  <span className="breadcrumb__separator">{">"}</span>
                  <span className="breadcrumb__current">{gameData.name}</span>
                </div>
        
        
        
        <div className="league-main-container bg-image-color">
          {/* <div className="league-main-bg" style={{ backgroundImage: `url(${bgimage})` }}></div> */}
          <div className="Next-match-container" >
            <div className="Next-match-section-one"></div>
            <div className="Next-match-section-two">
              {homeHtml}
              {resultHtml}
              {awayHtml}
            </div>
            <div className="Next-match-section-one">
                <div className="match-banner__details">
                  <div className="match-banner__detail-item">
                    <img src="/assets/image/time.png" alt="Date" className="match-banner__detail-icon" />
                    <span>{utctime}</span>
                    
                  </div>
                
                  <div className="match-banner__detail-item">
                    <Link to={leagueLink} className="detail-items">
                      <img src="/assets/image/trophy.png" alt="League" className="match-banner__detail-icon" />
                      <span>{leagueName}</span>
                    </Link>
                    
                  </div>
                
                  <div className="match-banner__detail-item">
                    {venueID ? (
                      <Link to={`/handball/venue/${venueID}`} className="detail-items">
                      <img src="/assets/image/venue.png" alt="Venue" className="match-banner__detail-icon" />
                      <span>
                        {locationName}
                        </span>
                      </Link>
                    ) : (
                      <div className="detail-items">
                      <img src="/assets/image/venue.png" alt="Venue" className="match-banner__detail-icon" />
                      <span>
                        {locationName}

                      </span>
                      </div>
                    )}
                  </div>
                </div>

            </div>
          </div>
        </div>

        <div className="league-main-container-two">
            <div className='container-match-detail'>


          <div className='column-match-detail small  '>

            <div className="referee-card">
                <div className="referee-card__icon">
                  <img src="/assets/image/referee.png" alt="referee_icon" />
                 </div>
                <div className="referee-card__info">
                      <div className="referee-card__role">Referee</div>
                      <div className="referee-card__name">{referee}</div>
                </div>
            </div>

            <div className="cards-section__card">
  <div className="cards-section__card-header">
    <img src="/assets/image/goal_status.png" alt="Goal_status" />
    <div className="cards-section__card-title">Goal Status</div>
  </div>

  <div className="cards-section__divider"></div>

  <div className="cards-section__card-content">
    

    <div className="cards-section__card-item">
      <div className="cards-section__card-label">
        <img src="/assets/image/halftime.png" alt="Halftime" />
        <span>Halftime</span>
      </div>
      <span className="cards-section__card-value">
        <span> {firstPeriodHome} -  {firstPeriodAway} </span>
        </span>
    </div>

    <div className="cards-section__card-item">
      <div className="cards-section__card-label">
        <img src="/assets/image/fulltime.png" alt="Fulltime" />
        <span>Fulltime</span>
      </div>
      <span className="cards-section__card-value"> 
        <span>  {secondPeriodHome} -  {secondPeriodAway} </span>
        </span>
    </div>

    
  </div>
</div>

          </div>


          <div className='column-match-detail large'>
            
      <Oddsdata id={id} status={status} />

          </div>
        </div>




          <div className="game-status-row ">
            
          </div>

        </div>
      </div>



      {/* <Lineups  homeTeamIcon={homeTeamIcon} id={id} awayTeamIcon={awayTeamIcon}/> */}

    </>
  );

  /**
   * generate result html
   * @param {Object} fullStatus 
   * @param {Object} result 
   *  @param {string|number} time 
   * @returns {JSX.Element} 
   */
  function result(fullStatus, result, time) {
    fullStatus = JSON.parse(fullStatus);
    result = JSON.parse(result);
    time = LocalTime(time);

    // console.log("result", result);

    let displayResult;

    if (Array.isArray(result) && result.length === 0) {
      // If result is an empty array, set a placeholder
      displayResult = '-';
    } else if (result && result.home && result.away) {
      // If result contains scores, display them

      const resultHome = result.home;
      const resultAway = result.away;
      displayResult = `${resultHome} - ${resultAway}`;
    } else {
      // Default fallback
      displayResult = '-';
    }






    return (
      <div className="next-match-item">
        <h2 className="livedata-score">
          {new HtmlToReactParser().parse(displayResult)}
        </h2>
        <p className="matchscore">{fullStatus['long']}</p>
        
      </div>
    );
  }

  // function location(){

  //   return ( 

  //     <>

  //     </>
  //   );

  // }

  /**
   * generate team html
   * @param {Object} data 
   * @returns {JSX.Element} 
   */
  function team(data) {
    return (
      <div className="next-match-item">
        <div className="next-match-title">
          <div className="match-image">
            <img src={data['icon'] ? data['icon'] : defaultImage} className="small-images" alt={data['name']} width="70" height="70" onError={(e) => { e.target.src = defaultImage; }} loading="lazy" />
          </div>
          <h3 className="match-title">{data['display_name']}</h3>
        </div>
      </div>
    );
  }
}

export default GameScore;