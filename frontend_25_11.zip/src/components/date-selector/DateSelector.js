import React, { useRef, useState } from 'react';
import './DateSelector.css';

/**
 * Custom date selector
 * @param {Object} props 
 * @returns 
 */
export default function DateSelector({ days, selectedDate, setSelectedDate }) {
  // Open/close state for the custom dropdown
  const [open, setOpen] = useState(false);
  // Ref for the hidden native select element to keep it in sync
  const selectRef = useRef();

  // Find index of the currently selected date in the days array
  const selectedIndex = days.indexOf(selectedDate);

  // Handle native select change (hidden), update selectedDate state
  const handleSelectChange = e => {
    setSelectedDate(e.target.value);
  };

  // Handle selecting a date from the custom dropdown
  // Updates selectedDate and closes dropdown
  // Also synchronizes hidden select element value
  const handleDivSelect = dateStr => {
    setSelectedDate(dateStr);
    setOpen(false);
    if (selectRef.current) {
      selectRef.current.value = dateStr;
    }
  };

  // Keyboard handler to toggle dropdown open/close on Enter or Space key
  const handleDivKeyDown = (e) => {
    if (e.key === 'Enter' || e.key === ' ') {
      setOpen(prev => !prev);
    }
  };

  // Toggle dropdown open/close - used for click on mobile
  const toggleDropdown = () => {
    setOpen(prev => !prev);
  };

  // Go to previous date in the days array if available
  const goPrev = () => {
    if (selectedIndex > 0) {
      setSelectedDate(days[selectedIndex - 1]);
    }
  };

  // Go to next date in the days array if available
  const goNext = () => {
    if (selectedIndex >= 0 && selectedIndex < days.length - 1) {
      setSelectedDate(days[selectedIndex + 1]);
    }
  };

  return (
    <div className="bet-date-sel">
      {/* Previous date button */}
      <button
        className="game-button"
        type="button"
        onClick={goPrev}
        disabled={selectedIndex <= 0}
        aria-label="Previous Date"
        style={{ cursor: selectedIndex <= 0 ? 'not-allowed' : 'pointer' }}
      >
        &#9664;
      </button>

      {/* Hidden native select for accessibility and form support, kept in sync */}
      <select
        ref={selectRef}
        name="game-date"
        value={selectedDate}
        onChange={handleSelectChange}
        style={{ display: 'none' }}
      >
        {days.map(dateStr => (
          <option key={dateStr} value={dateStr}>{dateStr}</option>
        ))}
      </select>

      {/* Visible custom dropdown box showing current selected date */}
      <div
        className="bet-date-sel-selector"
        tabIndex={0}                        // Allows focus for keyboard navigation
        role="button"                      // ARIA role for accessibility
        aria-haspopup="listbox"            // Indicates it controls a listbox
        aria-expanded={open}               // Indicates open/closed state
        onMouseEnter={() => setOpen(true)} // Open dropdown on hover (desktop)
        onMouseLeave={() => setOpen(false)} // Close dropdown when mouse leaves (desktop)
        onClick={toggleDropdown}           // Toggle dropdown on click (mobile)
        onKeyDown={handleDivKeyDown}      // Keyboard accessibility (Enter, Space)
      >
        <span className="bet-date-sel-selector-text">{selectedDate}</span>
        <span
          className="bet-date-sel-selector-arrow"
          style={{ float: 'right', fontSize: '80%', color: '#666' }}
        >
          &#x25BC;
        </span>
      </div>

      {/* Next date button */}
      <button
        className="game-button"
        type="button"
        onClick={goNext}
        disabled={selectedIndex === -1 || selectedIndex >= days.length - 1}
        aria-label="Next Date"
        style={{ cursor: selectedIndex >= days.length - 1 ? 'not-allowed' : 'pointer' }}
      >
        &#9654;
      </button>

      {/* Dropdown list of all available dates, visible when open */}
      {open && (
        <div
          className="bet-date-sel-dropdown"
          role="listbox"                    // ARIA role for accessibility
          onMouseEnter={() => setOpen(true)} // Keep dropdown open when hovering over it (desktop)
          onMouseLeave={() => setOpen(false)} // Close dropdown when mouse leaves (desktop)
        >
          {days.map(dateStr => (
            <div
              className="bet-date-sel-dropdown-item"
              key={dateStr}
              role="option"                 // ARIA role for each option
              aria-selected={selectedDate === dateStr} // Current selection state
              onClick={() => handleDivSelect(dateStr)} // Set date on click
              onMouseEnter={(e) => {
                // Optional: Add hover effect for dropdown items
                e.currentTarget.style.backgroundColor = '#fafafa';
              }}
              onMouseLeave={(e) => {
                // Optional: Remove hover effect for dropdown items
                e.currentTarget.style.backgroundColor = '';
              }}
            >
              {dateStr}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}