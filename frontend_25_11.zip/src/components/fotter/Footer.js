import React from "react";
import "./Footer.css"; // optional if you have styles

const Footer = () => {
return ( 
<footer className="footer">
    <div className="footer__top">
        <img src="/bet-assets/site/image/common/logo.svg" alt="Betting Premier Logo" className="footer__logo" /> 
        {/* <nav className="footer__nav">
            <a href="/blog/">Latest</a>
            <a href="/football">Football</a> 
            <a href="/ice-hockey">Ice Hockey</a> 
            <a href="/baseball">Baseball</a> 
            <a href="/basketball">BasketBall</a> 
            <a href="/volleyball">VolleyBall</a> 
        </nav> */}
        <p className="footer__copyright">
            Copyright © {new Date().getFullYear()} BettingPremier
        </p>
    </div>

    <div className="footer__bottom">
    <p>
      18+ Only. Please gamble responsibly!{" "}
      <strong>
        BeGambleAware.org
      </strong>{" "}
      &nbsp; 18+ | Erlaubt (White-list) | Suchtrisiken | Hilfe unter buwei.de
      (ENG: Allowed (white list) | Risk of addiction | Help at buwei.de.)
    </p>
  </div>
</footer>


);
};

export default Footer;
