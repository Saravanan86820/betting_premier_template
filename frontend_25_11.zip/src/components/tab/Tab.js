import { Link } from "react-router-dom";
import React from 'react';
import './Tab.css';

export default function Tab(props) {
  const items = props.items;

  return (
    <div className="bet-tab">
      {items.map((item, index) => (
        <div
          className="bet-tab-item"
          key={index}
        >
          <Link
            to={item.link}
            className="bet-tab-item-link"
            {...(item.active ? { 'data-active': '' } : {})}
          >
            {item.name}
          </Link>
        </div>
      ))}
    </div>
  );
}