import React, { useState, useEffect } from "react";
import './NewTopLeagues.css';
import { useLocation, Link } from 'react-router-dom';

const Topleagues = () => {
    const location = useLocation();
    const slug = location.pathname.split("/")[1];
    const dynamicSlug = slug || "football";

    const [leagueData, setLeagueData] = useState([]);
    const [error, setError] = useState('');

    // Map sport slugs to API endpoints
    const sportEndpoints = {
        'football': 'top-leagues-football',
        'ice-hockey': 'top-leagues-ice-hockey', 
        'baseball': 'top-leagues-baseball',
        'basketball': 'top-leagues-basketball',
        'volleyball': 'top-leagues-volleyball',
        'rugby': 'top-leagues-rugby',
        'handball': 'top-leagues-handball'
    };

    useEffect(() => {
        const endpoint = sportEndpoints[dynamicSlug];
        
        if (!endpoint) {
            setError('Sport not supported');
            return;
        }

        fetch(`/api/widget/${endpoint}`, { method: 'POST' })
            .then(response => response.json())
            .then(json => {
                if (json.status === "true" && json.data) {
                    const targetData = json.data.find((item) => item.name === endpoint);

                    if (targetData && targetData.data) {
                        const parsedData = JSON.parse(targetData.data);
                        setLeagueData(parsedData);
                    } else {
                        setError("Invalid data format or missing data.");
                    }
                } else {
                    setError("API response error.");
                }
            })
            .catch(err => {
                console.error('Error fetching league data:', err);
                setError('Error fetching data');
            });
    }, [dynamicSlug]);

    return (
        <div className="top-leagues-section" id="top-league">
            <div className="top-leagues-section__header">
                <h2>Top Leagues</h2>
                <div className="top-leagues-section__divider"></div>
            </div>

            <div className="top-leagues-section__top-leagues">
                {leagueData.map((league, index) => (
                    <div key={index} className="top-leagues-section__league">
                        <Link to={league.link}>
                            <img 
                                src={league.icon} 
                                alt={league.alt} 
                                className={`top-leagues-section__league-logo ${dynamicSlug}`}
                                loading="lazy" 
                            />
                            <span className="top-leagues-section__league-name">
                                {league.league_name}
                            </span>
                        </Link>
                    </div>
                ))}
            </div>
        </div>
    );
};

export default Topleagues;