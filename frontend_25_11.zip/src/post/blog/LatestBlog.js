import React, { useEffect, useState } from 'react';
import { useLocation } from 'react-router-dom';

import SkeletonRecentBlog from '../../pages/loader/SkeletonRecentPost';
// import ConfigUrl from './ConfigUrl';


function LatestBlog() {

    
    const location = useLocation();
    const slug = location.pathname.split("/")[1]; 
    const dynamicSlug = slug || "";

    const [posts, setPosts] = useState([]);
    const [error, setError] = useState('');
    const [loading, setLoading] = useState(true);


    useEffect(() => {
        const fetchPost = async () => {
            try {

                const apiUrl = dynamicSlug === ""     // home page → no slug
                        ? `/blog/wp-json/custom/v10/posts`
                        : `/blog/wp-json/custom/v10/posts?category=${dynamicSlug}`;

                const response = await fetch(apiUrl);
                const jsonresult = await response.json();

                if (response.ok) {
                    const limitedPosts = jsonresult.slice(0, 4); // Limit to 4 posts
                    setPosts(limitedPosts); 
                
                    // console.log(jsonresult);
                } else {
                    setError('Failed to fetch posts'); // Handle unsuccessful response
                    console.log('Error:', jsonresult);
                }

                setLoading(false); 
            } catch (err) {
                setError('An error occurred while fetching data'); // Catch and handle network or other errors
                console.error('Error:', err);
                setLoading(false);
            }
        };

        fetchPost();
    }, [dynamicSlug]);


    return (

        <>
            <div className="news-section"  id="recent-blog-home-top">
                <div className="news-section__header">

                    <h2>
                        {dynamicSlug === "" ? "Recent Blog" : `${dynamicSlug} News`}
                    </h2>
                    <div class="news-section__divider"></div>
                </div>
                {error && <p className="error-message">{error}</p>}
                {loading ? (
                    <SkeletonRecentBlog />
                ) : (
                <div class="news-section__news">
                    {posts.map((post) => {
                                  const category =
                                  post.categories && post.categories.length > 0
                                    ? post.categories[0]
                                    : { name: 'Unknown' };
                                const categoryName = category.name;
                                const categoryUrl = category.url;
                                const imageUrl = post.featured_image_url || undefined; 
                                return (
                                    <a href={post.link}  key={post.id} > 
                        <div class="news-section__news-card">
                            
                                <div class="news-section__news-image">
                                    <img src={imageUrl} alt={post.title} className="blog-images-top" width="90"  height="80" loading="lazy"/>
                                </div>
                                <div class="news-section__news-content">
                                    <p class="news-section__news-date">{post.date}</p>
                                    <h3 className="news-section__news-title">   {categoryName}   </h3>
                                    <h2 className="news-section__news-desc">  
                                {post.title}
                             </h2>

                                </div>
                            
                        </div>
                        </a>
                          );
                    })}
                  



                </div>
                )}
            </div>


        </>
    );
}

export default LatestBlog;