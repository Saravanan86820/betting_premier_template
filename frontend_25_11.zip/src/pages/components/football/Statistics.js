import React, { useEffect, useState } from 'react';
import '../Components.css';

function Statistics({ id }) {

    const [stats, setStats] = useState(null);  // Defaulting to an empty array
    const [loading, setLoading] = useState(false);

    const lineupAPI = `/api/sports/football/game/${id}/stats`;

    useEffect(() => {
        fetch(lineupAPI, { method: 'POST' })
            .then(response => response.json())
            .then(respData => {
                // Check if json.data[2] exists and has the correct structure
                let statsdata = null;

                if (respData['status'] !== 'true') {
                    return;
                }

                if (typeof respData['data'] !== 'object' || Object.keys(respData['data']).length === 0) {
                    return;
                }


                respData = respData['data'];
                for (const key in respData) {
                    if (!Object.prototype.hasOwnProperty.call(respData, key)) continue;
                    const item = respData[key];

                    if (item['type'] !== 'statistics') continue;
                   // console.log("item", item);
                    statsdata = item;
                    setLoading(true);
                }

                //  console.log(typeof statsdata);
                const statisticdata = statsdata ? JSON.parse(statsdata.data) : null; // Ensure it's an array
                //    console.log("statisticdata", statisticdata);

                //   console.log("API response:", json);
                // console.log("lineupdata", statsdata);

                setStats(statisticdata);  // Update lineups state
                setLoading(false);
            })
            .catch(err => {
                // console.error('Error fetching lineups:', err);
                setLoading(false);
            });
    }, [id]);

    if (loading) {
        return <div>Loading statistics...</div>;
    }

    if (!stats || !stats[0]['team'] || Object.keys(stats).length === 0) return null;


    // Organize players by rows
    const homeTeam = stats && stats[0];
    const awayTeam = stats && stats[1];

  //  console.log("homeTeam", homeTeam.statistics);
   // console.log("awayTeam", awayTeam.statistics);


    return (

        <>



            <div className="Statistics-container-main">

                {homeTeam.statistics.map((stat, index) => {
                      const home_Value = stat.value || 0;
                      const away_Value = awayTeam.statistics[index]?.value || 0;


                    const homecount = parseInt(stat.value || 0);
                    const awaycount = parseInt(awayTeam.statistics[index]?.value || 0);
                    const total = homecount + awaycount;

                    const homePercentage = total ? (homecount / total) * 100 : 0;
                    const awayPercentage = total ? (awaycount / total) * 100 : 0;

                    return ( 

                        <div className="Statistics-container" key={index}>

                            <div className="Statistics-row">
                                <div className="Statistics-row-list left-row">
                                    <span className="statistics-progess">{home_Value || 0}</span>
                                </div>
                                <div className="Statistics-row-list">
                                    <span>{stat.type}</span>
                                </div>
                                <div className="Statistics-row-list right-row">
                                    <span className="statistics-progess">{away_Value || 0}</span>
                                </div>
                            </div>


                            <div className="statistics_row">
                                <div className="statistics_row-list">
                                    <progress id="file-left" value={homePercentage} max="100"></progress>
                                </div>
                                <div className="statistics_row-list">
                                    <progress id="file-right" value={awayPercentage} max="100"></progress>
                                </div>
                            </div>

                        </div>

                    );
                })}


            </div>

        </>
    );
}

export default Statistics;