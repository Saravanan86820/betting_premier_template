import React from "react";

// import FeatureMatch from "../../sidebar/FeaturedMatch";
import Topleagues from "../../sidebar/Topleagues";
import Alleagues from "../../sidebar/Alleagues";
import Add from "../../sidebar/Add";
import LatestBlog from "../../post/blog/LatestBlog";


// import Scorematch from "../../pages/home/Scorematch";
import HomeBlog from "../../pages/home/HomeBlog";
// import HomeGame from "../../pages/home/HomeGame";
import Livescore from "../../pages/home/Livescore";
// import Scorematch, { ScorematchB, ScorematchC, ScorematchD } from "./Scorematch";
//  import ScoreLeagueone from "./ScoreLeagueone";
import ScoreLopp from "./ScoreLopp";
import NewTopLeagues from "../../sidebar/NewTopLeagues";
// import AllCountry from "../../sidebar/AllCountry";

function Scorelist() {

  const leagues = {};

  return (

    <>
      <div className="container-scorelist">
        <div className="container-score">

          <div className="column-score large">

            <HomeBlog />
            {/* <Livescore /> */}
            <ScoreLopp />
            {/* <HomeGame/> */}

            {/* <ScoreLeagueone/> */}
            {/* <Scorematch />

            <ScorematchB />
            <ScorematchC />
            <ScorematchD /> */}

          </div>

          <div className="column-score small">

            <div className="container-slide">
              <Add />
              <LatestBlog />
              {/* <FeatureMatch /> */}
              {/* <NewTopLeagues sports="football" /> */}
              {/* <Alleagues /> */}

            </div>

          </div>
        </div>
      </div>
    </>
  );
}

export default Scorelist;