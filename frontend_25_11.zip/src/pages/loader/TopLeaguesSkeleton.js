import React from "react";
import "./Loader.css";

const TopLeaguesSkeleton = () => {
  return (
    <div className="bet-top-leagues-skeleton">
      
      <div className="tls-grid">
        {[1, 2, 3, 4, 5].map((item) => (
          <div className="tls-card" key={item}>
            <div className="tls-logo"></div>
            <div className="tls-title"></div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default TopLeaguesSkeleton;
