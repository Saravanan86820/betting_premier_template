import React from "react";
import "./Loader.css";

export default function SkeletonLeagueStand() {
  return (
    <div className="bet-skeleton-league-page bet-skeleton-wrap">


        {/* Standings Section */}
        <div className="bet-card-skeleton">
          <div className="bet-card-title bet-skeleton-line"></div>

          {[1, 2, 3, 4, 5, 6, 7, 8].map((i) => (
            <div className="bet-standing-row-skeleton" key={i}>
              <div className="bet-row-circle bet-skeleton-logo"></div>
              <div className="bet-row-team-name bet-skeleton-line"></div>

              <div className="bet-row-small bet-skeleton-line"></div>
              <div className="bet-row-small bet-skeleton-line"></div>
              <div className="bet-row-small bet-skeleton-line"></div>

              <div className="bet-form-box bet-skeleton-line"></div>
            </div>
          ))}
        </div>

    </div>
  );
}
