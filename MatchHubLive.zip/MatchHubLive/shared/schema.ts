import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, timestamp, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Sports and Leagues types
export type SportType = 'football' | 'ice-hockey' | 'baseball' | 'basketball' | 'volleyball' | 'rugby' | 'handball';
export type LeagueType = 'MLB' | 'NHL' | 'NBA' | 'NFL' | 'Premier League' | 'La Liga' | 'Serie A' | 'Bundesliga' | 'Champions League';
export type MatchStatus = 'live' | 'upcoming' | 'finished';

// Match Schema
export interface Match {
  id: string;
  sport: SportType;
  league: LeagueType;
  homeTeam: string;
  awayTeam: string;
  homeTeamLogo: string;
  awayTeamLogo: string;
  homeScore: number | null;
  awayScore: number | null;
  status: MatchStatus;
  matchTime: string;
  liveMinute?: string;
}

export const insertMatchSchema = z.object({
  sport: z.enum(['football', 'ice-hockey', 'baseball', 'basketball', 'volleyball', 'rugby', 'handball']),
  league: z.string(),
  homeTeam: z.string(),
  awayTeam: z.string(),
  homeTeamLogo: z.string(),
  awayTeamLogo: z.string(),
  homeScore: z.number().nullable(),
  awayScore: z.number().nullable(),
  status: z.enum(['live', 'upcoming', 'finished']),
  matchTime: z.string(),
  liveMinute: z.string().optional(),
});

export type InsertMatch = z.infer<typeof insertMatchSchema>;

// Blog Post Schema
export interface BlogPost {
  id: string;
  sport: SportType;
  title: string;
  description: string;
  thumbnail: string;
  postedDate: string;
}

export const insertBlogPostSchema = z.object({
  sport: z.enum(['football', 'ice-hockey', 'baseball', 'basketball', 'volleyball', 'rugby', 'handball']),
  title: z.string(),
  description: z.string(),
  thumbnail: z.string(),
  postedDate: z.string(),
});

export type InsertBlogPost = z.infer<typeof insertBlogPostSchema>;

// Sport Category
export interface SportCategory {
  id: SportType;
  name: string;
  icon: string;
}

// League Category
export interface LeagueCategory {
  id: string;
  name: LeagueType;
  sport: SportType;
}
