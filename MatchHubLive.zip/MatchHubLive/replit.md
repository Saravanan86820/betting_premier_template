# BettingPremier – Live Sports Score & Match Hub

## Overview
BettingPremier is a modern, animated sports score tracking website designed to provide real-time match updates, scores, and sports news across multiple sports. Built with a focus on exceptional visual quality and smooth user experience.

**Current Status**: MVP Complete ✅
- All core features implemented and tested
- Beautiful dark/light mode theming
- Responsive design (mobile, tablet, desktop)
- End-to-end tested with 23/23 test cases passing

## Project Architecture

### Frontend Stack
- **Framework**: React + TypeScript + Vite
- **Routing**: Wouter
- **Styling**: Tailwind CSS + Shadcn UI components
- **Animations**: Framer Motion
- **Data Fetching**: TanStack React Query
- **State Management**: React hooks

### Backend Stack
- **Runtime**: Node.js + Express
- **Storage**: In-memory storage (MemStorage)
- **Validation**: Zod schemas
- **API**: REST endpoints with filtering

### Design System
**Dark Mode** (Default):
- Background: #0E141B (217 25% 11%)
- Primary Highlight: #1E90FF (210 100% 56%)
- Accent: #00FFC6 (170 100% 50%)

**Light Mode**:
- Background: #F8F9FB (220 20% 98%)
- Primary: #0056FF (217 100% 35%)
- Accent: #FF8C00 (30 100% 50%)

**Typography**: Poppins (primary), Inter, Montserrat
**Border Radius**: 12-16px for cards
**Animations**: 250-300ms sidebar, 200ms header, 150ms card hover

## Features

### Core Functionality
1. **Hero Banner** - Eye-catching carousel with featured sports, auto-rotating every 5 seconds
2. **Sports Navigation** - 7 sports supported:
   - ⚽ Football
   - 🏒 Ice Hockey
   - ⚾ Baseball
   - 🏀 Basketball
   - 🏐 Volleyball
   - 🏉 Rugby
   - 🤾 Handball

3. **Major Leagues** - Quick access to:
   - MLB (Baseball)
   - NHL (Ice Hockey)
   - NBA (Basketball)
   - NFL (Football)

4. **Match Filtering**:
   - All matches
   - Live matches (with real-time minute indicators)
   - Upcoming matches

5. **Blog Section** - Sport-filtered news with thumbnails and dates
6. **Dark/Light Mode** - Smooth theme transitions with persistent preference
7. **Responsive Sidebar** - Collapsible icon mode (desktop), drawer mode (mobile)

### API Endpoints

#### Matches
```
GET /api/matches?sport={sport}&status={status}
```
- `sport` (required): football, ice-hockey, baseball, basketball, volleyball, rugby, handball
- `status` (optional): live, upcoming, finished

#### Blog Posts
```
GET /api/blog?sport={sport}
```
- `sport` (required): Same options as matches

## Component Structure

```
client/src/
├── components/
│   ├── app-sidebar.tsx         # Shadcn sidebar with sports/leagues
│   ├── hero-banner.tsx         # Featured sports carousel
│   ├── header.tsx              # Sticky header with search & theme toggle
│   ├── main-content.tsx        # Match cards and filtering tabs
│   ├── match-card.tsx          # Individual match display
│   ├── match-card-skeleton.tsx # Loading state for matches
│   ├── blog-section.tsx        # Right column news feed
│   ├── theme-provider.tsx      # Dark/light mode management
│   └── ui/                     # Shadcn components
├── pages/
│   ├── home.tsx                # Main landing page
│   └── not-found.tsx           # 404 page
└── App.tsx                     # Root component with providers

server/
├── routes.ts                   # API endpoints
├── storage.ts                  # In-memory data storage with seed data
└── index.ts                    # Express server setup

shared/
└── schema.ts                   # TypeScript types and Zod schemas
```

## Recent Changes (October 15, 2025)

### Implementation
- ✅ Replaced custom sidebar with Shadcn sidebar primitives
- ✅ Added hero banner with auto-rotating sports carousel
- ✅ Fixed design tokens (border-radius 12-16px)
- ✅ Implemented Lucide React icons throughout
- ✅ Built complete API with realistic seed data
- ✅ Integrated React Query for data fetching
- ✅ Added beautiful loading states with skeletons
- ✅ Implemented smooth animations with Framer Motion

### Testing
- ✅ E2E tests passed (23/23 verification steps)
- ✅ Responsive behavior verified across breakpoints
- ✅ Dark/light mode transitions tested
- ✅ All sport and league filtering working
- ✅ Tab filtering (All/Live/Upcoming) verified

### Known Minor Issues
- Mobile drawer overlay occasionally blocks theme toggle (workaround: press Escape to close drawer)

## Development

### Running the Project
```bash
npm run dev
```
Access at: http://localhost:5000

### Key Commands
- `npm run dev` - Start development server
- TypeScript type checking is built into the workflow

## Future Enhancements
1. Real-time API integration for live scores
2. User accounts with favorite teams
3. Match notifications and alerts
4. Detailed match statistics pages
5. Social sharing features
6. Betting odds display (if applicable)
7. Advanced search with autocomplete
8. Performance optimizations for large datasets

## User Preferences
- Default theme: Dark mode
- Default sport: Football
- Sidebar: Collapsible with icon mode
- Animations: Enabled (smooth transitions)

## Technical Notes
- Uses in-memory storage (data resets on server restart)
- Seed data includes realistic matches across all sports
- Blog posts auto-filter based on selected sport
- Theme preference persists in localStorage
- Responsive breakpoints: mobile (<768px), tablet (768-1024px), desktop (>1024px)
