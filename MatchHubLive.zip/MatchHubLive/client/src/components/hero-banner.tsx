import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { ChevronRight, Trophy } from "lucide-react";
import { useState, useEffect } from "react";
import type { SportType } from "@shared/schema";

interface HeroBannerProps {
  onExploreLive: () => void;
  onSelectSport: (sport: SportType) => void;
}

const featuredSports = [
  { name: "Football", sport: "football" as SportType, image: "https://images.unsplash.com/photo-1574629810360-7efbbe195018?w=800&h=400&fit=crop" },
  { name: "Basketball", sport: "basketball" as SportType, image: "https://images.unsplash.com/photo-1546519638-68e109498ffc?w=800&h=400&fit=crop" },
  { name: "Baseball", sport: "baseball" as SportType, image: "https://images.unsplash.com/photo-1566577739112-5180d4bf9390?w=800&h=400&fit=crop" },
  { name: "Ice Hockey", sport: "ice-hockey" as SportType, image: "https://images.unsplash.com/photo-1515703407324-5f753afd8be8?w=800&h=400&fit=crop" },
];

export function HeroBanner({ onExploreLive, onSelectSport }: HeroBannerProps) {
  const [currentIndex, setCurrentIndex] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % featuredSports.length);
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="relative h-[400px] overflow-hidden rounded-lg mb-8">
      {featuredSports.map((sport, index) => (
        <motion.div
          key={sport.name}
          initial={false}
          animate={{
            opacity: index === currentIndex ? 1 : 0,
            scale: index === currentIndex ? 1 : 1.1,
          }}
          transition={{ duration: 0.7, ease: "easeInOut" }}
          className="absolute inset-0"
        >
          <div className="relative h-full w-full">
            <img
              src={sport.image}
              alt={sport.name}
              className="h-full w-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-r from-black/80 via-black/50 to-transparent" />
          </div>
        </motion.div>
      ))}

      <div className="relative z-10 flex h-full flex-col justify-center px-8 md:px-12 lg:px-16">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2, duration: 0.6 }}
        >
          <div className="flex items-center gap-2 mb-4">
            <Trophy className="h-8 w-8 text-primary" />
            <span className="text-sm font-semibold text-primary uppercase tracking-wider">
              Live Sports Coverage
            </span>
          </div>
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-4 max-w-2xl">
            Track every goal, every play — live with BettingPremier.
          </h1>
          <p className="text-lg md:text-xl text-gray-200 mb-8 max-w-xl">
            Real-time scores, match updates, and sports news for all your favorite teams and leagues.
          </p>
          <div className="flex flex-wrap gap-4">
            <Button 
              size="lg"
              onClick={onExploreLive}
              className="bg-primary text-primary-foreground hover:bg-primary/90"
              data-testid="button-explore-live"
            >
              Explore Live Matches
              <ChevronRight className="ml-2 h-5 w-5" />
            </Button>
          </div>
        </motion.div>
      </div>

      <div className="absolute bottom-6 right-6 z-20 flex gap-2">
        {featuredSports.map((_, index) => (
          <button
            key={index}
            onClick={() => setCurrentIndex(index)}
            className={cn(
              "h-2 rounded-full transition-all duration-300",
              index === currentIndex ? "w-8 bg-primary" : "w-2 bg-white/50"
            )}
            data-testid={`button-carousel-${index}`}
          />
        ))}
      </div>

      <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-background/20 to-transparent h-24 z-10" />
    </div>
  );
}

function cn(...classes: (string | boolean | undefined)[]) {
  return classes.filter(Boolean).join(' ');
}
