import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useQuery } from "@tanstack/react-query";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { MatchCard } from "@/components/match-card";
import { MatchCardSkeleton } from "@/components/match-card-skeleton";
import type { Match, SportType } from "@shared/schema";

interface MainContentProps {
  selectedSport: SportType;
}

export function MainContent({ selectedSport }: MainContentProps) {
  const [filterTab, setFilterTab] = useState<"all" | "live" | "upcoming">("all");

  const { data: matches, isLoading } = useQuery<Match[]>({
    queryKey: ["/api/matches", selectedSport, filterTab],
    queryFn: async () => {
      const params = new URLSearchParams({ sport: selectedSport });
      if (filterTab !== "all") {
        params.append("status", filterTab);
      }
      const response = await fetch(`/api/matches?${params}`);
      if (!response.ok) throw new Error("Failed to fetch matches");
      return response.json();
    },
  });

  const sportNames: Record<SportType, string> = {
    "football": "Football",
    "ice-hockey": "Ice Hockey",
    "baseball": "Baseball",
    "basketball": "Basketball",
    "volleyball": "Volleyball",
    "rugby": "Rugby",
    "handball": "Handball",
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4 }}
    >
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl md:text-3xl font-bold">
          {sportNames[selectedSport]} Matches
        </h2>
      </div>

      <Tabs value={filterTab} onValueChange={(v) => setFilterTab(v as typeof filterTab)} className="mb-6">
        <TabsList className="grid w-full max-w-md grid-cols-3">
          <TabsTrigger value="all" data-testid="tab-all">All</TabsTrigger>
          <TabsTrigger value="live" data-testid="tab-live">Live</TabsTrigger>
          <TabsTrigger value="upcoming" data-testid="tab-upcoming">Upcoming</TabsTrigger>
        </TabsList>
      </Tabs>

      <AnimatePresence mode="wait">
        {isLoading ? (
          <motion.div
            key="loading"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="space-y-4"
          >
            {[...Array(4)].map((_, i) => (
              <MatchCardSkeleton key={i} />
            ))}
          </motion.div>
        ) : matches && matches.length > 0 ? (
          <motion.div
            key="matches"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="space-y-4"
          >
            {matches.map((match, index) => (
              <motion.div
                key={match.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.05, duration: 0.3 }}
              >
                <MatchCard match={match} />
              </motion.div>
            ))}
          </motion.div>
        ) : (
          <motion.div
            key="empty"
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            className="flex flex-col items-center justify-center py-12 text-center"
          >
            <div className="rounded-full bg-muted p-6 mb-4">
              <svg
                className="h-12 w-12 text-muted-foreground"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
                />
              </svg>
            </div>
            <h3 className="text-xl font-semibold mb-2">No Matches Found</h3>
            <p className="text-muted-foreground max-w-md">
              There are no {filterTab === "all" ? "" : filterTab} matches available for {sportNames[selectedSport]} at the moment.
            </p>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}
