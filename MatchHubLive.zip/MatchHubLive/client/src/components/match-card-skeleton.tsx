import { Card } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";

export function MatchCardSkeleton() {
  return (
    <Card className="overflow-hidden">
      <div className="p-4 md:p-6">
        <div className="flex items-center justify-between mb-4">
          <Skeleton className="h-5 w-16" />
          <Skeleton className="h-4 w-24" />
        </div>

        <div className="grid grid-cols-[1fr_auto_1fr] gap-4 items-center">
          <div className="flex flex-col items-center text-center">
            <Skeleton className="mb-3 h-16 w-16 rounded-full" />
            <Skeleton className="h-4 w-24" />
          </div>

          <div className="flex flex-col items-center gap-2">
            <Skeleton className="h-10 w-20" />
          </div>

          <div className="flex flex-col items-center text-center">
            <Skeleton className="mb-3 h-16 w-16 rounded-full" />
            <Skeleton className="h-4 w-24" />
          </div>
        </div>
      </div>
    </Card>
  );
}
