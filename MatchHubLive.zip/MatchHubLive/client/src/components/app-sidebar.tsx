import { motion } from "framer-motion";
import { 
  Sidebar, 
  SidebarContent, 
  SidebarGroup, 
  SidebarGroupContent, 
  SidebarGroupLabel, 
  SidebarMenu, 
  SidebarMenuButton, 
  SidebarMenuItem 
} from "@/components/ui/sidebar";
import { Circle, Trophy, Target, Dumbbell, Network, Shield, Hand } from "lucide-react";
import { cn } from "@/lib/utils";
import type { SportType } from "@shared/schema";

interface AppSidebarProps {
  selectedSport: SportType;
  onSelectSport: (sport: SportType) => void;
}

const sports = [
  { id: "football" as SportType, name: "Football", icon: Circle },
  { id: "ice-hockey" as SportType, name: "Ice Hockey", icon: Target },
  { id: "baseball" as SportType, name: "Baseball", icon: Trophy },
  { id: "basketball" as SportType, name: "Basketball", icon: Dumbbell },
  { id: "volleyball" as SportType, name: "Volleyball", icon: Network },
  { id: "rugby" as SportType, name: "Rugby", icon: Shield },
  { id: "handball" as SportType, name: "Handball", icon: Hand },
];

const leagues = [
  { id: "mlb", name: "MLB", sport: "baseball" as SportType },
  { id: "nhl", name: "NHL", sport: "ice-hockey" as SportType },
  { id: "nba", name: "NBA", sport: "basketball" as SportType },
  { id: "nfl", name: "NFL", sport: "football" as SportType },
];

export function AppSidebar({ selectedSport, onSelectSport }: AppSidebarProps) {
  return (
    <Sidebar collapsible="icon">
      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupLabel>Sports</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {sports.map((sport) => (
                <SidebarMenuItem key={sport.id}>
                  <SidebarMenuButton
                    onClick={() => onSelectSport(sport.id)}
                    isActive={selectedSport === sport.id}
                    data-testid={`button-sport-${sport.id}`}
                    className="transition-all duration-200"
                  >
                    <motion.div
                      animate={{ 
                        filter: selectedSport === sport.id 
                          ? "drop-shadow(0 0 8px rgba(59, 130, 246, 0.5))" 
                          : "none"
                      }}
                      transition={{ duration: 0.3 }}
                    >
                      <sport.icon className="h-5 w-5" />
                    </motion.div>
                    <span>{sport.name}</span>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        <SidebarGroup>
          <SidebarGroupLabel>Major Leagues</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {leagues.map((league) => (
                <SidebarMenuItem key={league.id}>
                  <SidebarMenuButton
                    onClick={() => onSelectSport(league.sport)}
                    isActive={selectedSport === league.sport}
                    data-testid={`button-league-${league.id}`}
                    className="transition-all duration-200"
                  >
                    <div className={cn(
                      "flex h-5 w-5 items-center justify-center rounded text-xs font-bold",
                      selectedSport === league.sport ? "bg-sidebar-primary text-sidebar-primary-foreground" : "bg-sidebar-accent text-sidebar-accent-foreground"
                    )}>
                      {league.name.slice(0, 2)}
                    </div>
                    <span>{league.name}</span>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>
    </Sidebar>
  );
}
