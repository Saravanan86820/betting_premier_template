import { motion } from "framer-motion";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Clock } from "lucide-react";
import { cn } from "@/lib/utils";
import type { Match } from "@shared/schema";

interface MatchCardProps {
  match: Match;
}

export function MatchCard({ match }: MatchCardProps) {
  const isLive = match.status === "live";
  const isUpcoming = match.status === "upcoming";
  const isFinished = match.status === "finished";

  return (
    <motion.div
      whileHover={{ scale: 1.01 }}
      transition={{ duration: 0.2 }}
      data-testid={`card-match-${match.id}`}
    >
      <Card className="overflow-hidden hover-elevate active-elevate-2">
        <div className="p-4 md:p-6">
          <div className="flex items-center justify-between mb-4">
            <Badge 
              variant={isLive ? "default" : "secondary"}
              className={cn(
                "font-medium",
                isLive && "bg-primary text-primary-foreground animate-pulse"
              )}
              data-testid={`badge-status-${match.id}`}
            >
              {isLive && match.liveMinute ? `${match.liveMinute}'` : match.status.toUpperCase()}
            </Badge>
            <span className="text-sm text-muted-foreground" data-testid={`text-league-${match.id}`}>
              {match.league}
            </span>
          </div>

          <div className="grid grid-cols-[1fr_auto_1fr] gap-4 items-center">
            <div className="flex flex-col items-center text-center">
              <div className="mb-3 flex h-16 w-16 items-center justify-center rounded-full bg-muted overflow-hidden">
                <img
                  src={match.homeTeamLogo}
                  alt={match.homeTeam}
                  className="h-12 w-12 object-contain"
                  data-testid={`img-home-logo-${match.id}`}
                />
              </div>
              <h3 className="font-semibold text-sm md:text-base" data-testid={`text-home-team-${match.id}`}>
                {match.homeTeam}
              </h3>
            </div>

            <div className="flex flex-col items-center gap-2">
              {!isUpcoming && match.homeScore !== null && match.awayScore !== null ? (
                <div className="flex items-center gap-3">
                  <motion.span
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    className="text-3xl md:text-4xl font-bold"
                    data-testid={`text-home-score-${match.id}`}
                  >
                    {match.homeScore}
                  </motion.span>
                  <span className="text-2xl text-muted-foreground">-</span>
                  <motion.span
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    className="text-3xl md:text-4xl font-bold"
                    data-testid={`text-away-score-${match.id}`}
                  >
                    {match.awayScore}
                  </motion.span>
                </div>
              ) : (
                <div className="flex items-center gap-2 text-muted-foreground">
                  <Clock className="h-4 w-4" />
                  <span className="text-sm font-medium" data-testid={`text-match-time-${match.id}`}>
                    {match.matchTime}
                  </span>
                </div>
              )}
            </div>

            <div className="flex flex-col items-center text-center">
              <div className="mb-3 flex h-16 w-16 items-center justify-center rounded-full bg-muted overflow-hidden">
                <img
                  src={match.awayTeamLogo}
                  alt={match.awayTeam}
                  className="h-12 w-12 object-contain"
                  data-testid={`img-away-logo-${match.id}`}
                />
              </div>
              <h3 className="font-semibold text-sm md:text-base" data-testid={`text-away-team-${match.id}`}>
                {match.awayTeam}
              </h3>
            </div>
          </div>
        </div>
      </Card>
    </motion.div>
  );
}
