import { useState, useRef } from "react";
import { SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar";
import { AppSidebar } from "@/components/app-sidebar";
import { Header } from "@/components/header";
import { HeroBanner } from "@/components/hero-banner";
import { MainContent } from "@/components/main-content";
import { BlogSection } from "@/components/blog-section";
import type { SportType } from "@shared/schema";

export default function Home() {
  const [selectedSport, setSelectedSport] = useState<SportType>("football");
  const [showHero, setShowHero] = useState(true);
  const contentRef = useRef<HTMLDivElement>(null);

  const handleExploreLive = () => {
    setShowHero(false);
    contentRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  const sidebarStyle = {
    "--sidebar-width": "16rem",
    "--sidebar-width-icon": "3rem",
  };

  return (
    <SidebarProvider style={sidebarStyle as React.CSSProperties}>
      <div className="flex h-screen w-full">
        <AppSidebar 
          selectedSport={selectedSport}
          onSelectSport={setSelectedSport}
        />
        
        <div className="flex flex-1 flex-col overflow-hidden">
          <Header />
          
          <div className="flex flex-1 overflow-hidden">
            <main className="flex-1 overflow-y-auto">
              <div className="container mx-auto py-6 px-4 md:px-6 max-w-7xl">
                {showHero && (
                  <HeroBanner 
                    onExploreLive={handleExploreLive}
                    onSelectSport={(sport) => {
                      setSelectedSport(sport);
                      setShowHero(false);
                    }}
                  />
                )}
                <div ref={contentRef}>
                  <MainContent selectedSport={selectedSport} />
                </div>
              </div>
            </main>
            
            <BlogSection selectedSport={selectedSport} />
          </div>
        </div>
      </div>
    </SidebarProvider>
  );
}
