# BettingPremier Design Guidelines

## Design Approach
**Reference-Based Approach**: Drawing inspiration from sofascore.com and flashscore.com, but elevating with creative animations, sleek modern UI, and superior visual appeal.

## Core Architecture

### Layout System: 3-Column Structure
- **Header**: Sticky top bar (always visible)
- **Left Sidebar**: Expandable/collapsible navigation (icons only when collapsed, icons + labels when expanded)
- **Main Content**: Dynamic match display center column
- **Right Column**: Sport-filtered blog/news section

### Spacing System
Use Tailwind units: 2, 3, 4, 6, 8, 12, 16 for consistent rhythm throughout

## Color Palette

### Dark Mode (Primary)
- Background: `217 25% 11%` (#0E141B)
- Highlight/Accent: `170 100% 50%` (#00FFC6) or `210 100% 56%` (#1E90FF)
- Card backgrounds: Lighter shades of background
- Text: White/off-white

### Light Mode
- Background: `220 20% 98%` (#F8F9FB)
- Accent: `217 100% 35%` (#0056FF) or `30 100% 50%` (#FF8C00)
- Card backgrounds: Pure white
- Text: Dark gray/black

**Mode Switching**: Implement smooth color transitions (300-400ms ease) between modes

## Typography
- **Font Families**: Poppins (primary), Inter, or Montserrat
- **Hierarchy**:
  - Headers: 24-32px, font-semibold
  - Subheaders: 18-20px, font-medium
  - Body: 14-16px, font-normal
  - Small text: 12-14px

## Component Library

### Header Components
- Logo with sports-themed icon
- Website title "BettingPremier" (prominent)
- Centered/right-aligned search bar
- Dark/light mode toggle
- Smooth slide-in animation on scroll

### Sidebar Navigation
- Toggle button with ">" icon
- **Collapsed**: Icons only (48px width)
- **Expanded**: Icons + sport names (200-240px width)
- Sports categories: Football ⚽, Ice Hockey 🏒, Baseball ⚾, Basketball 🏀, Volleyball 🏐, Rugby 🏉, Handball 🤾
- Major leagues: MLB, NHL, NBA, NFL
- Glowing hover effect on icons
- Smooth sliding animation (250-300ms)

### Match Cards
- Border-radius: 12-16px
- Soft shadows with subtle gradients
- Contains:
  - Team logos (circular or square)
  - Team names
  - Match time/live status indicator
  - League name badge
  - Score (live/completed matches)
- Hover animations: slight elevation, glow effect

### Blog Section Cards
- Thumbnail image (16:9 ratio)
- Headline (bold, 16-18px)
- Short description (2-3 lines)
- Posted date
- Auto-filters based on selected sport
- Scroll or carousel layout

### Tab System
- All | Live | Upcoming match filters
- Active tab highlighted with accent color
- Smooth transitions between states

## Animations & Interactions

### Key Animations
- Sidebar slide toggle (250-300ms ease-out)
- Header slide-in on scroll (200ms)
- Card hover effects: elevation + glow (150ms)
- Mode transition: color fade (300-400ms)
- Tab switching: fade + slide (200ms)

### Animation Libraries
Consider Framer Motion or GSAP for advanced animations

## Landing Page Elements

### Hero Section
- Eye-catching banner with live match highlights
- Tagline: "Track every goal, every play — live with BettingPremier."
- Prominent CTA button: "Explore Live Matches"
- Featured sports carousel below hero

### Content Sections
1. Live matches grid (priority display)
2. Upcoming matches schedule (Sofascore-inspired clean grid)
3. Featured sports carousel
4. Latest news/blogs preview

## Responsive Behavior
- **Mobile**: Single column, collapsible sidebar as drawer
- **Tablet**: 2-column (main + blog stacked)
- **Desktop**: Full 3-column layout
- Mobile-first design approach
- Clean spacing, no clutter

## Images
- **Team Logos**: Required for all match cards
- **Blog Thumbnails**: 16:9 ratio images for all news items
- **Hero Banner**: Dynamic sports action imagery or live match highlights
- **Sport Category Icons**: Emoji or custom icons for each sport

## Technical Notes
- Fully responsive grid system
- Support for future API integration (live scores)
- TailwindCSS or Chakra UI recommended for consistency
- Searchable content (matches, teams, leagues)
- Fast-loading, optimized performance