import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertMatchSchema, insertBlogPostSchema, type MatchStatus, type SportType } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Get matches - with optional sport and status filters
  app.get("/api/matches", async (req, res) => {
    try {
      const sport = req.query.sport as SportType | undefined;
      const status = req.query.status as MatchStatus | undefined;

      let matches;
      
      if (sport && status) {
        matches = await storage.getMatchesBySportAndStatus(sport, status);
      } else if (sport) {
        matches = await storage.getMatchesBySport(sport);
      } else {
        matches = await storage.getAllMatches();
      }

      res.json(matches);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch matches" });
    }
  });

  // Get blog posts by sport
  app.get("/api/blog", async (req, res) => {
    try {
      const sport = req.query.sport as SportType;
      
      if (!sport) {
        return res.status(400).json({ error: "Sport parameter is required" });
      }

      const posts = await storage.getBlogPostsBySport(sport);
      res.json(posts);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch blog posts" });
    }
  });

  // Create a new match (for future admin functionality)
  app.post("/api/matches", async (req, res) => {
    try {
      const validatedData = insertMatchSchema.parse(req.body);
      const match = await storage.createMatch(validatedData);
      res.status(201).json(match);
    } catch (error) {
      res.status(400).json({ error: "Invalid match data" });
    }
  });

  // Create a new blog post (for future admin functionality)
  app.post("/api/blog", async (req, res) => {
    try {
      const validatedData = insertBlogPostSchema.parse(req.body);
      const post = await storage.createBlogPost(validatedData);
      res.status(201).json(post);
    } catch (error) {
      res.status(400).json({ error: "Invalid blog post data" });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
