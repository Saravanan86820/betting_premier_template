import { type Match, type BlogPost, type SportType, type MatchStatus, type InsertMatch, type InsertBlogPost } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  getAllMatches(): Promise<Match[]>;
  getMatchesBySport(sport: SportType): Promise<Match[]>;
  getMatchesBySportAndStatus(sport: SportType, status: MatchStatus): Promise<Match[]>;
  getBlogPostsBySport(sport: SportType): Promise<BlogPost[]>;
  createMatch(match: InsertMatch): Promise<Match>;
  createBlogPost(post: InsertBlogPost): Promise<BlogPost>;
}

export class MemStorage implements IStorage {
  private matches: Map<string, Match>;
  private blogPosts: Map<string, BlogPost>;

  constructor() {
    this.matches = new Map();
    this.blogPosts = new Map();
    this.seedData();
  }

  private seedData() {
    // Seed Football matches
    const footballMatches: InsertMatch[] = [
      {
        sport: "football",
        league: "Premier League",
        homeTeam: "Manchester United",
        awayTeam: "Liverpool",
        homeTeamLogo: "https://api.dicebear.com/7.x/shapes/svg?seed=manutd&backgroundColor=da291c",
        awayTeamLogo: "https://api.dicebear.com/7.x/shapes/svg?seed=liverpool&backgroundColor=c8102e",
        homeScore: 2,
        awayScore: 1,
        status: "live",
        matchTime: "19:45",
        liveMinute: "67",
      },
      {
        sport: "football",
        league: "La Liga",
        homeTeam: "Real Madrid",
        awayTeam: "Barcelona",
        homeTeamLogo: "https://api.dicebear.com/7.x/shapes/svg?seed=realmadrid&backgroundColor=febe10",
        awayTeamLogo: "https://api.dicebear.com/7.x/shapes/svg?seed=barcelona&backgroundColor=a50044",
        homeScore: null,
        awayScore: null,
        status: "upcoming",
        matchTime: "21:00",
      },
      {
        sport: "football",
        league: "Champions League",
        homeTeam: "Bayern Munich",
        awayTeam: "PSG",
        homeTeamLogo: "https://api.dicebear.com/7.x/shapes/svg?seed=bayern&backgroundColor=dc052d",
        awayTeamLogo: "https://api.dicebear.com/7.x/shapes/svg?seed=psg&backgroundColor=004170",
        homeScore: 3,
        awayScore: 2,
        status: "finished",
        matchTime: "17:00",
      },
      {
        sport: "football",
        league: "Serie A",
        homeTeam: "AC Milan",
        awayTeam: "Inter Milan",
        homeTeamLogo: "https://api.dicebear.com/7.x/shapes/svg?seed=acmilan&backgroundColor=fb090b",
        awayTeamLogo: "https://api.dicebear.com/7.x/shapes/svg?seed=inter&backgroundColor=0068a8",
        homeScore: 1,
        awayScore: 1,
        status: "live",
        matchTime: "20:00",
        liveMinute: "82",
      },
    ];

    // Seed Basketball matches
    const basketballMatches: InsertMatch[] = [
      {
        sport: "basketball",
        league: "NBA",
        homeTeam: "Lakers",
        awayTeam: "Warriors",
        homeTeamLogo: "https://api.dicebear.com/7.x/shapes/svg?seed=lakers&backgroundColor=552583",
        awayTeamLogo: "https://api.dicebear.com/7.x/shapes/svg?seed=warriors&backgroundColor=1d428a",
        homeScore: 98,
        awayScore: 95,
        status: "live",
        matchTime: "22:30",
        liveMinute: "Q4 2:15",
      },
      {
        sport: "basketball",
        league: "NBA",
        homeTeam: "Celtics",
        awayTeam: "Heat",
        homeTeamLogo: "https://api.dicebear.com/7.x/shapes/svg?seed=celtics&backgroundColor=007a33",
        awayTeamLogo: "https://api.dicebear.com/7.x/shapes/svg?seed=heat&backgroundColor=98002e",
        homeScore: null,
        awayScore: null,
        status: "upcoming",
        matchTime: "01:00",
      },
    ];

    // Seed Baseball matches
    const baseballMatches: InsertMatch[] = [
      {
        sport: "baseball",
        league: "MLB",
        homeTeam: "Yankees",
        awayTeam: "Red Sox",
        homeTeamLogo: "https://api.dicebear.com/7.x/shapes/svg?seed=yankees&backgroundColor=003087",
        awayTeamLogo: "https://api.dicebear.com/7.x/shapes/svg?seed=redsox&backgroundColor=bd3039",
        homeScore: 5,
        awayScore: 3,
        status: "live",
        matchTime: "23:00",
        liveMinute: "7th",
      },
      {
        sport: "baseball",
        league: "MLB",
        homeTeam: "Dodgers",
        awayTeam: "Giants",
        homeTeamLogo: "https://api.dicebear.com/7.x/shapes/svg?seed=dodgers&backgroundColor=005a9c",
        awayTeamLogo: "https://api.dicebear.com/7.x/shapes/svg?seed=giants&backgroundColor=fd5a1e",
        homeScore: null,
        awayScore: null,
        status: "upcoming",
        matchTime: "02:30",
      },
    ];

    // Seed Ice Hockey matches
    const hockeyMatches: InsertMatch[] = [
      {
        sport: "ice-hockey",
        league: "NHL",
        homeTeam: "Maple Leafs",
        awayTeam: "Canadiens",
        homeTeamLogo: "https://api.dicebear.com/7.x/shapes/svg?seed=leafs&backgroundColor=00205b",
        awayTeamLogo: "https://api.dicebear.com/7.x/shapes/svg?seed=habs&backgroundColor=af1e2d",
        homeScore: 3,
        awayScore: 2,
        status: "live",
        matchTime: "00:00",
        liveMinute: "P3 15:42",
      },
    ];

    // Seed Volleyball matches
    const volleyballMatches: InsertMatch[] = [
      {
        sport: "volleyball",
        league: "International",
        homeTeam: "Brazil",
        awayTeam: "Italy",
        homeTeamLogo: "https://api.dicebear.com/7.x/shapes/svg?seed=brazil&backgroundColor=009c3b",
        awayTeamLogo: "https://api.dicebear.com/7.x/shapes/svg?seed=italy&backgroundColor=009246",
        homeScore: 2,
        awayScore: 1,
        status: "live",
        matchTime: "18:00",
        liveMinute: "Set 4",
      },
    ];

    // Seed Rugby matches
    const rugbyMatches: InsertMatch[] = [
      {
        sport: "rugby",
        league: "International",
        homeTeam: "All Blacks",
        awayTeam: "Springboks",
        homeTeamLogo: "https://api.dicebear.com/7.x/shapes/svg?seed=allblacks&backgroundColor=000000",
        awayTeamLogo: "https://api.dicebear.com/7.x/shapes/svg?seed=springboks&backgroundColor=007a4d",
        homeScore: null,
        awayScore: null,
        status: "upcoming",
        matchTime: "15:00",
      },
    ];

    // Seed Handball matches
    const handballMatches: InsertMatch[] = [
      {
        sport: "handball",
        league: "European Championship",
        homeTeam: "France",
        awayTeam: "Germany",
        homeTeamLogo: "https://api.dicebear.com/7.x/shapes/svg?seed=france&backgroundColor=002395",
        awayTeamLogo: "https://api.dicebear.com/7.x/shapes/svg?seed=germany&backgroundColor=000000",
        homeScore: 28,
        awayScore: 25,
        status: "live",
        matchTime: "19:00",
        liveMinute: "55:30",
      },
    ];

    // Create all matches
    [...footballMatches, ...basketballMatches, ...baseballMatches, ...hockeyMatches, ...volleyballMatches, ...rugbyMatches, ...handballMatches].forEach((match) => {
      const id = randomUUID();
      this.matches.set(id, { ...match, id });
    });

    // Seed Blog Posts
    const blogPosts: InsertBlogPost[] = [
      {
        sport: "football",
        title: "Manchester United's Comeback Victory",
        description: "Analysis of Man United's impressive performance against Liverpool in the Premier League clash.",
        thumbnail: "https://images.unsplash.com/photo-1574629810360-7efbbe195018?w=400&h=250&fit=crop",
        postedDate: "2 hours ago",
      },
      {
        sport: "football",
        title: "El Clásico Preview: Real Madrid vs Barcelona",
        description: "Everything you need to know about the biggest match in Spanish football this weekend.",
        thumbnail: "https://images.unsplash.com/photo-1579952363873-27f3bade9f55?w=400&h=250&fit=crop",
        postedDate: "5 hours ago",
      },
      {
        sport: "football",
        title: "Champions League Highlights: Bayern Munich Dominates",
        description: "Bayern Munich showcases their attacking prowess in a thrilling Champions League encounter.",
        thumbnail: "https://images.unsplash.com/photo-1508098682722-e99c43a406b2?w=400&h=250&fit=crop",
        postedDate: "1 day ago",
      },
      {
        sport: "basketball",
        title: "Lakers Hold Off Warriors in Thriller",
        description: "LeBron James leads Lakers to narrow victory over Golden State in Western Conference showdown.",
        thumbnail: "https://images.unsplash.com/photo-1546519638-68e109498ffc?w=400&h=250&fit=crop",
        postedDate: "3 hours ago",
      },
      {
        sport: "basketball",
        title: "NBA Playoff Race Heats Up",
        description: "With just weeks remaining, the Eastern Conference playoff picture is getting clearer.",
        thumbnail: "https://images.unsplash.com/photo-1608245449230-4ac19066d2d0?w=400&h=250&fit=crop",
        postedDate: "6 hours ago",
      },
      {
        sport: "baseball",
        title: "Yankees vs Red Sox: A Classic Rivalry Renewed",
        description: "The historic rivalry continues with another dramatic encounter at Yankee Stadium.",
        thumbnail: "https://images.unsplash.com/photo-1566577739112-5180d4bf9390?w=400&h=250&fit=crop",
        postedDate: "4 hours ago",
      },
      {
        sport: "ice-hockey",
        title: "Maple Leafs Edge Out Canadiens in OT",
        description: "Toronto continues their winning streak with dramatic overtime victory against Montreal.",
        thumbnail: "https://images.unsplash.com/photo-1515703407324-5f753afd8be8?w=400&h=250&fit=crop",
        postedDate: "2 hours ago",
      },
      {
        sport: "volleyball",
        title: "Brazil Dominates International Volleyball",
        description: "Brazilian squad shows why they're world champions with commanding performance.",
        thumbnail: "https://images.unsplash.com/photo-1612872087720-bb876e2e67d1?w=400&h=250&fit=crop",
        postedDate: "5 hours ago",
      },
      {
        sport: "rugby",
        title: "All Blacks Prepare for Springboks Clash",
        description: "New Zealand gearing up for one of the biggest matches of the rugby calendar.",
        thumbnail: "https://images.unsplash.com/photo-1616940844649-535215ae4eb1?w=400&h=250&fit=crop",
        postedDate: "8 hours ago",
      },
      {
        sport: "handball",
        title: "France Shows Class in Handball Championship",
        description: "Defending champions France demonstrate their superiority in European competition.",
        thumbnail: "https://images.unsplash.com/photo-1551958219-acbc608c6377?w=400&h=250&fit=crop",
        postedDate: "3 hours ago",
      },
    ];

    blogPosts.forEach((post) => {
      const id = randomUUID();
      this.blogPosts.set(id, { ...post, id });
    });
  }

  async getAllMatches(): Promise<Match[]> {
    return Array.from(this.matches.values());
  }

  async getMatchesBySport(sport: SportType): Promise<Match[]> {
    return Array.from(this.matches.values()).filter((match) => match.sport === sport);
  }

  async getMatchesBySportAndStatus(sport: SportType, status: MatchStatus): Promise<Match[]> {
    return Array.from(this.matches.values()).filter(
      (match) => match.sport === sport && match.status === status
    );
  }

  async getBlogPostsBySport(sport: SportType): Promise<BlogPost[]> {
    return Array.from(this.blogPosts.values()).filter((post) => post.sport === sport);
  }

  async createMatch(insertMatch: InsertMatch): Promise<Match> {
    const id = randomUUID();
    const match: Match = { ...insertMatch, id };
    this.matches.set(id, match);
    return match;
  }

  async createBlogPost(insertPost: InsertBlogPost): Promise<BlogPost> {
    const id = randomUUID();
    const post: BlogPost = { ...insertPost, id };
    this.blogPosts.set(id, post);
    return post;
  }
}

export const storage = new MemStorage();
