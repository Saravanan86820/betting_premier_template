import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom'; // Import Link for routing if necessary
import './Navbar.css'; // Make sure to link to your CSS file

function Navbar() {

 
  return (

    <>
      <header className="header">
        {/* Logo */}
        <div className="header__img">
          <Link to="/">
            <img src="/assets/image/nav/logo.svg" alt="BettingPremier" width="150" height="50" loading="lazy" />
          </Link>
        </div>

      {/* Search */}
      <div className="header__search">
        <img src="/assets/image/nav/search.svg" alt="search-icon" />
        <input type="text" placeholder="Search" />
      </div>

      {/* Settings & Icons */}
      <div className="header__settings">
        <a href="/blog/">
          <div className="header__items header__items--latest">
            <img src="/assets/image/nav/latest_new.svg" alt="latest" />
          </div>
        </a>

        <a href="#">
          <div className="header__items header__items--setting">
            <img src="/assets/image/nav/setting.svg" alt="setting" />
          </div>
        </a>

        <div className="header__dark-mode-toggle">
          <img src="/assets/image/nav/dark-mode-toggle.svg" alt="dark-mode-toggle" />
        </div>
      </div>
    </header>
    
    </>
  );

}


export default Navbar;