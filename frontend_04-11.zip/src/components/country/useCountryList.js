import { useState, useEffect } from 'react';
import { getFromDB, setToDB } from '../../utility/DB';

/**
 * Custom React hook to get list of countries from API ("/api/country"),
 * with IndexedDB caching using the utility functions.
 */
export default function useCountryList() {
  const api = '/api/country';           // API endpoint for fetching country data
  const CACHE_KEY = 'country_list';     // Key under which country list is stored in IndexedDB

  const [countries, setCountries] = useState([]); // State variable to hold countries array

  useEffect(() => {
    let isMounted = true; // Flag to prevent state updates after component unmount

    /**
     * Fetch countries from IndexedDB cache first.
     * If not present, fetch from API and cache the result.
     */
    async function fetchAndCache() {
      try {
        // Try to retrieve cached countries from IndexedDB
        const countries = await getFromDB(CACHE_KEY);

        // If countries exist in cache and not empty, set to state
        if (countries && Object.keys(countries).length > 0) {
          if (isMounted) setCountries(countries);
        } else {
          // Not in cache: fetch from API, store in state and cache
          const resp = await fetch(api, { method: 'POST' }); // API fetch (POST method)
          const json = await resp.json();                    // Parse JSON response
          if (isMounted) setCountries(json.data);            // Set state with fetched data
          await setToDB(CACHE_KEY, json.data);               // Save fetched data to IndexedDB
        }
      } catch (e) {
        // Handle errors (IndexedDB or fetch failed): fallback to API fetch
        console.error('IndexedDB or fetch error:', e);
        const resp = await fetch(api, { method: 'POST' });
        const json = await resp.json();
        if (isMounted) setCountries(json.data);
      }
    }

    // Begin fetch-and-cache logic on component mount/update
    fetchAndCache();

    // Cleanup function to prevent state updates after unmount
    return () => { isMounted = false; };
  }, [api]); // Effect dependency: re-run if API endpoint changes

  // Return countries state (array) for use in caller component
  return countries;
}
