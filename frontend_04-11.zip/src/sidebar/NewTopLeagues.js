import React, { useState, useEffect } from "react";
// import '../index.css';
import './NewTopLeagues.css';
import { useParams, Link } from 'react-router-dom';
import { useLocation } from "react-router-dom";

/**
 * List of top leagues in a sports
 * Can be displayed in sidebar
 */
export default function NewTopLeagues(props) {
  const apiURL = `/api/widget/top-leagues-${props.sports}`;
  const [topLeagues, setTopLeagues] = useState([]);
  const [error, setError] = useState('');

  // Fetch top leagues
  useEffect(() => {
    fetch(apiURL, { method: 'POST' })
      .then(response => response.json())
      .then(respData => {
        if (!respData || respData.status !== "true" || !respData.data) {
          setError("Top Leagues not available");
          console.error("Top Leagues not available");
        }
        let data = respData['data']['0']['data'];
        data = JSON.parse(data);
        // console.log(data);
        setTopLeagues(data);
      })
      .catch(err => {
        console.error('Error fetching top leagues data:', err);
        setError('Error fetching data');
      });
  }, []);

  return (
    <div className="top-leagues-section" id="top-league">
      <div className="top-leagues-section__header">
        <h2>Top Leagues</h2>
        <div class="top-leagues-section__divider"></div>
      </div>
      
        <div className="top-leagues-section__top-leagues">
          
            {topLeagues.map((league, index) => (
              <div key={index} className="top-leagues-section__league">
                <Link to={league.link}>
                  <img src={league.icon} alt={league.alt} className="top-leagues-section__league-logo"  loading="lazy" />
                  <span className="top-leagues-section__league-name">{league.league_name}</span>
                </Link>
              </div>
            ))}
          
        </div>
      
    </div>
  );
}
