import React from "react";
import '../../../index.css';

import VolleyballScorelist from "./VolleyballScorelist";


import Topleagues from "../../../sidebar/Topleagues";
import Alleagues from "../../../sidebar/Alleagues";
// import Add from "../../sidebar/Add";

function Volleyball() {



  return (
    <>

      <div className="mvp-main-box-cont">
        <div className="container-scorelist container-betting-tools">
          <div className="container-score">

            <div className="column-score large">
              <div className="basketball-page-container" id="basketball-page">
                <VolleyballScorelist />
           
              </div>
            </div>

            <div className="column-score small">

              <div className="container-slide">

                {/* <FeatureMatch /> */}
                <Topleagues />
                {/* <Add /> */}
                <Alleagues/>

              </div>

            </div>
          </div>
        </div>
      </div>

    </>
  );

}

export default Volleyball;