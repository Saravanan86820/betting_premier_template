import React from "react";


// import FeatureMatch from "../../sidebar/FeaturedMatch";
import Topleagues from "../../sidebar/Topleagues";
// import Alleagues from "../../sidebar/Alleagues";
import Add from "../../sidebar/Add";
import RecentBlog from "../../sidebar/RecentBlog";


import MatchBanner from "../components/football/MatchBanner";
import IceGameScore from "../../pages/components/ice-hockey/GameScore";
import BaseballGameScore from "../../pages/components/baseball/GameScore";
import BasketballGameScore from "../../pages/components/basketball/GameScore";
import HandBallGameScore from "../../pages/components/handball/GameScore";
import RugbyGameScore from "../../pages/components/rugby/GameScore";
import VolleyBallGameScore from "../../pages/components/volleyball/GameScore";
// import Lineupdata from "../../pages/components/Lineupdata";
// import Statistics from "../../pages/components/Statistics";
// import Wintask from "../../pages/components/Wintask";
import { useLocation } from "react-router-dom";

function MatchSummary() {

  const location = useLocation();
  const slug = location.pathname.split("/")[1];

  return (
    <>
      <div className="mvp-main-box-cont" id="more-blog-section">
        <div className="main-box-container">
          <div className="container-score">

            <div className="column-score large">

              {slug === "football" && <>

                <MatchBanner />
              </>
              }

              {slug === "ice-hockey" &&

                <>
                  <IceGameScore />
                </>
              }


              {slug === "baseball" &&

                <>
                  <BaseballGameScore />
                </>
              }

              {slug === "basketball" &&

                <>
                  <BasketballGameScore />
                </>
              }


              {slug === "handball" &&

                <>
                  <HandBallGameScore />
                </>
              }
              {slug === "rugby" &&

                <>
                  <RugbyGameScore />
                </>
              }
              {slug === "volleyball" &&

                <>
                  <VolleyBallGameScore />
                </>
              }

              {/* <Lineupdata/> */}
              {/* <Wintask />
              <Statistics /> */}


            </div>

            <div className="column-score small">

              <div className="container-slide">
                <Add />
                <RecentBlog />
              </div>
            </div>
          </div>
        </div>
      </div>



    </>
  );
}

export default MatchSummary;