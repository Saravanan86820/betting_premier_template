import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { useLocation } from "react-router-dom";

// import FeatureMatch from "../../sidebar/FeaturedMatch";
import Topleagues from "../../sidebar/Topleagues";
// import Alleagues from "../../sidebar/Alleagues";
import Add from "../../sidebar/Add";
import RecentBlog from "../../sidebar/RecentBlog";


import Leaguebanner from "../components/football/Leaguebanner";
import Matches from "../components/football/Matches";
// import Leagueinfo from "../../pages/components/Leagueinfo";
import LeagueStanded from "../components/football/LeagueStanded";


// ice hockey
import IceHockeyLeagueList from "../../pages/components/ice-hockey/IceHockeyLeagueList";
import IceHockeyMatches from "../../pages/components/ice-hockey/IceHockeyMatches";
import IceHockeyStanding from "../../pages/components/ice-hockey/IceHockeyStanding";

// baseball code
import BaseballLeagueList from "../components/baseball/BaseballLeague";
import BaseBallMatches from "../../pages/components/baseball/BaseBallMatches";
import BaseballStanding from "../../pages/components/baseball/BaseballStanding";

// baseketball code
import BasketballLeague from "../components/basketball/BasketballLeague";
import BasketBallMatches from "../../pages/components/basketball/BasketBallMatches";
import BasketballStanding from "../../pages/components/basketball/BasketballStanding";

// volleyball code
import VolleyBallLeague from "../components/volleyball/VolleyBallLeague";
import VolleyBallMatches from "../../pages/components/volleyball/VolleyBallMatches";
import VolleyballStanding from "../../pages/components/volleyball/VolleyballStanding";


// handball code
import HandBallLeague from "../components/handball/HandBallLeague";
import HandBallMatches from "../../pages/components/handball/HandBallMatches";
// rugby code
import RugbyLeague from "../components/rugby/RugbyLeague";
import RugbyMatches from "../../pages/components/rugby/RugbyMatches";
import NewTopLeagues from '../../sidebar/NewTopLeagues';
import RugbyStanding from '../components/rugby/RugbyStandings';
import HandBallStanding from '../components/handball/HandBallStandings';


function Leaguelist() {

  const [selectedSeason, setSelectedSeason] = useState(null);
  const location = useLocation();
  // const slug = location.pathname.split("/").find((segment) => segment);

  const slug = location.pathname.split("/")[1];

  return (
    <>
      <div className="mvp-main-box-cont" id="more-blog-section">

        <div className="main-box-container">
          <div className="container-score">

            <div className="column-score large">

              {slug === "football" &&
                <>
                <Leaguebanner setSelectedSeason={setSelectedSeason} selectedSeason={selectedSeason} />
                  <div className='container-match'>
                    <div className='column-match small  league_cont'>
                      {selectedSeason && <Matches selectedSeason={selectedSeason} slug={slug} />}
                    </div>
                    <div className='column-match large  league_cont'>
                      {selectedSeason && <LeagueStanded selectedSeason={selectedSeason} />}
                    </div>
                  </div>
                </>
              }
              {slug === "ice-hockey" &&
                <>
                  <IceHockeyLeagueList setSelectedSeason={setSelectedSeason} selectedSeason={selectedSeason} />
                  <div className='container-match'>
                    <div className='column-match small  league_cont'>
                      {selectedSeason && <IceHockeyMatches selectedSeason={selectedSeason} slug={slug} />}
                    </div>
                    <div className='column-match large  league_cont'>
                      {selectedSeason && <IceHockeyStanding selectedSeason={selectedSeason} />}
                  </div>
                  </div>
                </>
              }
              {slug === "baseball" &&
                <>
                  <BaseballLeagueList setSelectedSeason={setSelectedSeason} selectedSeason={selectedSeason} />
                  <div className='container-match'>
                    <div className='column-match small  league_cont'>
                      {selectedSeason && <BaseBallMatches selectedSeason={selectedSeason} slug={slug} />}
                    </div>
                    <div className='column-match large  league_cont'>
                      {selectedSeason && <BaseballStanding selectedSeason={selectedSeason} />}
                    </div>
                  </div>
                      
                </>
              }
              {slug === "basketball" &&
                <>
                  <BasketballLeague setSelectedSeason={setSelectedSeason} selectedSeason={selectedSeason} />
                  <div className='container-match'>
                    <div className='column-match small  league_cont'>
                      {selectedSeason && <BasketBallMatches selectedSeason={selectedSeason} slug={slug} />}
                    </div>
                    <div className='column-match large  league_cont'>
                      {selectedSeason && <BasketballStanding selectedSeason={selectedSeason} />}

                    </div>
                    </div>
                  

                </>
              }
              {
                slug === "volleyball" &&
                <>
                  <VolleyBallLeague setSelectedSeason={setSelectedSeason} selectedSeason={selectedSeason} />
                  <div className='container-match'>
                    <div className='column-match small  league_cont'>
                      {selectedSeason && <VolleyBallMatches selectedSeason={selectedSeason} slug={slug} />}
                    </div>
                    <div className='column-match large  league_cont'>
                      {selectedSeason && <VolleyballStanding selectedSeason={selectedSeason} />}

                    </div>
                    </div>
                  
                </>
              }
              {
                slug === "handball" &&
                <>
                  <HandBallLeague setSelectedSeason={setSelectedSeason} selectedSeason={selectedSeason} />
                  <div className='container-match'>
                    <div className='column-match small  league_cont'>
                      {selectedSeason && <HandBallMatches selectedSeason={selectedSeason} slug={slug} />}
                    </div>
                    <div className='column-match large  league_cont'>
                      {selectedSeason && <HandBallStanding selectedSeason={selectedSeason} />}

                    </div>
                    </div>
                </>
              }
              {
                slug === "rugby" &&
                <>
                  <RugbyLeague setSelectedSeason={setSelectedSeason} selectedSeason={selectedSeason} />
                  <div className='container-match'>
                    <div className='column-match small  league_cont'>
                      {selectedSeason && <RugbyMatches selectedSeason={selectedSeason} slug={slug} />}
                    </div>
                    <div className='column-match large  league_cont'>
                      {selectedSeason && <RugbyStanding selectedSeason={selectedSeason} />}

                    </div>
                    </div>
                  
                </>
              }



            </div>

            <div className="column-score small">

              <div className="container-slide">
                {/* <FeatureMatch /> */}
                <RecentBlog />
                <Add />
              </div>
            </div>
          </div>
        </div>

      </div>
    </>
  );
}

export default Leaguelist;