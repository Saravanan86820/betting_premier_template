import React from "react";

import { Link } from 'react-router-dom';

// import FeatureMatch from "../../sidebar/FeaturedMatch";
import Topleagues from "../../sidebar/Topleagues";
// import Alleagues from "../../sidebar/Alleagues";
import Add from "../../sidebar/Add";
import RecentBlog from "../../sidebar/RecentBlog";

import Livegamescore from "../../pages/livegame/Livegamescore";

function Livegame() {


    return (

        <>

           

            <div className="mvp-main-box-cont" id="more-blog-section">

            <div className="main-box-container">
                <div className="container-score">

                    <div className="column-score large">
                      <Livegamescore/>
                       
                    </div>

                    <div className="column-score small">

                        <div className="container-slide">
                            {/* <FeatureMatch /> */}
                            <Topleagues />
                            <Add/>
                            {/* <Alleagues/> */}
                            <RecentBlog/>
                        </div>
                    </div>
                </div>
                </div>

            </div>



        </>
    );
}

export default Livegame;