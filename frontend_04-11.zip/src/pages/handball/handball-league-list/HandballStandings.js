import React, { useState, useEffect } from 'react';


function HandballStandings() {

  const [standings, setStandings] = useState([]);
  const [filteredStandings, setFilteredStandings] = useState([]);
  const [groups, setGroups] = useState([]);
  const [selectedGroup, setSelectedGroup] = useState('');

  useEffect(() => {
    // Simulating a fetch operation (you can replace this with an API call)
    const fetchData = () => {
      const data = [
        {
          "position": 12,
          "stage": "MLB - Regular Season",
          "group": {
            "name": "American League"
          },
          "team": {
            "id": 5,
            "name": "Boston Red Sox",
            "logo": "https://media.api-sports.io/baseball/teams/5.png"
          },
          "league": {
            "id": 1,
            "name": "MLB",
            "type": "League",
            "logo": "https://media.api-sports.io/baseball/leagues/1.png",
            "season": 2020
          },
          "country": {
            "id": 1,
            "name": "USA",
            "code": "US",
            "flag": "https://media.api-sports.io/flags/us.svg"
          },
          "games": {
            "played": 0,
            "win": {
              "total": 0,
              "percentage": "0.000"
            },
            "lose": {
              "total": 0,
              "percentage": "0.000"
            }
          },
          "points": {
            "for": 0,
            "against": 0
          },
          "form": null,
          "description": null
        },
        {
          "position": 5,
          "stage": "MLB - Regular Season",
          "group": {
            "name": "AL East"
          },
          "team": {
            "id": 5,
            "name": "Boston Red Sox",
            "logo": "https://media.api-sports.io/baseball/teams/5.png"
          },
          "league": {
            "id": 1,
            "name": "MLB",
            "type": "League",
            "logo": "https://media.api-sports.io/baseball/leagues/1.png",
            "season": 2020
          },
          "country": {
            "id": 1,
            "name": "USA",
            "code": "US",
            "flag": "https://media.api-sports.io/flags/us.svg"
          },
          "games": {
            "played": 0,
            "win": {
              "total": 0,
              "percentage": "0.000"
            },
            "lose": {
              "total": 0,
              "percentage": "0.000"
            }
          },
          "points": {
            "for": 0,
            "against": 0
          },
          "form": null,
          "description": null
        },
        {
          "position": 9,
          "stage": "MLB - Pre-season",
          "group": {
            "name": "American League"
          },
          "team": {
            "id": 5,
            "name": "Boston Red Sox",
            "logo": "https://media.api-sports.io/baseball/teams/5.png"
          },
          "league": {
            "id": 1,
            "name": "MLB",
            "type": "League",
            "logo": "https://media.api-sports.io/baseball/leagues/1.png",
            "season": 2020
          },
          "country": {
            "id": 1,
            "name": "USA",
            "code": "US",
            "flag": "https://media.api-sports.io/flags/us.svg"
          },
          "games": {
            "played": 12,
            "win": {
              "total": 5,
              "percentage": "0.417"
            },
            "lose": {
              "total": 7,
              "percentage": "0.583"
            }
          },
          "points": {
            "for": 57,
            "against": 60
          },
          "form": null,
          "description": null
        }
      ]
      ;
      setStandings(data); // Setting the fetched data to state
    };

    fetchData();
  }, []);

      useEffect(() => {
         console.log("Standings state updated: ", standings);
       }, [standings]);

       useEffect(() => {
        // Extract unique groups for the dropdown
        const uniqueGroups = ["All", ...new Set(standings.map(item => item.group.name))];
        setGroups(uniqueGroups);
        setFilteredStandings(standings); // Initially show all standings
      }, [standings]);
    
      const handleGroupChange = (group) => {
        setSelectedGroup(group);
        if (group === "All") {
          setFilteredStandings(standings);
        } else {
          const filtered = standings.filter(item => item.group.name === group);
          setFilteredStandings(filtered);
        }
      };

  return (

    <>

      <div className="league-main-container" id="league-standings">
        <div className="league-main-row">
          <div className="league-center-title">
            <div className="imageflex">
              <img src="/assets/image/standing.svg" alt="Standings" width="25" height="25" className="league-imageflex" loading="lazy" />
              <h4 className="league-heading-sub">Standings Handball </h4>
            </div>
          </div>

          <div className="group-filter">
          <label htmlFor="group-select">Filter by Group:</label>
          <select id="group-select" value={selectedGroup} onChange={(e) => handleGroupChange(e.target.value)}>
            {groups.map((group, index) => (
              <option key={index} value={group}>{group}</option>
            ))}
          </select>
        </div>

          <div className="league-main-tabel">
            <div className="tabsection-container">
              <div>

                <div className="all-table-data">
                  <div className="ptable">
                    <table id="tablefull">
                      <thead>
                        <tr className="col">
                          <th style={{ width: '2%' }}>#</th>
                          <th style={{ width: '58%' }}>Team</th>
                          <th> Played</th>
                          <th> Gropuname</th>
                          <th>Win</th>
                          <th>Loss</th>

                          <th>  Points</th>
                          <th>Form</th>
                        </tr>
                      </thead>
                      <tbody>

                        {filteredStandings.map((item, index) => (
                          <tr className="wpos" key={index}>
                            <td>{index}</td>
                            <td className="imagtile">
                              <img
                                className="participant__image"
                                alt="date"
                                src="/bet-assets/site/image/football/team/liverpool-40-6713011a51495241.png"
                                width="15"

                                loading="lazy"
                              />
                            livebroof
                            </td>
                          
                            <td>  {item.games.played}</td>
                            <td>  {item.group.name}</td>
                            <td> {item.games.win.total}</td>
                            <td> {item.games.lose.total}</td>

                            <td> {item.points.for}</td>
                            <td>


                              {item.form ? item.form : " -" }
                            </td>
                          </tr>


                        ))}



                      </tbody>
                    </table>
                  </div>

                  <div className="key-tabel">
                    <div className="key-tabel-title">
                      Key
                    </div>
                    <div className="key-tabel-list">
                      <ol className="tabel-ul">
                        <li className="tabel-li">Win</li>
                        <li className="tabel-li">Loss</li>
                        <li className="tabel-li">Draw</li>
                      </ol>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>


    </>
  );
}

export default HandballStandings;