import React, { useEffect, useState } from 'react';
import './HomeBlog.css';

function HomeBlog() {
    const [posts, setPosts] = useState([]);
    const [error, setError] = useState('');
    const [currentIndex, setCurrentIndex] = useState(0);

    useEffect(() => {
        const fetchPost = async () => {
            try {
                const response = await fetch('/blog/wp-json/custom/v3/league/blog');
                const jsonresult = await response.json();

                if (response.ok) {
                    setPosts(jsonresult);
                } else {
                    setError('Failed to fetch posts');
                    console.log('Error:', jsonresult);
                }
            } catch (err) {
                setError('An error occurred while fetching data');
                console.error('Error:', err);
            }
        };

        fetchPost();
    }, []);

    useEffect(() => {
    if (posts.length === 0) return;
    const interval = setInterval(() => {
      setCurrentIndex((prevIndex) =>
        prevIndex === posts.length - 1 ? 0 : prevIndex + 1
      );
    }, 4000);
    return () => clearInterval(interval);
  }, [posts]);

  if (error) return <p>{error}</p>;
  if (posts.length === 0) return <p>Loading...</p>;


    return (
        <>
            {error && <p className="error-message">{error}</p>}

            <div className="slideshow">
              
      <div
        className="slideshow__slides"
        style={{ transform: `translateX(-${currentIndex * 100}%)` }}
      >
        {posts.slice(0, 6).map((post) => (
          <a href={post.link} key={post.id} className="slideshow__slide">
            <div
              className="slideshow__image"
              style={{ backgroundImage: `url(${post.featured_image_url})` }}
            >
              <div className="slideshow__overlay">
                <h2 className="slideshow__title">{post.title}</h2>
              </div>
            </div>
          </a>
        ))}
      </div>

        </div>
      {/* Navigation dots */}
      <div className="slideshow__dots">
        {posts.slice(0, 6).map((_, idx) => (
          <span
            key={idx}
            className={`dot ${idx === currentIndex ? 'active' : ''}`}
            onClick={() => setCurrentIndex(idx)}
          ></span>
        ))}
      </div>
            
        </>
    );
}

export default HomeBlog;
