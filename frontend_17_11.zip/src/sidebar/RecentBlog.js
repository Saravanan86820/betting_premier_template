import React, { useEffect, useState } from 'react';
import '../index.css';

import SkeletonRecentBlog from '../pages/loader/SkeletonRecentBlog';

function RecentBlog() {

    const [posts, setPosts] = useState([]);
    const [error, setError] = useState('');
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const fetchPost = async () => {
            try {
                const response = await fetch(
                    '/blog/wp-json/custom/v1/posts'
                );
                const jsonresult = await response.json();

                if (response.ok) {
                    const limitedPosts = jsonresult.slice(0, 3); // Limit to 4 posts
                    setPosts(limitedPosts);

                    // console.log(jsonresult);
                } else {
                    setError('Failed to fetch posts'); // Handle unsuccessful response
                    console.log('Error:', jsonresult);
                }

                setLoading(false); 
            } catch (err) {
                setError('An error occurred while fetching data'); // Catch and handle network or other errors
                console.error('Error:', err);
                setLoading(false); 
            }
        };

        fetchPost();
    }, []);


    return (

        <>
            <div className="match">
                <div className="match-header">

                    <div className="match-tournament"> Recent Blog</div>
                    <div className="match-tournament-divider"></div>
                </div>
                {error && <p className="error-message">{error}</p>}
                {loading ? (
                                    <SkeletonRecentBlog />
                                ) : (
                <div className="Recent-content-main">
                    {posts.map((post) => {
                        const category =
                            post.categories && post.categories.length > 0
                                ? post.categories[0]
                                : { name: 'Unknown' };
                        const categoryName = category.name;
                        const categoryUrl = category.url;
                        const imageUrl = post.featured_image_url || undefined;
                        return (

                            <a href={post.link} key={post.id} >
                                <div className="blog-row-main" >
                                    <div className="blog-row">
                                        <div className="blog-row-image">
                                            <img src={imageUrl} alt={post.title} className="blog-images-top" width="90" height="80" loading="lazy"/>
                                        </div>
                                        <div className="blog-row-content">

                                            <h3 className="blog-sub-text">   {categoryName}  </h3>
                                            <h2 className="blog-sub-title">
                                                {post.title}
                                            </h2>

                                        </div>
                                    </div>
                                </div>
                            </a>
                        );
                    })}




                </div>
                                )}
            </div>


        </>
    );
}

export default RecentBlog;