import React from "react";
import './About.css';

import { Link } from 'react-router-dom';



function About() {


    return (

        <>

            <div className="flex-container-about league_cont">
                <div className="flex-about-item">
                    <div className="flex-about-list image-center">
                        <img src="/bet-assets/site/image/common/allsport.svg" alt="aboutimage" width="500"  height="380" className="about-image" loading="lazy"/>
                    </div>
                    <div className="flex-about-list">
                        {/* <span className="span-date">About Us</span> */}
                        <h2 className="about-heading">
                            About BettingPremier
                        </h2>
                        <p className="para-about">

                            Bettingpremier.com makes available the live stream schedules, ensuring that you experience the live streaming of every sport. We offer an immense amount of betting related information and guidelines for an in-depth understanding of the betting concepts and to help you decide the right ones to choose.
                        </p>
                        <p className="para-about">
                            We feature a wide range of betting types available in each sport so that you prefer the best and the most affordable bet. We, thus, invest a great deal of time and effort into determining which ones we endorse to you. We render ample guidance to betting in every form, suitable to everyone from learners to skilled bettors.                        </p>

                        <a href="/blog/about-us/">
                            <button className="bet-button">
                                More About <span className="svgspan"> </span>
                            </button>
                        </a>
                    </div>
                </div>
            </div>




            <section className="betting-tools">
      
        <h2>Our Betting Tools</h2>
      

      <div className="betting-tools__grid">
        {/* Card 1 */}
        <div className="betting-tool__card">
          <div className="betting-tool__image">
            <img src="/bet-assets/site/image/common/stream-schedule.svg" alt="Live Stream Schedule" />
          </div>
          <div className="betting-tool__content">
            <h3>Bet365 Schedule</h3>
            <p>
              Bet365 offer live stream on major sports events from Football, Tennis, Ice Hockey, and more.
            </p>
            <a href="#" className="betting-tool__link">Read More</a>
          </div>
        </div>

        {/* Card 2 */}
        <div className="betting-tool__card">
          <div className="betting-tool__image">
            <img src="/bet-assets/site/image/common/bettingconverter.svg" alt="Odds Converter" />
          </div>
          <div className="betting-tool__content">
            <h3>Odds Converter</h3>
            <p>
              A simple Odds Converter tool to convert between Decimal, Fractional, and American odds.
            </p>
            <a href="#" className="betting-tool__link">Read More</a>
          </div>
        </div>

        {/* Card 3 */}
        <div className="betting-tool__card">
          <div className="betting-tool__image">
            <img src="/bet-assets/site/image/common/bet365-games.svg" alt="Bet365 Games" />
          </div>
          <div className="betting-tool__content">
            <h3>Bet365 Games</h3>
            <p>
              Bet365 is popular site with millions of customers all over the world because they cover all possible games.
            </p>
            <a href="#" className="betting-tool__link">Read More</a>
          </div>
        </div>

        {/* Card 4 */}
        <div className="betting-tool__card">
          <div className="betting-tool__image">
            <img src="/bet-assets/site/image/common/bet365-casino.svg" alt="Bet365 Casino" />
          </div>
          <div className="betting-tool__content">
            <h3>Bet365 Casino</h3>
            <p>
              Casinos are most commonly built with hotels, restaurants, and cruise ships or other tourist attractions.
            </p>
            <a href="#" className="betting-tool__link">Read More</a>
          </div>
        </div>
      </div>
    </section>
           
        </>
    );
}

export default About;