import React, { useState, useEffect } from "react";
import '../../index.css';
import { useParams, Link } from 'react-router-dom';
import LocalTime from "../../utility/LocalTime";

function Scorematch() {

    const [matches, setMatches] = useState([]);
    const [gameMatch, setGameMatch] = useState({});
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

    const [data, setData] = useState([]);
    const [seasonId, setSeasonId] = useState(null);

    useEffect(() => {
        const fetchData = async () => {
            try {
                const response = await fetch('/blog/wp-json/custom/v6/league/season/1/api');

                if (!response.ok) {
                    // If the response status is not OK, throw an error
                    throw new Error(`Error: ${response.status} ${response.statusText}`);
                }

                const jsonData = await response.json();
                setData(jsonData);

                if (jsonData.length > 0) {
                    setSeasonId(jsonData[0].season_id);
                }
            } catch (err) {
                // Log error to console
                console.error('Fetch error:', err);
            }
        };

        fetchData();
    }, []);

    useEffect(() => {
        if (!seasonId) return; // Exit if seasonId is not available

        const fetchMatches = async () => {
            const allSeasonUrl = `/api/season/${seasonId}/game`;
            //console.log("allSeasonUrl",allSeasonUrl);
             
            try {
                const response = await fetch(allSeasonUrl, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ type: 'recent' })
                });
                const respData = await response.json();

                if (!respData['status'] || respData['status'] !== 'true' || respData['data'].length === 0) {
                    console.error('Something wrong with the API response', respData);
                    setError(true);
                    return;
                }

                const currentTimeUTC = Math.floor(new Date().getTime() / 1000);
                let scheduleData = respData['data'];

                // Filter and sort for past and upcoming matches
                const lastMatches = scheduleData
                    .filter(game => game.time < currentTimeUTC)
                    .sort((a, b) => b.time - a.time)
                    .slice(0, 3)
                    .reverse();

                let selectedMatches = scheduleData
                    .filter(game => game.time > currentTimeUTC)
                    .sort((a, b) => a.time - b.time)
                    .slice(0, 3);

                if (selectedMatches.length > 0) {
                    selectedMatches = [...lastMatches, ...selectedMatches];
                } else {
                    selectedMatches = lastMatches.concat(
                        scheduleData
                            .filter(game => game.time < currentTimeUTC)
                            .sort((a, b) => b.time - a.time)
                            .slice(0, 6 - selectedMatches.length)
                    );
                }

                setMatches(selectedMatches);
            } catch (error) {
                console.error('Error fetching match data:', error);
                setError(true);
            } finally {
                setLoading(false);
            }
        };

        fetchMatches();
    }, [seasonId]); // Dependency on seasonId

    useEffect(() => {
        if (matches && matches.length > 0) {
            matches.forEach(match => fetchGameDetails(match.id));
        }
    }, [matches]);

    const fetchGameDetails = (matchId) => {
        const LeagueGame = `/api/game/${matchId}`;
        fetch(LeagueGame, { method: 'POST' })
            .then(response => response.json())
            .then(json => {
                if (json && json.data) {
                    setGameMatch(prevState => ({
                        ...prevState,
                        [matchId]: json.data,
                    }));
                    setLoading(false);
                } else {
                    const errorMessage = `Game data not found for match ${matchId}`;
                    console.error(errorMessage);
                    //setError(errorMessage);
                }
            })
           .catch(() => {
                const errorMessage = `Error fetching game data for match ${matchId}`;
                console.error(errorMessage);
                // setError(errorMessage);
            });
    };


    if (loading) {
        return <div>Loading...</div>;
    }

    if (error) {
        return <div>Error: {error}</div>;
    }

    return (
        <div className="league-section-main">
            <div className="league-section-row">
                <div className="header-bg-slide">
                    {data.length > 0 && (
                        <div className="header-flex" key={data[0].id}>
                            <div className="country-images">
                                <img
                                    src={data[0].country_icon}
                                    alt={data[0].country_alt}
                                    width="20"
                                    height="20"
                                    className="country-icon"
                                     loading="lazy"
                                />
                            </div>
                            <div className="country-content">
                                <Link to={data[0].league_link}>
                                    <span className="country-name">
                                        {data[0].country_name}
                                    </span>
                                    <h3 className="text-slide">
                                        {data[0].league_name}
                                    </h3>
                                </Link>
                            </div>
                        </div>
                    )}

                </div>

                {matches && matches.length > 0 ? (

                    <div className="league-container">

                        {matches.map(match => {


                            const matchDetails = gameMatch[match.id] || {}; // Get match details from state
                            const homeTeam = matchDetails.home || {};
                            const awayTeam = matchDetails.away || {};
                            //const matchDate = new Date(matchDetails.date); // Format the date
                            const hometime = matchDetails.time;
                            const utctime = LocalTime(hometime);

                            let defaultImage = '/bet-assets/site/image/defaulticon.svg';

                            const gamesurl = match['name'] ? match['name'].replace(/\s+/g, '-').replace(/\//g, '-').replace(/-+/g, '-').toLowerCase() : "";
                            const idgame = match["id"] ? match["id"] : "";
                            const gameurlslug = `${gamesurl}/${idgame}`;

                            return (
                                <Link to={`/football/game/${gameurlslug}`} key={`row-${match.id}`}>
                                    <div className="league-rows" >
                                        <div className="league-rows-iteam-match1">
                                            <div className="league-rows-iteam-time">
                                                <div className="match-date">
                                                    <div className="match-date">{utctime} </div>
                                                </div>
                                                <div className="match-status">{matchDetails.full_status && JSON.parse(matchDetails.full_status).long}</div>
                                            </div>
                                        </div>
                                        <div className="league-rows-iteam-match2">
                                            <div className="league-match-data">
                                                <div className="league-match-img">
                                                    <img
                                                        src={homeTeam.icon ? homeTeam.icon : defaultImage}
                                                        alt={homeTeam.display_name || 'league'}
                                                        className="league-live-img"
                                                        onError={(e) => { e.target.src = defaultImage; }}
                                                         loading="lazy" width="20" height="20"
                                                    />

                                                    <span>{homeTeam.display_name}</span>

                                                </div>
                                                <div className="league-match-score">

                                                    {matchDetails.result && JSON.parse(matchDetails.result).fulltime ? (
                                                        <>
                                                            {JSON.parse(matchDetails.result).fulltime.home !== null
                                                                ? JSON.parse(matchDetails.result).fulltime.home
                                                                : '-'}
                                                        </>
                                                    ) : (
                                                        '-'
                                                    )}
                                                </div>
                                            </div>

                                            <div className="league-match-data">
                                                <div className="league-match-img">
                                                    <img
                                                        src={awayTeam.icon ? awayTeam.icon : defaultImage}
                                                        alt={awayTeam.display_name || 'league'}
                                                        className="league-live-img"
                                                        onError={(e) => { e.target.src = defaultImage; }}
                                                         loading="lazy" width="20" height="20"
                                                    />

                                                    <span>{awayTeam.display_name}</span>
                                                </div>
                                                <div className="league-match-score">

                                                    {matchDetails.result && JSON.parse(matchDetails.result).fulltime ? (
                                                        <>
                                                            {JSON.parse(matchDetails.result).fulltime.away !== null
                                                                ? JSON.parse(matchDetails.result).fulltime.away
                                                                : '-'}
                                                        </>
                                                    ) : (
                                                        '-'
                                                    )}
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </Link>
                            );
                        })}

                    </div>

                ) : (
                    <div>No matches available</div>
                )}
            </div>
        </div>
    );

}

function ScorematchB() {

    const [matches, setMatches] = useState([]);
    const [gameMatch, setGameMatch] = useState({});
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

    const [data, setData] = useState([]);
    const [seasonId, setSeasonId] = useState(null);

    useEffect(() => {
        const fetchData = async () => {
            try {
                const response = await fetch('/blog/wp-json/custom/v6/league/season/1/api');
                // console.log('response', response);
                if (!response.ok) {
                    // If the response status is not OK, throw an error
                    throw new Error(`Error: ${response.status} ${response.statusText}`);
                }

                const jsonData = await response.json();
                setData(jsonData);

                if (jsonData.length > 0) {
                    setSeasonId(jsonData[1].season_id);
                }
            } catch (err) {
                // Log error to console
                console.error('Fetch error:', err);
            }
        };

        fetchData();
    }, []);

    useEffect(() => {
        if (!seasonId) return; // Exit if seasonId is not available

        const fetchMatches = async () => {
            const allSeasonUrl = `/api/season/${seasonId}/game`;

            //    console.log("allSeasonUrl",allSeasonUrl);
            try {
                const response = await fetch(allSeasonUrl, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ type: 'recent' })
                });
                const respData = await response.json();

                if (!respData['status'] || respData['status'] !== 'true' || respData['data'].length === 0) {
                    console.error('Something wrong with the API response', respData);
                    setError(true);
                    return;
                }

                const currentTimeUTC = Math.floor(new Date().getTime() / 1000);
                let scheduleData = respData['data'];

                // Filter and sort for past and upcoming matches
                const lastMatches = scheduleData
                    .filter(game => game.time < currentTimeUTC)
                    .sort((a, b) => b.time - a.time)
                    .slice(0, 3)
                    .reverse();

                let selectedMatches = scheduleData
                    .filter(game => game.time > currentTimeUTC)
                    .sort((a, b) => a.time - b.time)
                    .slice(0, 3);

                if (selectedMatches.length > 0) {
                    selectedMatches = [...lastMatches, ...selectedMatches];
                } else {
                    selectedMatches = lastMatches.concat(
                        scheduleData
                            .filter(game => game.time < currentTimeUTC)
                            .sort((a, b) => b.time - a.time)
                            .slice(0, 6 - selectedMatches.length)
                    );
                }

                setMatches(selectedMatches);
            } catch (error) {
                console.error('Error fetching match data:', error);
                setError(true);
            } finally {
                setLoading(false);
            }
        };

        fetchMatches();
    }, [seasonId]); // Dependency on seasonId


    useEffect(() => {
        if (matches && matches.length > 0) {
            matches.forEach(match => fetchGameDetails(match.id));
        }
    }, [matches]);

    const fetchGameDetails = (matchId) => {
        const LeagueGame = `/api/game/${matchId}`;
        fetch(LeagueGame, { method: 'POST' })
            .then(response => response.json())
            .then(json => {
                if (json && json.data) {
                    setGameMatch(prevState => ({
                        ...prevState,
                        [matchId]: json.data,
                    }));
                    setLoading(false);
                } else {
                    const errorMessage = `Game data not found for match ${matchId}`;
                    console.error(errorMessage);

                }
            })
            .catch(() => {
                const errorMessage = `Error fetching game data for match ${matchId}`;
                console.error(errorMessage);
                // setError(errorMessage);
            });
    };


    if (loading) {
        return <div>Loading...</div>;
    }

    if (error) {
        return <div>Error: {error}</div>;
    }

    return (
        <div className="league-section-main">
            <div className="league-section-row">
                <div className="header-bg-slide">
                    {data.length > 0 && (
                        <div className="header-flex" key={data[1].id}>
                            <div className="country-images">
                                <img
                                    src={data[1].country_icon}
                                    alt={data[1].country_alt}
                                    width="20"
                                    height="20"
                                    className="country-icon"
                                     loading="lazy"
                                />
                            </div>
                            <div className="country-content">
                                <Link to={data[1].league_link}>
                                    <span className="country-name">
                                        {data[1].country_name}
                                    </span>
                                    <h3 className="text-slide">
                                        {data[1].league_name}
                                    </h3>
                                </Link>
                            </div>
                        </div>
                    )}
                </div>

                {matches && matches.length > 0 ? (

                    <div className="league-container">

                        {matches.map(match => {


                            const matchDetails = gameMatch[match.id] || {}; // Get match details from state
                            const homeTeam = matchDetails.home || {};
                            const awayTeam = matchDetails.away || {};
                            //const matchDate = new Date(matchDetails.date); // Format the date
                            const hometime = matchDetails.time;
                            const utctime = LocalTime(hometime);

                            let defaultImage = '/bet-assets/site/image/defaulticon.svg';

                            const gamesurl = match['name'] ? match['name'].replace(/\s+/g, '-').replace(/\//g, '-').replace(/-+/g, '-').toLowerCase() : "";
                            const idgame = match["id"] ? match["id"] : "";
                            const gameurlslug = `${gamesurl}/${idgame}`;
                            // key={match.id}
                            return (
                                <Link to={`/football/game/${gameurlslug}`}  key={`row-${match.id}`}>
                                    <div className="league-rows" >
                                        <div className="league-rows-iteam-match1">
                                            <div className="league-rows-iteam-time">
                                                <div className="match-date">
                                                    <div className="match-date">{utctime} </div>
                                                </div>
                                                <div className="match-status">{matchDetails.full_status && JSON.parse(matchDetails.full_status).long}</div>
                                            </div>
                                        </div>
                                        <div className="league-rows-iteam-match2">
                                            <div className="league-match-data">
                                                <div className="league-match-img">
                                                    <img
                                                        src={homeTeam.icon ? homeTeam.icon : defaultImage}
                                                        alt={homeTeam.display_name || 'league'}
                                                        className="league-live-img"
                                                        onError={(e) => { e.target.src = defaultImage; }}
                                                         loading="lazy" width="20" height="20"
                                                    />

                                                    <span>{homeTeam.display_name}</span>

                                                </div>
                                                <div className="league-match-score">

                                                    {matchDetails.result && JSON.parse(matchDetails.result).fulltime ? (
                                                        <>
                                                            {JSON.parse(matchDetails.result).fulltime.home !== null
                                                                ? JSON.parse(matchDetails.result).fulltime.home
                                                                : '-'}
                                                        </>
                                                    ) : (
                                                        '-'
                                                    )}
                                                </div>
                                            </div>

                                            <div className="league-match-data">
                                                <div className="league-match-img">
                                                    <img
                                                        src={awayTeam.icon ? awayTeam.icon : defaultImage}
                                                        alt={awayTeam.display_name || 'league'}
                                                        className="league-live-img"
                                                        onError={(e) => { e.target.src = defaultImage; }}
                                                         loading="lazy" width="20" height="20"
                                                    />

                                                    <span>{awayTeam.display_name}</span>
                                                </div>
                                                <div className="league-match-score">

                                                    {matchDetails.result && JSON.parse(matchDetails.result).fulltime ? (
                                                        <>
                                                            {JSON.parse(matchDetails.result).fulltime.away !== null
                                                                ? JSON.parse(matchDetails.result).fulltime.away
                                                                : '-'}
                                                        </>
                                                    ) : (
                                                        '-'
                                                    )}
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </Link>
                            );
                        })}

                    </div>

                ) : (
                    <div>No matches available</div>
                )}
            </div>
        </div>
    );

}

function ScorematchC() {

    const [matches, setMatches] = useState([]);
    const [gameMatch, setGameMatch] = useState({});
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

    const [data, setData] = useState([]);
    const [seasonId, setSeasonId] = useState(null);

    useEffect(() => {
        const fetchData = async () => {
            try {
                const response = await fetch('/blog/wp-json/custom/v6/league/season/1/api');
                //    console.log('response', response);
                if (!response.ok) {
                    // If the response status is not OK, throw an error
                    throw new Error(`Error: ${response.status} ${response.statusText}`);
                }

                const jsonData = await response.json();
                setData(jsonData);

                if (jsonData.length > 0) {
                    setSeasonId(jsonData[2].season_id);

                }
            } catch (err) {
                // Log error to console
                console.error('Fetch error:', err);
            }
        };

        fetchData();
    }, []);

    useEffect(() => {
        if (!seasonId) return; // Exit if seasonId is not available

        const fetchMatches = async () => {
            const allSeasonUrl = `/api/season/${seasonId}/game`;

            //  console.log("allSeasonUrl",allSeasonUrl);
            try {
                const response = await fetch(allSeasonUrl, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ type: 'recent' })
                });
                const respData = await response.json();

                if (!respData['status'] || respData['status'] !== 'true' || respData['data'].length === 0) {
                    console.error('Something wrong with the API response', respData);
                    setError(true);
                    return;
                }

                const currentTimeUTC = Math.floor(new Date().getTime() / 1000);
                let scheduleData = respData['data'];

                // Filter and sort for past and upcoming matches
                const lastMatches = scheduleData
                    .filter(game => game.time < currentTimeUTC)
                    .sort((a, b) => b.time - a.time)
                    .slice(0, 3)
                    .reverse();

                let selectedMatches = scheduleData
                    .filter(game => game.time > currentTimeUTC)
                    .sort((a, b) => a.time - b.time)
                    .slice(0, 3);

                if (selectedMatches.length > 0) {
                    selectedMatches = [...lastMatches, ...selectedMatches];
                } else {
                    selectedMatches = lastMatches.concat(
                        scheduleData
                            .filter(game => game.time < currentTimeUTC)
                            .sort((a, b) => b.time - a.time)
                            .slice(0, 6 - selectedMatches.length)
                    );
                }

                setMatches(selectedMatches);
            } catch (error) {
                console.error('Error fetching match data:', error);
                setError(true);
            } finally {
                setLoading(false);
            }
        };

        fetchMatches();
    }, [seasonId]); // Dependency on seasonId

    useEffect(() => {
        if (matches && matches.length > 0) {
            matches.forEach(match => fetchGameDetails(match.id));
        }
    }, [matches]);

    const fetchGameDetails = (matchId) => {
        const LeagueGame = `/api/game/${matchId}`;
        fetch(LeagueGame, { method: 'POST' })
            .then(response => response.json())
            .then(json => {
                if (json && json.data) {
                    setGameMatch(prevState => ({
                        ...prevState,
                        [matchId]: json.data,
                    }));
                    setLoading(false);
                } else {
                    const errorMessage = `Game data not found for match ${matchId}`;
                    console.error(errorMessage);

                }
            })
            .catch(() => {
                const errorMessage = `Error fetching game data for match ${matchId}`;
                console.error(errorMessage);
                // setError(errorMessage);
            });
    };


    if (loading) {
        return <div>Loading...</div>;
    }

    if (error) {
        return <div>Error: {error}</div>;
    }

    return (
        <div className="league-section-main">
            <div className="league-section-row">
                <div className="header-bg-slide">

                    {data.length > 0 && (
                        <div className="header-flex" key={data[2].id}>
                            <div className="country-images">
                                <img
                                    src={data[2].country_icon}
                                    alt={data[2].country_alt}
                                    width="20"
                                    height="20"
                                    className="country-icon"
                                     loading="lazy"
                                />
                            </div>
                            <div className="country-content">
                                <Link to={data[2].league_link}>
                                    <span className="country-name">
                                        {data[2].country_name}
                                    </span>
                                    <h3 className="text-slide">
                                        {data[2].league_name}
                                    </h3>
                                </Link>
                            </div>
                        </div>
                    )}

                </div>

                {matches && matches.length > 0 ? (

                    <div className="league-container">

                        {matches.map(match => {


                            const matchDetails = gameMatch[match.id] || {}; // Get match details from state
                            const homeTeam = matchDetails.home || {};
                            const awayTeam = matchDetails.away || {};
                            //const matchDate = new Date(matchDetails.date); // Format the date
                            const hometime = matchDetails.time;
                            const utctime = LocalTime(hometime);

                            let defaultImage = '/bet-assets/site/image/defaulticon.svg';

                            const gamesurl = match['name'] ? match['name'].replace(/\s+/g, '-').replace(/\//g, '-').replace(/-+/g, '-').toLowerCase() : "";
                            const idgame = match["id"] ? match["id"] : "";
                            const gameurlslug = `${gamesurl}/${idgame}`;

                            return (
                                <Link to={`/football/game/${gameurlslug}`} key={`row-${match.id}`}>
                                    <div className="league-rows" >
                                        <div className="league-rows-iteam-match1">
                                            <div className="league-rows-iteam-time">
                                                <div className="match-date">
                                                    <div className="match-date">{utctime} </div>
                                                </div>
                                                <div className="match-status">{matchDetails.full_status && JSON.parse(matchDetails.full_status).long}</div>
                                            </div>
                                        </div>
                                        <div className="league-rows-iteam-match2">
                                            <div className="league-match-data">
                                                <div className="league-match-img">
                                                    <img
                                                        src={homeTeam.icon ? homeTeam.icon : defaultImage}
                                                        alt={homeTeam.display_name || 'league'}
                                                        className="league-live-img"
                                                        onError={(e) => { e.target.src = defaultImage; }}
                                                         loading="lazy" width="20" height="20"
                                                    />

                                                    <span>{homeTeam.display_name}</span>

                                                </div>
                                                <div className="league-match-score">

                                                    {matchDetails.result && JSON.parse(matchDetails.result).fulltime ? (
                                                        <>
                                                            {JSON.parse(matchDetails.result).fulltime.home !== null
                                                                ? JSON.parse(matchDetails.result).fulltime.home
                                                                : '-'}
                                                        </>
                                                    ) : (
                                                        '-'
                                                    )}
                                                </div>
                                            </div>

                                            <div className="league-match-data">
                                                <div className="league-match-img">
                                                    <img
                                                        src={awayTeam.icon ? awayTeam.icon : defaultImage}
                                                        alt={awayTeam.display_name || 'league'}
                                                        className="league-live-img"
                                                        onError={(e) => { e.target.src = defaultImage; }}
                                                         loading="lazy" width="20" height="20"
                                                    />

                                                    <span>{awayTeam.display_name}</span>
                                                </div>
                                                <div className="league-match-score">

                                                    {matchDetails.result && JSON.parse(matchDetails.result).fulltime ? (
                                                        <>
                                                            {JSON.parse(matchDetails.result).fulltime.away !== null
                                                                ? JSON.parse(matchDetails.result).fulltime.away
                                                                : '-'}
                                                        </>
                                                    ) : (
                                                        '-'
                                                    )}
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </Link>
                            );
                        })}

                    </div>

                ) : (
                    <div>No matches available</div>
                )}
            </div>
        </div>
    );

}

function ScorematchD() {

    const [matches, setMatches] = useState([]);
    const [gameMatch, setGameMatch] = useState({});
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

    const [data, setData] = useState([]);
    const [seasonId, setSeasonId] = useState(null);

    useEffect(() => {
        const fetchData = async () => {
            try {
                const response = await fetch('/blog/wp-json/custom/v6/league/season/1/api');
                //    console.log('response', response);
                if (!response.ok) {
                    // If the response status is not OK, throw an error
                    throw new Error(`Error: ${response.status} ${response.statusText}`);
                }

                const jsonData = await response.json();
                setData(jsonData);

                if (jsonData.length > 0) {
                    setSeasonId(jsonData[3].season_id);
                }
            } catch (err) {
                // Log error to console
                console.error('Fetch error:', err);
            }
        };

        fetchData();
    }, []);

    useEffect(() => {
        if (!seasonId) return; // Exit if seasonId is not available

        const fetchMatches = async () => {
            const allSeasonUrl = `/api/season/${seasonId}/game`;

            //   console.log("allSeasonUrl",allSeasonUrl);
            try {
                const response = await fetch(allSeasonUrl, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ type: 'recent' })
                });
                const respData = await response.json();

                if (!respData['status'] || respData['status'] !== 'true' || respData['data'].length === 0) {
                    console.error('Something wrong with the API response', respData);
                    setError(true);
                    return;
                }

                const currentTimeUTC = Math.floor(new Date().getTime() / 1000);
                let scheduleData = respData['data'];

                // Filter and sort for past and upcoming matches
                const lastMatches = scheduleData
                    .filter(game => game.time < currentTimeUTC)
                    .sort((a, b) => b.time - a.time)
                    .slice(0, 3)
                    .reverse();

                let selectedMatches = scheduleData
                    .filter(game => game.time > currentTimeUTC)
                    .sort((a, b) => a.time - b.time)
                    .slice(0, 3);

                if (selectedMatches.length > 0) {
                    selectedMatches = [...lastMatches, ...selectedMatches];
                } else {
                    selectedMatches = lastMatches.concat(
                        scheduleData
                            .filter(game => game.time < currentTimeUTC)
                            .sort((a, b) => b.time - a.time)
                            .slice(0, 6 - selectedMatches.length)
                    );
                }

                setMatches(selectedMatches);
            } catch (error) {
                console.error('Error fetching match data:', error);
                setError(true);
            } finally {
                setLoading(false);
            }
        };

        fetchMatches();
    }, [seasonId]); // Dependency on seasonId

    useEffect(() => {
        if (matches && matches.length > 0) {
            matches.forEach(match => fetchGameDetails(match.id));
        }
    }, [matches]);

    const fetchGameDetails = (matchId) => {
        const LeagueGame = `/api/game/${matchId}`;
        fetch(LeagueGame, { method: 'POST' })
            .then(response => response.json())
            .then(json => {
                if (json && json.data) {
                    setGameMatch(prevState => ({
                        ...prevState,
                        [matchId]: json.data,
                    }));
                    setLoading(false);
                } else {
                    const errorMessage = `Game data not found for match ${matchId}`;
                    console.error(errorMessage);

                }
            })
            .catch(() => {
                const errorMessage = `Error fetching game data for match ${matchId}`;
                console.error(errorMessage);
                // setError(errorMessage);
            });
    };


    if (loading) {
        return <div>Loading...</div>;
    }

    if (error) {
        return <div>Error: {error}</div>;
    }

    return (
        <div className="league-section-main">
            <div className="league-section-row">
                <div className="header-bg-slide">
                    {data.length > 0 && (
                        <div className="header-flex" key={data[3].id}>
                            <div className="country-images">
                                <img
                                    src={data[3].country_icon}
                                    alt={data[3].country_alt}
                                    width="20"
                                    height="20"
                                    className="country-icon"
                                     loading="lazy"
                                />
                            </div>
                            <div className="country-content">
                                <Link to={data[3].league_link}>
                                    <span className="country-name">
                                        {data[3].country_name}
                                    </span>
                                    <h3 className="text-slide">
                                        {data[3].league_name}
                                    </h3>
                                </Link>
                            </div>
                        </div>
                    )}


                </div>

                {matches && matches.length > 0 ? (

                    <div className="league-container">

                        {matches.map(match => {


                            const matchDetails = gameMatch[match.id] || {}; // Get match details from state
                            const homeTeam = matchDetails.home || {};
                            const awayTeam = matchDetails.away || {};
                            //const matchDate = new Date(matchDetails.date); // Format the date
                            const hometime = matchDetails.time;
                            const utctime = LocalTime(hometime);

                            let defaultImage = '/bet-assets/site/image/defaulticon.svg';

                            const gamesurl = match['name'] ? match['name'].replace(/\s+/g, '-').replace(/\//g, '-').replace(/-+/g, '-').toLowerCase() : "";
                            const idgame = match["id"] ? match["id"] : "";
                            const gameurlslug = `${gamesurl}/${idgame}`;

                            return (
                                <Link to={`/football/game/${gameurlslug}`} key={`row-${match.id}`}>
                                    <div className="league-rows" >
                                        <div className="league-rows-iteam-match1">
                                            <div className="league-rows-iteam-time">
                                                <div className="match-date">
                                                    <div className="match-date">{utctime} </div>
                                                </div>
                                                <div className="match-status">{matchDetails.full_status && JSON.parse(matchDetails.full_status).long}</div>
                                            </div>
                                        </div>
                                        <div className="league-rows-iteam-match2">
                                            <div className="league-match-data">
                                                <div className="league-match-img">
                                                    <img
                                                        src={homeTeam.icon ? homeTeam.icon : defaultImage}
                                                        alt={homeTeam.display_name || 'league'}
                                                        className="league-live-img"
                                                        onError={(e) => { e.target.src = defaultImage; }}
                                                         loading="lazy" width="20" height="20"
                                                    />

                                                    <span>{homeTeam.display_name}</span>

                                                </div>
                                                <div className="league-match-score">

                                                    {matchDetails.result && JSON.parse(matchDetails.result).fulltime ? (
                                                        <>
                                                            {JSON.parse(matchDetails.result).fulltime.home !== null
                                                                ? JSON.parse(matchDetails.result).fulltime.home
                                                                : '-'}
                                                        </>
                                                    ) : (
                                                        '-'
                                                    )}
                                                </div>
                                            </div>

                                            <div className="league-match-data">
                                                <div className="league-match-img">
                                                    <img
                                                        src={awayTeam.icon ? awayTeam.icon : defaultImage}
                                                        alt={awayTeam.display_name || 'league'}
                                                        className="league-live-img"
                                                        onError={(e) => { e.target.src = defaultImage; }}
                                                         loading="lazy" width="20" height="20"
                                                    />

                                                    <span>{awayTeam.display_name}</span>
                                                </div>
                                                <div className="league-match-score">

                                                    {matchDetails.result && JSON.parse(matchDetails.result).fulltime ? (
                                                        <>
                                                            {JSON.parse(matchDetails.result).fulltime.away !== null
                                                                ? JSON.parse(matchDetails.result).fulltime.away
                                                                : '-'}
                                                        </>
                                                    ) : (
                                                        '-'
                                                    )}
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </Link>
                            );
                        })}

                    </div>

                ) : (
                    <div>No matches available</div>
                )}
            </div>
        </div>
    );

}

export default Scorematch;
export { ScorematchB, ScorematchC, ScorematchD };