import { useState, useEffect } from 'react';
import { getFromDB, setToDB } from '../../utility/DB';

/**
 * Custom React hook to get list of countries by Slug from API ("/api/widget/${endpoint}"),
 * with IndexedDB caching using the utility functions.
 * @param {string} dynamicSlug 
 * @returns 
 */
export default function useTopLeagueList(dynamicSlug) {
  const [leagueData, setLeagueData] = useState([]);   // State variable to hold league array
  const [loading, setLoading] = useState(true);    // For Loading State
  const [error, setError] = useState("");

  const endpoint = `top-leagues-${dynamicSlug}`
  const api = `/api/widget/${endpoint}`; //API endpoint for fetching Top league data by Slug
  const CACHE_KEY = `top_leagues_${dynamicSlug}`; // Key under which data is stored in IndexedDB

  useEffect(() => {
    let isMounted = true;  // Flag to prevent state updates after component unmount

    /**
     * Fetch countries code by slug from IndexedDB cache first.
     * If not present, fetch from API and cache the result.
     */
    async function fetchAndCache() {
      try {
        setLoading(true);


        // Try to retrieve cached countries from IndexedDB
        const cached = await getFromDB(CACHE_KEY);

        // If countries exist in cache and not empty, set to state
        if (cached && cached.length > 0) {
          if (isMounted) {
            setLeagueData(cached);
            setLoading(false);
          }
          return;
        } 
        
          // Not in cache: fetch from API, store in state and cache
          const resp = await fetch(api, { method: 'POST' });          // API fetch (GET method)
          const json = await resp.json();                            // Parse JSON response

          if (json.status === "true" && json.data) {
            const targetData = json.data.find(
              (item) => item.name === endpoint
            );
                        
            if (!targetData || !targetData.data) {
              throw new Error("Invalid data format");
            }
            
            const parsedData = JSON.parse(targetData.data);
            
            if (isMounted) {
              setLeagueData(parsedData);          // Set state with fetched data
              setLoading(false);
            }
            
            
            await setToDB(CACHE_KEY, parsedData);       // Save fetched data to IndexedDB
          } else {
          throw new Error("API returned invalid data");
        }
          

      } catch (error) {
        // Handle errors (IndexedDB or fetch failed): fallback to API fetch
        console.error("IndexedDB or fetch error:", error);

        if (isMounted) {
          setError(err.message);
          setLeagueData([]);
          setLoading(false);
        }
      }
    }

    // If slug not supported, skip the API
    if (!endpoint) {
      setError("Sport not supported");
      setLeagueData([]);
      setLoading(false);
      return;
    }

    
    // Begin fetch-and-cache logic on component mount/update
    fetchAndCache();

    // Cleanup function to prevent state updates after unmount
    return () => { isMounted = false };

  }, [api]);

  // At the end of your hook, before return
// console.log('Hook returning:', { countries, loading });

  return { leagueData, loading, error };
}
