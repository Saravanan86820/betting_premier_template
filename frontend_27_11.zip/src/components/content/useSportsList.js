import React from "react";

/**
 * 
 * @param {string} slug - The dynamic slug (e.g., "football", "basketball").
 * @returns {string | undefined} The corresponding sport name, or undefined if the slug is not found.
 */
export default function useSportsList(slug) {
    const sports = {
        'football': "Football",
        'ice-hockey': "Ice Hockey",
        'basketball': "Basketball",
        'baseball': "Baseball",
        'rugby': "Rugby",
        'volleyball': "Volleyball",
        'handball': "Handball"
    };

    const sportName = sports[slug];

    return sportName;
}