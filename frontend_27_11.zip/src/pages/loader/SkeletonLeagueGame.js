import React from "react";
import "./Loader.css";

export default function SkeletonLeagueGame() {
  return (
    <div className="bet-skeleton-league-page bet-skeleton-wrap">

        {/* Game Section */}
        <div className="bet-card-skeleton">
          <div className="bet-card-title bet-skeleton-line"></div>

          {[1, 2, 3, 4, 5].map((i) => (
            <div className="bet-game-row-skeleton" key={i}>
              <div className="bet-team">
                <div className="bet-team-logo bet-skeleton-logo"></div>
                <div className="bet-team-name bet-skeleton-line"></div>
              </div>

              <div className="bet-score bet-skeleton-line"></div>
            </div>
          ))}
        </div>


    </div>
  );
}
