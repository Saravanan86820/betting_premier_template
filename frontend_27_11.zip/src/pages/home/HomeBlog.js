import React, { useEffect, useState, useRef } from 'react';
import './HomeBlog.css';

function HomeBlog() {
    const [posts, setPosts] = useState([]);
    const [error, setError] = useState('');
    const [currentIndex, setCurrentIndex] = useState(0);

    // Direction: 1 = forward, -1 = backward
    const [direction, setDirection] = useState(1);

    // ⭐ NEW: useRef for swipe start position
    const touchStartX = useRef(null);

    useEffect(() => {
        const fetchPost = async () => {
            try {
                const response = await fetch('/blog/wp-json/custom/v3/league/blog');
                const jsonresult = await response.json();

                if (response.ok) setPosts(jsonresult);
                else setError('Failed to fetch posts');
            } catch (err) {
                setError('An error occurred while fetching data');
            }
        };
        fetchPost();
    }, []);

    // Auto slide forward → backward → forward (infinite loop)
    useEffect(() => {
        if (posts.length === 0) return;

        const interval = setInterval(() => {
            setCurrentIndex(prevIndex => {
                let nextIndex = prevIndex + direction;

                if (nextIndex >= posts.slice(0, 6).length) {
                    setDirection(-1);
                    nextIndex = prevIndex - 1;
                } 
                else if (nextIndex < 0) {
                    setDirection(1);
                    nextIndex = prevIndex + 1;
                }

                return nextIndex;
            });
        }, 3500);

        return () => clearInterval(interval);
    }, [posts, direction]);

    // Touch Start → store swipe start using useRef
    const handleTouchStart = (e) => {
        touchStartX.current = e.touches[0].clientX;
    };

    // Touch End → compare swipe end with start
    const handleTouchEnd = (e) => {
        const endX = e.changedTouches[0].clientX;
        const diff = touchStartX.current - endX;

        // Swipe left → next
        if (diff > 50) {
            setDirection(1);
            setCurrentIndex(i =>
                i === posts.slice(0, 6).length - 1 ? i : i + 1
            );
        }
        // Swipe right → previous
        else if (diff < -50) {
            setDirection(-1);
            setCurrentIndex(i => (i === 0 ? i : i - 1));
        }
    };

    if (error) return <p>{error}</p>;
    if (posts.length === 0) return <p>Loading...</p>;

    return (
        <>
            <div
                className="slideshow"
                onTouchStart={handleTouchStart}
                onTouchEnd={handleTouchEnd}
            >
                <div
                    className="slideshow__slides"
                    style={{
                        transform: `translateX(-${currentIndex * 100}%)`,
                        transition: "transform 0.6s ease-in-out"
                    }}
                >
                    {posts.slice(0, 6).map((post) => (
                        <a href={post.link} key={post.id} className="slideshow__slide">
                            <div
                                className="slideshow__image"
                                style={{ backgroundImage: `url(${post.featured_image_url})` }}
                            >
                                <div className="slideshow__overlay">
                                    <h2 className="slideshow__title">{post.title}</h2>
                                </div>
                            </div>
                        </a>
                    ))}
                </div>
            </div>

            <div className="slideshow__dots">
                {posts.slice(0, 6).map((_, idx) => (
                    <span
                        key={idx}
                        className={`dot ${idx === currentIndex ? 'active' : ''}`}
                        onClick={() => {
                            setDirection(idx > currentIndex ? 1 : -1);
                            setCurrentIndex(idx);
                        }}
                    ></span>
                ))}
            </div>
        </>
    );
}

export default HomeBlog;
