import React from "react";

import { useParams, Link } from 'react-router-dom';

function HandballMatch() {
    return (

        <>

            <div className="league-main-container">

                <div className="league-main-row">
                    <div className="league-center-title">
                        <div className="imageflex">
                            <img src="/assets/image/handball/handball-game.svg" alt="League" width="36" height="36" className="league-imageflex" loading="lazy" />
                            <h4 className="league-heading-sub">Game Handball</h4>
                        </div>
                    </div>

                    <div className="league-match-data-single">

                        <div className="league-container">

                            <Link to="/basketball/game">

                                <div className="league-rows" >
                                    <div className="league-rows-iteam-match1">
                                        <div className="league-rows-iteam-time">
                                            <div className="match-date">
                                                <div>  December 8, 2024 at 10:30 PM </div>
                                            </div>
                                            <div className="match-status"> Match Finished</div>
                                        </div>
                                    </div>


                                    <div className="league-rows-iteam-match2">
                                        <div className="league-match-data">
                                            <div className="league-match-img">
                                                <img src="/bet-assets/site/image/football/team/venezia-517-670e67cf50fc2887.png" alt="Venezia" className="league-live-img" loading="lazy" width="20" height="20" />

                                                <span>Venezia</span>

                                            </div>
                                            <div className="league-match-score">
                                                <div className="baseball-score-row">

                                                    <div className="baseball-score-list">
                                                        <div className="baseball-score"> 218 </div>
                                                        <div className="baseball-score"> 218 </div>
                                                        <div className="baseball-score"> 218 </div>
                                                        <div className="baseball-score"> 218 </div>
                                                    </div>

                                                    <div className="baseball-score-list">
                                                        <div className="baseball-score score--bold"> 118  </div>

                                                    </div>

                                                </div>

                                            </div>
                                        </div>

                                        <div className="league-match-data">
                                            <div className="league-match-img">
                                                <img src="/bet-assets/site/image/football/team/como-895-670e686a3cfdc874.png" alt="como" className="league-live-img" loading="lazy" width="20" height="20" />

                                                <span>Venezia</span>
                                            </div>
                                            <div className="league-match-score">
                                                <div className="baseball-score-row">

                                                    <div className="baseball-score-list">
                                                        <div className="baseball-score"> 218 </div>
                                                        <div className="baseball-score"> 218 </div>
                                                        <div className="baseball-score"> 218 </div>
                                                        <div className="baseball-score"> 218 </div>
                                                    </div>

                                                    <div className="baseball-score-list">
                                                        <div className="baseball-score score--bold"> 118  </div>

                                                    </div>

                                                </div>

                                            </div>
                                        </div>
                                    </div>

                                </div>
                            </Link>
                            {/* second */}

                            <Link to="/basketball/game">
                                <div className="league-rows" >
                                    <div className="league-rows-iteam-match1">
                                        <div className="league-rows-iteam-time">
                                            <div className="match-date">
                                                <div>  December 8, 2024 at 10:30 PM </div>
                                            </div>
                                            <div className="match-status"> Match Finished</div>
                                        </div>
                                    </div>


                                    <div className="league-rows-iteam-match2">
                                        <div className="league-match-data">
                                            <div className="league-match-img">
                                                <img src="/bet-assets/site/image/football/team/venezia-517-670e67cf50fc2887.png" alt="Venezia" className="league-live-img" loading="lazy" width="20" height="20" />

                                                <span>Venezia</span>

                                            </div>
                                            <div className="league-match-score">
                                                <div className="baseball-score-row">

                                                    <div className="baseball-score-list">
                                                        <div className="baseball-score"> 218 </div>
                                                        <div className="baseball-score"> 218 </div>
                                                        <div className="baseball-score"> 218 </div>
                                                        <div className="baseball-score"> 218 </div>
                                                    </div>

                                                    <div className="baseball-score-list">
                                                        <div className="baseball-score score--bold"> 118  </div>

                                                    </div>

                                                </div>

                                            </div>
                                        </div>

                                        <div className="league-match-data">
                                            <div className="league-match-img">
                                                <img src="/bet-assets/site/image/football/team/como-895-670e686a3cfdc874.png" alt="como" className="league-live-img" loading="lazy" width="20" height="20" />

                                                <span>Venezia</span>
                                            </div>
                                            <div className="league-match-score">
                                                <div className="baseball-score-row">

                                                    <div className="baseball-score-list">
                                                        <div className="baseball-score"> 218 </div>
                                                        <div className="baseball-score"> 218 </div>
                                                        <div className="baseball-score"> 218 </div>
                                                        <div className="baseball-score"> 218 </div>
                                                    </div>

                                                    <div className="baseball-score-list">
                                                        <div className="baseball-score score--bold"> 118  </div>

                                                    </div>

                                                </div>

                                            </div>
                                        </div>
                                    </div>

                                </div>

                            </Link>

                            {/* third  */}


                            <div className="league-rows" >
                                <div className="league-rows-iteam-match1">
                                    <div className="league-rows-iteam-time">
                                        <div className="match-date">
                                            <div>  December 8, 2024 at 10:30 PM </div>
                                        </div>
                                        <div className="match-status"> Match Finished</div>
                                    </div>
                                </div>


                                <div className="league-rows-iteam-match2">
                                    <div className="league-match-data">
                                        <div className="league-match-img">
                                            <img src="/bet-assets/site/image/football/team/venezia-517-670e67cf50fc2887.png" alt="Venezia" className="league-live-img" loading="lazy" width="20" height="20" />

                                            <span>Venezia</span>

                                        </div>
                                        <div className="league-match-score">
                                            <div className="baseball-score-row">

                                                <div className="baseball-score-list">
                                                    <div className="baseball-score"> 218 </div>
                                                    <div className="baseball-score"> 218 </div>
                                                    <div className="baseball-score"> 218 </div>
                                                    <div className="baseball-score"> 218 </div>
                                                </div>

                                                <div className="baseball-score-list">
                                                    <div className="baseball-score score--bold"> 118  </div>

                                                </div>

                                            </div>

                                        </div>
                                    </div>

                                    <div className="league-match-data">
                                        <div className="league-match-img">
                                            <img src="/bet-assets/site/image/football/team/como-895-670e686a3cfdc874.png" alt="como" className="league-live-img" loading="lazy" width="20" height="20" />

                                            <span>Venezia</span>
                                        </div>
                                        <div className="league-match-score">
                                            <div className="baseball-score-row">

                                                <div className="baseball-score-list">
                                                    <div className="baseball-score"> 218 </div>
                                                    <div className="baseball-score"> 218 </div>
                                                    <div className="baseball-score"> 218 </div>
                                                    <div className="baseball-score"> 218 </div>
                                                </div>

                                                <div className="baseball-score-list">
                                                    <div className="baseball-score score--bold"> 118  </div>

                                                </div>

                                            </div>

                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>

                    </div>
                </div>
            </div >


        </>

    );
}

export default HandballMatch;