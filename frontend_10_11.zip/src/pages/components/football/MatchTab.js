import React, { useEffect, useState } from 'react';
import '../Components.css';



import Statistics from "./Statistics";
import Lineups from "./Lineups";
import Event from "./Event";

function MatchTab({ homeTeamIcon, awayTeamIcon, id, homeProvd_id, awayProvd_id, homeName, awayName }) {
  const [availableTabs, setAvailableTabs] = useState([]); // Store available tabs
  const [activeTab, setActiveTab] = useState(0);
  const [loading, setLoading] = useState(true);
  const [tabLoading, setTabLoading] = useState(false);

  const lineupAPI = `/api/sports/football/game/${id}/stats`;

  useEffect(() => {
    fetch(lineupAPI, { method: 'POST' })
      .then(response => response.json())
      .then(respData => {
        if (respData['status'] !== 'true' || !respData['data']) {
          setLoading(false);
          return;
        }

        const data = respData['data'];
        //  console.log("data", data);
        const tabs = [];

        // Check and add tabs based on the type
        Object.values(data).forEach(item => {
          if (item.type === 'statistics') tabs.push({ label: 'Statistics', content: <Statistics id={id} /> });
          if (item.type === 'lineup') tabs.push({ label: 'Lineups', content: <Lineups homeTeamIcon={homeTeamIcon} awayTeamIcon={awayTeamIcon} id={id} /> });
          if (item.type === 'events') tabs.push({ label: 'Event', content: <Event id={id} homeProvd_id={homeProvd_id} awayProvd_id={awayProvd_id} homeName={homeName} awayName={awayName} /> });
        });

        const reorderedTabs = tabs.sort((a, b) => {
          if (a.label === 'Event') return -1;
          if (b.label === 'Event') return 1;
          return 0;
        });

        setAvailableTabs(reorderedTabs);
        // console.log('Available Tabs:', tabs); 
        setLoading(false);
      })
      .catch(err => {
        console.error('Error fetching data:', err);
        setLoading(false);
      });
  }, [id]);

  const handleTabClick = (index) => {
    setTabLoading(true); // Show loading spinner
    setActiveTab(index);

    // Simulate a delay for loading (replace this with actual async logic if needed)
    setTimeout(() => {
      setTabLoading(false); // Hide spinner after content loads
    }, 350); // Adjust time based on real loading
  };

  if (loading) {
    return <div>Loading...</div>;
  }

  if (availableTabs.length === 0) {
    return null;  // Show message if no tabs are available
  }

  // console.log('Rendering Available Tabs:', availableTabs);

  const typeImageMap = {
    Lineups: '/assets/image/lineup.png',
    Event: '/assets/image/event.png',
    Statistics: '/assets/image/stat.png',
  };


  return (


    <div className="lineups-container">
      <div className="lineups-container-row">
        
        <div className="tabs">
          <div className="tab_buttons">
            {availableTabs.map((tab, index) => (
              <button
                key={index}
                className={`tab_button ${activeTab === index ? 'active' : ''}`}
                data-type={tab.label}
                onClick={() => handleTabClick(index)}
              >

                {typeImageMap[tab.label] && (
                  <img
                    src={typeImageMap[tab.label]}
                    alt={tab.label}
                    width="18"
                    height="18"
                    className="league-imageflex"
                    loading="lazy"
                  />
                )}
                <span className="tab--name"> {tab.label}  </span>
              </button>
            ))}
          </div>
          <div className="tab_content">
            {tabLoading ? (
              <div className="spinner"></div> // Add spinner style here
            ) : (
              availableTabs[activeTab].content
            )}

          </div>
        </div>
      </div>
    </div>
  );
}

export default MatchTab;
