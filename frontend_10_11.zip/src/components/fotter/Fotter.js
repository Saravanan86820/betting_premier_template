import React from "react";
import './Fotter.css';

import { Link } from 'react-router-dom';

function Fotter() {

  return (

    <>
      <footer id="mvp-foot-wrap" className="footer-container" style={{
        backgroundImage: `linear-gradient(#edf1f6, #f4f4f4db), url("/assets/image/common/footer-bg.png")`
      }}>

        <div className="mvp-main-box-cont footer-row">
          <div id="mvp-foot-logo" className="left relative">
            <a href=""><img src="/assets/image/common/logo.svg" alt="Sports Betting News | Betting Stream" width="250"  height="80" loading="lazy"/></a>
          </div>

        </div>
        <div id="mvp-foot-menu-wrap" className="foot-left">
          <div className="mvp-main-box-cont">
            <div id="mvp-foot-menu" className="footerleft">


              <ul id="menu-menu-footer1" className="menu">
                <li className="menu-item menu-item-type-custom ">  <a href="/blog/" target="_blank"> Latest </a> </li>
                {/* <li className="menu-item"> <a href="/blog/bet365-live-stream-schedule/" target="_blank"> Stream Schedule </a> </li> */}
                <li className="menu-item">  <Link to="/football">Football </Link></li>
                <li className="menu-item">  <Link to="/ice-hockey">Ice Hockey </Link></li>
                <li className="menu-item">  <Link to="/baseball/"> Baseball </Link></li>
                <li className="menu-item">  <Link to="/basketball/"> Basketball </Link></li>
                <li className="menu-item">  <Link to="/volleyball/"> volleyball </Link></li>
              </ul>


            </div>
          </div>
        </div>

        <div id="mvp-foot-copy-wrap" className="left-last">
          <div className="mvp-main-box-cont">


            <div className="bet-footer">
              <div className="s-bet-footer">
                <span className="bet-footer__left bet-footer__copyrights">Copyright © 2025 BettingPremier.</span>

              </div>
              <div className="bet-footer__right">
                <span className="bet-footer__right-line">18+ Only. Please gamble responsibly!
                  <img className="footer-brand-logo" src="/assets/image/common/fotterbrand.png"  width="200"  height="20"  loading="lazy" />
                  
                </span>
                <span className="bet-footer__right-line"> 18+| Erlaubt (White-list)| Suchtrisiken | Hilfe unter buwei.de (ENG: Allowed (white list) | Risk of addiction | Help at buwei.de.)   </span>
              </div>
            </div>
          </div>
        </div>

      </footer>



    </>
  );
}

export default Fotter;