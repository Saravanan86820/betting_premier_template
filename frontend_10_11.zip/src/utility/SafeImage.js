import React, { useState } from "react";

/**
 * create image with fallback image
 * @param {Object} param0 
 * @returns {JSX.Element}
 */
export default function SafeImage({ src, fallbackSrc, alt, ...props }) {
  const [imgSrc, setImgSrc] = useState(src);
  const [hasError, setHasError] = useState(false);

  const handleError = () => {
    if (!hasError && fallbackSrc) {
      setImgSrc(fallbackSrc);
      setHasError(true);
    }
  };

  return <img src={imgSrc} onError={handleError} alt={alt} {...props} />;
}

