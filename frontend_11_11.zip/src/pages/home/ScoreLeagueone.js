import React, { useState, useEffect } from "react";
import '../../index.css';
import { useParams, Link } from 'react-router-dom';
import matchlogo from '../../assets/image/imageapi/2.png';
import LocalTime from "../../utility/LocalTime";


function ScoreLeagueone() {

    const [matches, setMatches] = useState([]);
    const [gameMatch, setGameMatch] = useState({});
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

    useEffect(() => {
        const AllseasonUrl = "/api/season/511/game";
        fetch(AllseasonUrl, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ type: 'recent' }) })
            .then(response => response.json())
            .then(respData => {
                if (!respData['status'] || respData['status'] !== 'true' || respData['data'].length === 0) {
                  console.error('Somthing wrong with the API response', respData);
                  setError(true);
                  return;
                }
        
                const currentTimeUTC = Math.floor(new Date().getTime() / 1000);
                let selectedMatches = [];
                let scheduleData = respData['data'];
                let lastmatches = scheduleData
                  .filter(game => game['time'] < currentTimeUTC)
                  .sort((a, b) => b.time - a.time)
                  .slice(0, 5)
                  .reverse(); ;
             
        
                // upcoming matches
                selectedMatches = scheduleData
                  .filter(game => game['time'] > currentTimeUTC)
                  .sort((a, b) => a.time - b.time)
                  .slice(0, 5); 
               
                 // console.log("selectedMatches",selectedMatches);
                if (selectedMatches.length > 0)
                  selectedMatches = [...lastmatches, ...selectedMatches];
                else
                  selectedMatches = selectedMatches
                    .concat(scheduleData
                      .filter(game => game['time'] < currentTimeUTC)
                      .sort((a, b) => b['time'] - a['time'])
                      .slice(0, 10 - selectedMatches.length));

                     // console.log("selectedMatches1",selectedMatches);
 
                setMatches(selectedMatches);
                setLoading(false);
              })
              .catch(error => {
              
                console.error('Error fetching match data:', error);
                setLoading(false);
              });
    }, []);

    useEffect(() => {
        if (matches && matches.length > 0) {
            matches.forEach(match => fetchGameDetails(match.id));
        }
    }, [matches]);

    const fetchGameDetails = (matchId) => {
        const LeagueGame = `/api/game/${matchId}`;
        fetch(LeagueGame, { method: 'POST' })
            .then(response => response.json())
            .then(json => {
                if (json && json.data) {
                    setGameMatch(prevState => ({
                        ...prevState,
                        [matchId]: json.data,
                    }));
                    setLoading(false);
                } else {
                    setError(`Game data not found for match ${matchId}`);
                }
            })
            .catch(() => setError(`Error fetching game data for match ${matchId}`));
    };


    if (loading) {
        return <div>Loading...</div>;
    }

    if (error) {
        return <div>Error: {error}</div>;
    }

    return (
        <div className="league-section-main">
            <div className="league-section-row">
                <div className="header-bg-slide">
                    <div className="header-flex">
                        <div className="country-images">

                            <img
                                src="/bet-assets/site/image/country/it.svg"
                                alt="Italy"
                                width="26"
                                height="26"
                                className="country-icon"
                            />

                        </div>
                        <div>
                            <span className="country-name">
                                Italy
                            </span>
                            <h3 className="text-slide">
                                Serie A2
                            </h3>
                        </div>
                    </div>
                </div>

                {matches && matches.length > 0 ? (

                    <div className="league-container">

                        {matches.map(match => {


                            const matchDetails = gameMatch[match.id] || {}; // Get match details from state
                            const homeTeam = matchDetails.home || {};
                            const awayTeam = matchDetails.away || {};
                            //const matchDate = new Date(matchDetails.date); // Format the date
                            const hometime = matchDetails.time;
                            const  utctime = LocalTime(hometime);

                            let defaultImage = '/assets/image/defaulticon.svg';

                            const gamesurl = match['name'] ? match['name'].replace(/\s+/g, '-').replace(/-+/g, '-').toLowerCase() : "";
                            const idgame = match["id"] ? match["id"] : "";
                            const gameurlslug = `${gamesurl}/${idgame}`;

                            return (
                                <Link to={`/football/game/${gameurlslug}`} key={match.id}>
                                    <div className="league-rows" >
                                        <div className="league-rows-iteam-match1">
                                            <div className="league-rows-iteam-time">
                                                <div className="match-date">
                                                    <div>{utctime} </div>
                                                </div>
                                                <div className="match-status">{matchDetails.full_status && JSON.parse(matchDetails.full_status).long}</div>
                                            </div>
                                        </div>
                                        <div className="league-rows-iteam-match2">
                                            <div className="league-match-data">
                                                <div className="league-match-img">
                                                    <img
                                                        src={homeTeam.icon ? homeTeam.icon : defaultImage}
                                                        alt={homeTeam.display_name || 'league'}
                                                        className="league-live-img"
                                                        onError={(e) => { e.target.src = defaultImage; }}
                                                    />

                                                    <span>{homeTeam.display_name}</span>

                                                </div>
                                                <div className="league-match-score">

                                                    {matchDetails.result && JSON.parse(matchDetails.result).fulltime ? (
                                                        <>
                                                            {JSON.parse(matchDetails.result).fulltime.home !== null
                                                                ? JSON.parse(matchDetails.result).fulltime.home
                                                                : '-'}
                                                        </>
                                                    ) : (
                                                        '-'
                                                    )}
                                                </div>
                                            </div>

                                            <div className="league-match-data">
                                                <div className="league-match-img">
                                                    <img
                                                        src={awayTeam.icon ? awayTeam.icon : defaultImage}
                                                        alt={awayTeam.display_name || 'league'}
                                                        className="league-live-img"
                                                        onError={(e) => { e.target.src = defaultImage; }}
                                                    />

                                                    <span>{awayTeam.display_name}</span>
                                                </div>
                                                <div className="league-match-score">

                                                    {matchDetails.result && JSON.parse(matchDetails.result).fulltime ? (
                                                        <>
                                                            {JSON.parse(matchDetails.result).fulltime.away !== null
                                                                ? JSON.parse(matchDetails.result).fulltime.away
                                                                : '-'}
                                                        </>
                                                    ) : (
                                                        '-'
                                                    )}
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </Link>
                            );
                        })}

                    </div>

                ) : (
                    <div>No matches available</div>
                )}
            </div>
        </div>
    );
}

export default ScoreLeagueone;
