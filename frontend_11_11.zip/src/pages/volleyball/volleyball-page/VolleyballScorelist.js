import React, { useState, useEffect } from "react";
import { useParams, Link } from 'react-router-dom';
import LocalTime from "../../../utility/LocalTime";

import useFetchMatches from "./useFetchMatches";


function VolleyballScorelist() {

   
  const { data, matches, gameMatch, loading, error, dynamicSlug } = useFetchMatches();


  if (loading) {
    return <div>Loading...</div>;
  }

  if (error) {
    return <div>Error: {error}</div>;
  }

  const mergedData = data.map((item) => {
    // Find matches corresponding to the current item's season_id
    const relatedMatches = matches.filter((match) => {
      const matchDetails = gameMatch[match.id] || {};
      return Number(matchDetails.season_id) === Number(item.season_id);
    });

    return {
      ...item,
      relatedMatches, // Add the filtered matches to the item
    };
  });

  return (
    <>

      <div className="league-section-main">

        {mergedData.map((item, index) => (
          <div className="league-section-row" key={item.id || index} data-id={item.id || index}>
            <div className="header-bg-slide">

              <div className="header-flex">
                <div className="country-images">
                  <img
                    src={item.country_icon}
                    alt={item.country_alt}
                    width="20"
                    height="20"
                    className="country-icon"
                    loading="lazy"
                  />
                </div>
                <div className="country-content">
                  <Link to={item.league_link}>
                    <span className="country-name">
                      {item.country_name}
                    </span>
                    <h3 className="text-slide">
                      {item.league_name}
                    </h3>
                  </Link>
                </div>
              </div>


            </div>

            <div className="league-container sport-loop" id="sport_data-loop">

              {item.relatedMatches.map((match, index) => {


                const matchDetails = gameMatch[match.id] || {};
                const homeTeam = matchDetails.home || {};
                const awayTeam = matchDetails.away || {};
                //const matchDate = new Date(matchDetails.date); // Format the date
                const hometime = matchDetails.time;
                const utctime = LocalTime(hometime);

                let defaultImage = '/assets/image/volleyball/d-volleyball.svg';


                const gamesurl = match['name'] ? match['name'].replace(/\s+/g, '-').replace(/\//g, '-').replace(/-+/g, '-').toLowerCase() : "";
                const idgame = match["id"] ? match["id"] : "";
                const gameurlslug = `${gamesurl}/${idgame}`;

                return (
                  <Link to={`/${dynamicSlug}/game/${gameurlslug}`} key={index}>
                    <div className="league-rows" >
                      <div className="league-rows-iteam-match1">
                        <div className="league-rows-iteam-time">
                          <div className="match-date">
                            <div className="match-date">{utctime} </div>
                          </div>
                          <div className="match-status">{matchDetails.full_status && JSON.parse(matchDetails.full_status).long}</div>
                        </div>
                      </div>
                      <div className="league-rows-iteam-match2">
                        <div className="league-match-data">
                          <div className="league-match-img">
                            <img
                              src={homeTeam.icon ? homeTeam.icon : defaultImage}
                              alt={homeTeam.display_name || 'league'}
                              className="league-live-img"
                              onError={(e) => { e.target.src = defaultImage; }}
                              loading="lazy" width="20" height="20"
                            />

                            <span>{homeTeam.display_name}</span>

                          </div>
                          <div className="league-match-score">

                            {matchDetails.result && JSON.parse(matchDetails.result).home !== null ? 
                              JSON.parse(matchDetails.result).home
                             : 
                              '-'
                            }


                          </div>
                        </div>

                        <div className="league-match-data">
                          <div className="league-match-img">
                            <img
                              src={awayTeam.icon ? awayTeam.icon : defaultImage}
                              alt={awayTeam.display_name || 'league'}
                              className="league-live-img"
                              onError={(e) => { e.target.src = defaultImage; }}
                              loading="lazy" width="20" height="20"
                            />

                            <span>{awayTeam.display_name}</span>
                          </div>
                          <div className="league-match-score">

                            {matchDetails.result && JSON.parse(matchDetails.result).away !== null ? (
                              JSON.parse(matchDetails.result).away
                            ) : (
                              '-'
                            )}

                          </div>
                        </div>
                      </div>
                    </div>
                  </Link>
                );
              })}

            </div>


          </div>
        ))}
      </div>



    </>
  );
}

export default VolleyballScorelist;