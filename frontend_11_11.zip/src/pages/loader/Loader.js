// src/components/Loader.js
import React from 'react';
import './Loader.css'; // Import the CSS file containing styles

const Loader = () => {

  // console.log("loading1");
  return (
    

    <div className="bet-page-loading">
      <div className="bet-page-loading-wrapper">
        <img className="bet-page-loading__ball" src="/assets/image/ball.svg" loading="lazy"/>
        <img className="bet-page-loading__grass" src="/assets/image/grass.svg" loading="lazy"/>
      </div>
    </div>



  );
};

export default Loader;
