/**
 * Filters, groups, and sorts games for schedule or live usage.
 * 
 * @param {Array} schedule - List of game objects
 * @param {Object} options - { mode: 'scheduled' | 'live', selectedDate?: 'yyyy-mm-dd' }
 * @returns {Object} { gameList, leagues, leagueOrder }
 */
export default function SortGames(schedule, options) {
  let gameList = {};
  let leagueList = {};
  const now = Date.now();

  schedule.forEach(game => {
    let valid = false;

    if (options.mode === 'scheduled') {
      // Date filter (local day)
      const gameLocalDate = new Date(parseInt(game.time, 10) * 1000)
        .toLocaleDateString('en-CA');
      valid = (gameLocalDate === options.selectedDate);
    } else if (options.mode === 'live') {
      const gameTimeMs = game.time * 1000;
      // Within past 24h and not in future
      valid = !(gameTimeMs + 24 * 60 * 60 * 1000 < now || gameTimeMs > now);
    }

    if (!valid) return;

    if (!gameList[game.league_id])
      gameList[game.league_id] = [];
    if (!leagueList[game.league_id])
      leagueList[game.league_id] = game.league;
    gameList[game.league_id].push(game);
  });

  // Sorting logic for leagues
  const leagueArr = Object.values(leagueList).sort((a, b) => {
    // Big leagues first
    if (a.big === 1 && b.big !== 1) return -1;
    if (b.big === 1 && a.big !== 1) return 1;
    // Then by country code
    if (a.country_code < b.country_code) return -1;
    if (a.country_code > b.country_code) return 1;
    // Then league name
    if (a.display_name < b.display_name) return -1;
    if (a.display_name > b.display_name) return 1;
    return 0;
  });

  const leagueOrder = leagueArr.map(l => l.id);

  return {
    gameList,
    leagueList,
    leagueOrder
  };
}
