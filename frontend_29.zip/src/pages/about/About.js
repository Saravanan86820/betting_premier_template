import React from "react";
import './About.css';

import { Link } from 'react-router-dom';



function About() {


    return (

        <>

            <div className="flex-container-about">
                <div className="flex-about-item">
                    <div className="flex-about-list image-center">
                        <img src="/assets/image/common/allsport.svg" alt="aboutimage" width="500"  height="380" className="about-image" loading="lazy"/>
                    </div>
                    <div className="flex-about-list">
                        {/* <span className="span-date">About Us</span> */}
                        <h2 className="about-heading">
                            About BettingPremier
                        </h2>
                        <p className="para-about">

                            Bettingpremier.com makes available the live stream schedules, ensuring that you experience the live streaming of every sport. We offer an immense amount of betting related information and guidelines for an in-depth understanding of the betting concepts and to help you decide the right ones to choose.
                        </p>
                        <p className="para-about">
                            We feature a wide range of betting types available in each sport so that you prefer the best and the most affordable bet. We, thus, invest a great deal of time and effort into determining which ones we endorse to you. We render ample guidance to betting in every form, suitable to everyone from learners to skilled bettors.                        </p>

                        <a href="/blog/about-us/">
                            <button className="bet-button">
                                More About <span className="svgspan"> </span>
                            </button>
                        </a>
                    </div>
                </div>
            </div>





            <div className="container-betting-tools margin-top">
                <div className="header-bg-slide">
                    <h3 className="text-slide">Our Betting Tools</h3>
                </div>

                <div className="flex-container-card">
                          
                    <div className="flex-about-card">
                    <a href="/blog/bet365-live-stream-schedule/">
                        <div className="card-design-offers">
                            <img src="/assets/image/common/stream-schedule.svg" alt="Bet365 schedule"  className="card-offers-image" width="350"  height="210" loading="lazy"/>
                            <div className="card-design-content">
                                <h5 className="card-title"> Bet365 Schedule </h5>
                                <p className="card-design-para">
                                    Bet365 offer live stream on major sports events from Football, Tennis, Ice Hockey, and more.
                                </p>
                                <div className="linkbutton"> READ MORE </div>
                            </div>
                        </div>
                        </a>
                    </div>

                    <div className="flex-about-card">
                              <a href="/blog/odds-converter/"> 
                        <div className="card-design-offers">
                            <img src="/assets/image/common/bettingconverter.svg" alt="Odds Converter" className="card-offers-image" width="350"  height="210" loading="lazy"/>
                            <div className="card-design-content">
                                <h5 className="card-title"> Odds Converter </h5>
                                <p className="card-design-para">
                                    A simple Odds Converter tool to convert between Decimal, Fractional, and American odds.
                                </p>
                                <div className="linkbutton">READ MORE</div>
                            </div>
                        </div>
                        </a>
                    </div>
                    <div className="flex-about-card">
                    <a href="/blog/bet365-games/" >
                        <div className="card-design-offers">
                            <img src="/assets/image/common/bet365-games.svg" alt="Bet365 Games" className="card-offers-image" width="350"  height="210" loading="lazy"/>
                            <div className="card-design-content">
                                <h5 className="card-title"> Bet365 Games</h5>
                                <p className="card-design-para">
                                    Bet365 is popular site with millions of customers all over the world because they cover all possible games
                                </p>
                                <div className="linkbutton">READ MORE</div>
                            </div>
                        </div>
                        </a>
                    </div>
                    <div className="flex-about-card">
                               <a href="/blog/bet365-casino/"> 
                        <div className="card-design-offers">
                            <img src="/assets/image/common/bet365-casino.svg" alt="Bet365 Casino"  className="card-offers-image" width="350"  height="210" loading="lazy"/>
                            <div className="card-design-content">
                                <h5 className="card-title"> Bet365 Casino </h5>
                                <p className="card-design-para">
                                    Casinos are most commonly built with hotels, restaurants, retail shopping, cruise ships or other tourist attractions.
                                </p>
                                <div className="linkbutton">READ MORE</div>
                            </div>
                        </div>
                        </a>
                    </div>
                </div>
            </div>
        </>
    );
}

export default About;