import React, { useEffect, useState } from "react";
import { useParams } from 'react-router-dom';
import { Helmet } from "react-helmet";
import '../components/Components.css';
import './Venue.css';
import RecentBlog from "../../sidebar/RecentBlog";
import InsertAd from "../components/ad/InsertAd";
import SafeImage from "../../utility/Safeimage";

export default function Venue() {
  const { sport, id } = useParams();
  let [data, setData] = useState(null);
  let [countryData, setCountryData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const api = `/api/sports/${sport}/venue/${id}`;

  useEffect(() => {
    fetch(api, { method: 'POST' })
      .then(response => response.json())
      .then(respData => {
        if (respData['status'] !== 'true')
          return;
        if (respData && respData['data'] && respData['data'].length > 0) {
          respData = respData['data'][0];
          if (typeof respData['more'] === 'string')
            respData['more'] = JSON.parse(respData['more']);

          // get country details
          let countryData = getCountry(respData['country_code']);

          // set data
          setData(respData);

          console.log(respData);
          
          setCountryData(countryData);
        }
        else
          setError('Venue not found');
        setLoading(false);
      })
      .catch(err => {
        console.error('Error fetching venue details:', err);
        setLoading(false);
      });
  }, []);

  // validate response
  if (loading)
    return <div>Loading...</div>;
  if (error)
    return <div>{error}</div>;
  if (!data || typeof data !== 'object')
    return <div>Venue data not available.</div>;

  const countryIcon = `/bet-assets/site/image/country/${data['country_code']}.svg`;
  const defaultImage = '/bet-assets/site/image/football/venue/venue-default.png';

  return (
    <>
      <Helmet>
        <title>{`${data['name']} Venue`}</title>
        <meta name="description" content={`${data['name']} is a ${sport} venue in ${data['more']['country']}`} />
      </Helmet>

      <div className="mvp-main-box-cont" data-page="venue">
        <div className="main-box-container">
          <div className="container-score">
            <div className="column-score large">

              <div className="league-main-container bg-image-color">
                <div className="league-main-bg" style={{ backgroundImage: `url(${countryIcon})` }}></div>
                <div className="league-main-box">
                  <div className="league-main-title">{data['name']}</div>
                  <div className="league-main-subtitle">
                    <img src={countryIcon} className="league-main-subtitle-icon" alt={countryData['name']} />
                    <div className="league-main-subtitle-text">{data['more']['country']}</div>
                  </div>
                </div>
              </div>

              <div className="bet-content-box-wrapper">
                <div className="bet-content-box">
                  <div className="bet-content-box-title" hidden>
                    <img className="bet-content-box-title-icon" src="/bet-assets/site/image/football/icon/venue/venue.svg" alt="venue" />
                    <span className="bet-content-box-title-text">Venue</span>
                  </div>
                  <div className="bet-content-box-content">
                    <div className="bet-content-box-content-item">
                      <div className="bet-content-box-content-item-name">
                        <img src="/bet-assets/site/image/football/icon/venue/name.svg" alt="venue name" />
                        <span>Name</span>
                      </div>
                      <div className="bet-content-box-content-item-value">{data['name']}</div>
                    </div>
                    <div className="bet-content-box-content-item">
                      <div className="bet-content-box-content-item-name">
                        <img src="/bet-assets/site/image/football/icon/venue/address.svg" alt="venue address" />
                        <span>Address</span>
                      </div>
                      <div className="bet-content-box-content-item-value">{data['more']['address']}</div>
                    </div>
                    <div className="bet-content-box-content-item">
                      <div className="bet-content-box-content-item-name">
                        <img src="/bet-assets/site/image/football/icon/venue/city.svg" alt="venue city" />
                        <span>City</span>
                      </div>
                      <div className="bet-content-box-content-item-value">{data['more']['city']}</div>
                    </div>
                    <div className="bet-content-box-content-item">
                      <div className="bet-content-box-content-item-name">
                        <img src="/bet-assets/site/image/football/icon/venue/country.svg" alt="venue country" />
                        <span>Country</span>
                      </div>
                      <div className="bet-content-box-content-item-value">{data['more']['country']}</div>
                    </div>
                    <div className="bet-content-box-content-item">
                      <div className="bet-content-box-content-item-name">
                        <img src="/bet-assets/site/image/football/icon/venue/surface.svg" alt="surface" />
                        <span>Surface</span>
                      </div>
                      <div className="bet-content-box-content-item-value">{data['more']['surface']}</div>
                    </div>
                    <div className="bet-content-box-content-item">
                      <div className="bet-content-box-content-item-name">
                        <img src="/bet-assets/site/image/football/icon/venue/capacity.svg" alt="venue capacity" />
                        <span>Capacity</span>
                      </div>
                      <div className="bet-content-box-content-item-value">{data['more']['capacity']}</div>
                    </div>
                  </div>
                </div>

                <div className="bet-content-box">
                  <div className="bet-content-box-title" hidden>
                    <img className="bet-content-box-title-icon" src="/bet-assets/site/image/football/icon/venue/venue-image.svg" alt="venue" />
                    <span className="bet-content-box-title-text">Image</span>
                  </div>
                  <div className="bet-content-box-content">
                    <div className="bet-content-box-content-item venue-image">
                      <SafeImage
                        src={data['more']['image']}
                        fallbackSrc={defaultImage}
                        alt={data['name']}
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="column-score small">
              <RecentBlog />
              <div className="match bet-ad-insert js-bet-ad-insert">
                <InsertAd />
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );

  async function getCountry(code) {
    const response = await fetch(`/api/country/${code}`, { method: 'POST' });
    const respData = await response.json();
    if (respData['status'] !== 'true')
      setError('Country data not found');
    if (respData && respData['data'])
      setCountryData(respData['data']);
    else
      setError('Country data not found');
  }
}
