import React, { useEffect, useState } from 'react';
import '../Components.css';

function Lineups({ homeTeamIcon, awayTeamIcon, id }) {
  const [lineups, setLineups] = useState(null);  // Defaulting to an empty array
  const [loading, setLoading] = useState(false);

  const defaultImage = '/assets/image/league-banner.png';
 
  const finalHomeTeamIcon = homeTeamIcon ? homeTeamIcon : defaultImage;
  const finalAwayTeamIcon = awayTeamIcon ? awayTeamIcon : defaultImage;

  const lineupAPI = `/api/sports/football/game/${id}/stats`;

  useEffect(() => {
    fetch(lineupAPI, { method: 'POST' })
      .then(response => response.json())
      .then(respData => {
        // Check if json.data[2] exists and has the correct structure
        let linedata = null;

        if (respData['status'] !== 'true') {
          return;
        }

        if (typeof respData['data'] !== 'object' || Object.keys(respData['data']).length === 0) {
          return;
        }

        // console.log ('test');
        respData = respData['data'];
       
        for (const key in respData) {
          if (!Object.prototype.hasOwnProperty.call(respData, key)) continue;
          const item = respData[key];

          if (item['type'] !== 'lineup') continue;
          // console.log("item", item);
          linedata = item;
          setLoading(true);
        }

        // console.log(typeof linedata);
        const lineupdata = linedata ? JSON.parse(linedata.data) : null; // Ensure it's an array
         // console.log(lineupdata);

        //   console.log("API response:", json);
        // console.log("lineupdata", linedata);

        setLineups(lineupdata);  // Update lineups state
        setLoading(false);
      })
      .catch(err => {
        // console.error('Error fetching lineups:', err);
        setLoading(false);
      });
  }, [id]);

  if (loading) {
    return <div>Loading Lineups...</div>;
  }

  // console.log(lineups);
  if (!lineups || !lineups[0]['team'] || Object.keys(lineups).length === 0 ) return null;

  //console.log(Object.keys(lineups));

  // Log the final value of lineups before rendering
   //console.log("Final lineups1:", lineups);


  const homeTeam = lineups && lineups[0];
  const awayTeam = lineups && lineups[1];

  const homestartxi =  homeTeam?.startXI || null;
  const awaystartxi =  awayTeam?.startXI || null;
  // console.log("homestartxi", homestartxi);
  // console.log("awaytartxi", awaystartxi);
  //awayTeam.startXI;

  // if (!homestartxi || !awaystartxi) {
  //   return null; // Hides the entire section
  // }

  if (!homestartxi || !awaystartxi) {
    return <div> No data available </div>;
  }

  const rows = {};
  homestartxi.forEach(player => {

    // console.log(player.player.grid);
    const [row, col] = player.player.grid.split(":").map(Number);
    if (!rows[row]) rows[row] = [];
    rows[row].push(player);
  });

  const sortedRows = Object.keys(rows).sort((a, b) => a - b);

  // rowsecond awaytartxi
  const rowsecond = {};

  awaystartxi.forEach(player => {

    // console.log(player.player.grid);
    const [row, col] = player.player.grid.split(":").map(Number);
    if (!rowsecond[row]) rowsecond[row] = [];
    rowsecond[row].push(player);
  });

  const sortedRowsSecond = Object.keys(rowsecond).sort((a, b) => b - a);



  return (


    <>

      <div className="lineups-section">
        <div className="lineups_container">
          <div className="lineups_image">
            <img src="/assets/image/gamelineup.svg" className="lineups-image-icon" alt="Soccer Field"/>
          </div>
          <div className="lineups_content">

            <div className="lineupplayers">
              <div className="lineupplayers_columns">
                {sortedRows.map(row => (
                  <div key={row} className="lineup_players-row">
                    {rows[row]
                      .sort((a, b) => a.player.grid.split(":")[1] - b.player.grid.split(":")[1]) // Sort by column
                      .map(player => (
                        <div className="lineups_circle-container" key={player.player.id}>
                          <div className="lineups--circle">
                            {`${player.player.number}`}
                          </div>
                          <span className="tooltip-text"> {player.player.name}</span>
                        </div>
                      ))}
                  </div>
                ))}
              </div>
              <div className="lineupplayers_columns">

                {sortedRowsSecond.map(row => (
                  <div key={row} className="lineup_players-row">
                    {rowsecond[row]
                      .sort((a, b) => b.player.grid.split(":")[1] - a.player.grid.split(":")[1]) // Sort by column
                      .map(player => (
                        <div className="lineups_circle-container" key={player.player.id}>
                          <div className="lineups--circle">
                            {`${player.player.number}`}
                          </div>
                          <span className="tooltip-text"> {player.player.name}</span>
                        </div>
                      ))}
                  </div>
                ))}

              </div>

            </div>

          </div>
        </div>
      </div>


      <div className="lineups-container-players">

        {homeTeam ? (
          <div className="lineups-playerslist">
            <div className="lineups-players-data-title">
              <h4 className="lineup--title">{homeTeam.team.name} <span className="lineup--formation">  {homeTeam.formation}</span></h4> <img  src={finalHomeTeamIcon} width="24" height="24" alt={homeTeam.team.name}  onError={(e) => { e.target.src = defaultImage; }} className="lineups-imageflex" loading="lazy" />
            </div>
          
                <div className="lineups-players-data-list">
                  <div className="lineups-players-coach  coachbg">
                    <h4 className="lineups-sub">COACH</h4>
                    <span className="lineup--coach"> <img src="/assets/image/coach.svg" width="18" height="18" alt="coach" className="lineups-imageflex" loading="lazy"/> </span>
                  </div>
                  <div className="lineups-players-coach-name">  {homeTeam.coach && homeTeam.coach.name ? homeTeam.coach.name : "-"} </div>
                </div>
       
                {/* {awayTeam.coach.length > 0 && awayTeam.coach.name.length > 0 && (   )} */}
            {/* Players */}
            {homeTeam.startXI && homeTeam.startXI.length > 0 && (
              <div className="lineups-players-data-list">
                <div className="lineups-players-coach coachbg">
                  <h4 className="lineups-sub">STARTING XI</h4>
                  <span className="lineup--coach"> <img src="/assets/image/teamplayer.svg" width="23" height="23" alt="coach" className="lineups-imageflex" loading="lazy"/> </span>
                </div>
                {homeTeam.startXI && homeTeam.startXI.map((player, index) => (
                  <div className="lineups-players--name" key={index} >
                    {player.player.number}  -  {player.player.name}
                  </div>
                ))}

              </div>
            )}
            {/* SUBSTITUTES */}
            {homeTeam.substitutes && homeTeam.substitutes.length > 0 && (
              <div className="lineups-players-data-list">
                <div className="lineups-players-coach coachbg">
                  <h4 className="lineups-sub">SUBSTITUTES</h4>
                  <span className="lineup--coach"> <img src="/assets/image/subplayer.svg" width="20" height="20" alt="coach" className="lineups-imageflex" loading="lazy"/> </span> </div>

                {homeTeam.substitutes && homeTeam.substitutes.map((player, index) => (
                  <div className="lineups-players--name" key={index}>

                    {player.player.number}  -  {player.player.name}
                  </div>
                ))}

              </div>
            )}

          </div>

        ) : (
          <div>No lineup data available</div>
        )}


        {awayTeam ? (
          <div className="lineups-playerslist">
            <div className="lineups-players-data-title">
              <h4 className="lineup--title">{awayTeam.team.name} <span className="lineup--formation">  {awayTeam.formation}</span></h4> <img  src={finalAwayTeamIcon} width="24" height="24" alt={awayTeam.team.name} onError={(e) => { e.target.src = defaultImage; }} className="lineups-imageflex" loading="lazy"/>
            </div>
         
              <div className="lineups-players-data-list">
                <div className="lineups-players-coach  coachbg">
                  <h4 className="lineups-sub">COACH</h4>
                  <span className="lineup--coach"> <img src="/assets/image/coach.svg" width="18" height="18" alt="coach" className="lineups-imageflex" loading="lazy"/> </span>
                </div>
                <div className="lineups-players-coach-name">  {awayTeam.coach && awayTeam.coach.name ? awayTeam.coach.name : "-"} </div>
              </div>
           

            {/* Players */}
            {awayTeam.startXI && awayTeam.startXI.length > 0 && (
              <div className="lineups-players-data-list">
                <div className="lineups-players-coach coachbg">
                  <h4 className="lineups-sub">STARTING XI</h4>
                  <span className="lineup--coach"> <img src="/assets/image/teamplayer.svg" width="23" height="23" alt="coach" className="lineups-imageflex" loading="lazy"/> </span> </div>
                {awayTeam.startXI && awayTeam.startXI.map((player, index) => (
                  <div className="lineups-players--name" key={index} >
                    {player.player.number}  -  {player.player.name}
                  </div>
                ))}

              </div>
            )}
            {/* SUBSTITUTES */}
            {awayTeam.substitutes && awayTeam.substitutes.length > 0 && (
              <div className="lineups-players-data-list">
                <div className="lineups-players-coach coachbg">
                  <h4 className="lineups-sub">SUBSTITUTES</h4>
                  <span className="lineup--coach"> <img src="/assets/image/subplayer.svg" width="20" height="20" alt="coach" className="lineups-imageflex" loading="lazy"/> </span> </div>

                {awayTeam.substitutes && awayTeam.substitutes.map((player, index) => (
                  <div className="lineups-players--name" key={index}>

                    {player.player.number}  -  {player.player.name}
                  </div>
                ))}

              </div>

            )}

          </div>

        ) : (
          <div>No lineup data available</div>
        )}



      </div>

    </>
  );
}

export default Lineups;
