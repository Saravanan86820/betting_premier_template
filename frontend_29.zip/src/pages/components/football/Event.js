import React, { useEffect, useState } from 'react';
import '../Components.css';

function Event({ id, homeProvd_id, awayProvd_id, homeName, awayName }) {

  const [event, setEvent] = useState(null);  // Defaulting to an empty array
  const [loading, setLoading] = useState(false);

  const eventAPI = `/api/sports/football/game/${id}/stats`;

  useEffect(() => {
    fetch(eventAPI, { method: 'POST' })
      .then(response => response.json())
      .then(respData => {

        let statsdata = null;

        if (respData['status'] !== 'true') {
          return;
        }

        if (typeof respData['data'] !== 'object' || Object.keys(respData['data']).length === 0) {
          return;
        }


        respData = respData['data'];
        for (const key in respData) {
          if (!Object.prototype.hasOwnProperty.call(respData, key)) continue;
          const item = respData[key];

          if (item['type'] !== 'events') continue;
          // console.log("eventAPI", item);
          statsdata = item;
          setLoading(true);
        }

       // console.log(typeof statsdata);
        const statisticdata = statsdata ? JSON.parse(statsdata.data) : null;
      //  console.log("eventAPI", statisticdata);

        //   console.log("API response:", json);
        // console.log("lineupdata", statsdata);

        setEvent(statisticdata);  // Update lineups state
        setLoading(false);
      })
      .catch(err => {
        // console.error('Error fetching lineups:', err);
        setLoading(false);
      });
  }, [id]);

  if (loading) {
    return <div>Loading statistics...</div>;
  }

  if (!event || Object.keys(event).length === 0) return null;


  // const homeEvents = event.filter((e) => e.team.id === Number(homeProvd_id));
  // const awayEvents = event.filter((e) => e.team.id === Number(awayProvd_id));

  // console.log("homeEvents", homeEvents);
  // console.log("awayEvents", awayEvents);


  return (
    <>

      <div className="event-container">

        <div className="event_container-team">
          <div className="event_team-row  position-relative">
            {homeName}
          </div>
          <div className="event_team-row">
            {awayName}
          </div>
        </div>

        <div className="event_container-row">
          {event.map((e, index) => (
            <div className="event_container-row-one" data-id={e.team.id === Number(homeProvd_id)} key={`event-${index}`} >



              <div className="event-item" key={`event-item-${index}`} data-row={`row-${index}`}>
                {/* subst */}
                <div className="event_item-list" key={`event-item-list-${index}`}>
                  <div className="event_item-row">
                    {e.type === "subst" && (
                      <>
                        <div className="event_item-box" key={`subst-${index}`}>
                          <div className="event_item-title">
                            <div className="event_list">
                              <img src="/assets/image/substute_icon.svg" alt="substitution_icon" width="30" height="30" className="substitution_icon" loading="lazy" />
                            </div>

                            <div className="event_list event_flex">
                              <div className="event_item-content">
                                <div className="event_item-content-list">
                                  <div className="event_in"> In</div>
                                  <div className="event_player"> {e.player.name ? e.player.name : "-"}</div>

                                </div>
                                <div className="event_item-content-list">
                                  <div className="event_out"> Out</div>

                                  <div className="event_assist"> {e.assist.name ? e.assist.name : "-"}</div>
                                </div>
                              </div>
                            </div>

                            <div className="event_list">
                              <span className="event_elapsed-time">{e.time.elapsed}'</span> <span className='event_extra-time'> {e.time.extra ? `+${e.time.extra}` : ''} </span>
                            </div>


                          </div>


                        </div>
                      </>
                    )}
                  </div>

                  <div className="event_item-row">
                    {e.type === "Goal" && (
                      <>
                        <div className="event_item-box" key={`goal-${index}`}>
                          <div className="event_item-title">
                            <div className="event_list">
                              <img src="/assets/image/league-banner.png" alt="substitution_icon" width="30" height="30" className="substitution_icon" loading="lazy" />
                            </div>
                            <div className="event_list event_flex">
                              <div className="event_item-content">
                                <div className="event_item-content-list">

                                  <div className="event_player"> {e.player.name ? e.player.name : "-"}</div>

                                </div>
                                <div className="event_item-content-list">

                                  <div className="event_assist"> {e.assist.name ? e.assist.name : "-"}</div>

                                </div>
                              </div>
                            </div>
                            <div className="event_list">
                              <span className="event_elapsed-time">{e.time.elapsed}'</span> <span className='event_extra-time'> {e.time.extra ? `+${e.time.extra}` : ''} </span>
                            </div>
                          </div>


                        </div>
                      </>
                    )}
                  </div>

                  <div className="event_item-row">
                    {e.type === "Card" && (
                      <>
                        <div className="event_item-box" key={`card-${index}`}>
                          <div className="event_item-title">
                            <div className="event_list">
                              <span className={e.detail}> </span>
                            </div>
                            <div className="event_list event_flex">
                              <div className="event_item-content">
                                <div className="event_item-content-list">

                                  <div className="event_player"> {e.detail} </div>

                                </div>
                                <div className="event_item-content-list">

                                  <div className="event_assist">  {e.player.name}  </div>

                                </div>
                              </div>
                            </div>
                            <div className="event_list">
                              <span className="event_elapsed-time">{e.time.elapsed}'</span> <span className='event_extra-time'> {e.time.extra ? `+${e.time.extra}` : ''} </span>
                            </div>
                          </div>


                        </div>
                      </>
                    )}
                  </div>

                </div>


              </div>





            </div>

          ))}





        </div>

      </div>
    </>
  );
}

export default Event;
