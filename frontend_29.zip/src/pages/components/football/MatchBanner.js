import React, { useEffect, useState } from "react";
import '../Components.css';
import { Helmet } from 'react-helmet';
// import { useParams } from 'react-router-dom';
import LocalTime from "../../../utility/LocalTime";
const HtmlToReactParser = require('html-to-react').Parser;
import { Link, useParams } from 'react-router-dom';

import MatchTab from "./MatchTab";
import Oddsdata from "./Oddsdata";

function MatchBanner() {
  const { id } = useParams();
  const [gameData, setGameMatch] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const gameAPI = `/api/sports/football/game/${id}`;

  useEffect(() => {
    fetch(gameAPI, { method: 'POST' })
      .then(response => response.json())
      .then(json => {

        //console.log('Fetched match data:', json);
        if (json['status'] !== 'true') {
          return;
        }

        if (json && json['data']) {
          setGameMatch(json['data']); // Store the entire game data
        } else {
          setError('Game not found');
        }
        setLoading(false);
      })

      .catch(err => {
        console.error('Error fetching match season:', err);
        setLoading(false);
      });
  }, [id]);

  // validate response
  if (loading)
    return <div>Loading...</div>;
  if (error)
    return <div>{error}</div>;
  if (!gameData)
    return <div>No game data available.</div>;

  const resultHtml = result(gameData['full_status'], gameData['result'], gameData['time']);
  const homeHtml = gameData['home'] ? team(gameData['home']) : '';
  const awayHtml = gameData['away'] ? team(gameData['away']) : '';


  // const resultHtml1 = location(gameData['halftime'], gameData['fulltime'], gameData['extratime'] , gameData['goals']);

  //console.log(homeTeam.icon);


  const resultData = JSON.parse(gameData.result);

  const goaltimehome = resultData.goals && resultData.goals.home !== null ? resultData.goals.home : "";
  const goaltimeaway = resultData.goals && resultData.goals.away !== null ? resultData.goals.away : "";
  const fulltimehome = resultData.fulltime && resultData.fulltime.home !== null ? resultData.fulltime.home : "";
  const fulltimeaway = resultData.fulltime && resultData.fulltime.away !== null ? resultData.fulltime.away : "";
  const halftimehome = resultData.halftime && resultData.halftime.home !== null ? resultData.halftime.home : "";
  const halftimeaway = resultData.halftime && resultData.halftime.away !== null ? resultData.halftime.away : "";
  const extratimehome = resultData.extratime && resultData.extratime.home !== null ? resultData.extratime.home : "";
  const extratimeaway = resultData.extratime && resultData.extratime.away !== null ? resultData.extratime.away : "";
  const penaltyhome = resultData.penalty && resultData.penalty.home !== null ? resultData.penalty.home : "";
  const penaltyaway = resultData.penalty && resultData.penalty.away !== null ? resultData.penalty.away : "";


  const location = JSON.parse(gameData.location);
  const locationcity = location.city && location.city !== null ? location.city : "-";
  const locationname = location.name && location.name !== null ? location.name : "-";

  const moreinfo = JSON.parse(gameData.more_info);
  const referee = moreinfo.referee && moreinfo.referee !== null ? moreinfo.referee : "-";

  const hometime = gameData.time;
  const utctime = LocalTime(hometime);
  // console.log("resultData", utctime);
  let defaultImage = '/assets/image/default-football.svg';

  const homeTeamIcon = gameData.home ? gameData.home.icon : defaultImage;
  const awayTeamIcon = gameData.away ? gameData.away.icon : defaultImage;

  const homeProvd_id = gameData.home ? gameData.home.provd_id : '';
  const awayProvd_id = gameData.away ? gameData.away.provd_id : '';

  const homeTeam = gameData.home || {};
  const awayTeam = gameData.away || {};

  const bgimage = homeTeam.icon ? homeTeam.icon : awayTeam.icon;

  const status = gameData.status;
  //  console.log("status", status);

  const homeName = homeTeam.display_name;
  const awayName = awayTeam.display_name;


  // location
  const venueID = gameData.venue_id ? gameData.venue_id : null;

  return (
    <>
      <Helmet>
        <title>{`${gameData.name} Game Summary`}</title>
        <meta name="description" content={`Catch up on the ${gameData.name} result, including score, summary, and post-match analysis. Hear from the coaches, players, and more.`} />
      </Helmet>

      <div className="game-container" key={gameData['id']} id="game-banner-top">
        <div className="league-main-container bg-image-color">
          <div className="league-main-bg" style={{ backgroundImage: `url(${bgimage})` }}></div>
          <div className="Next-match-container" >
            <div className="Next-match-section-one"></div>
            <div className="Next-match-section-two">
              {homeHtml}
              {resultHtml}
              {awayHtml}
            </div>
            <div className="Next-match-section-one"></div>
          </div>
        </div>

        <div className="league-main-container-two">
          <div className="game-status-row ">
            <div className="game-status-row-list">
              <div className="game-status-row-data">
                <div className="league-center-title">
                  <div className="imageflex">

                    <img src="/assets/image/more-info.svg" alt="League" width="25" height="25" className="league-imageflex" loading="lazy" />

                    <h4 className="league-heading-sub"> More Info</h4>
                  </div>
                </div>
                <div className="goal-center-details">
                  <div className="goal-center-list">
                    <div className="goal-center-data">

                      <span className="goal--image" >
                        <img src="/assets/image/match-location.svg" alt="League" width="25" height="25" loading="lazy" />
                      </span>
                      <span className="goal--text" >Location</span>
                    </div>
                    {venueID ? (
                      <div className="goal-center-data">
                        <span>
                          <Link to={`/football/venue/${venueID}`} >
                            {locationname}
                          </Link>
                        </span>
                      </div>
                    ) : (
                      <div className="goal-center-data">
                        <span>{locationname}</span>
                      </div>
                    )}
                  </div>
                  <div className="goal-center-list">
                    <div className="goal-center-data">
                      <span className="goal--image" >
                        <img src="/assets/image/match-city.svg" alt="League" width="25" height="25" loading="lazy" />
                      </span>
                      <span className="goal--text" >City</span>
                    </div>
                    <div className="goal-center-data">
                      <span>{locationcity}</span>
                    </div>
                  </div>
                  <div className="goal-center-list">
                    <div className="goal-center-data">

                      <span className="goal--image" >
                        <img src="/assets/image/match-referee.svg" alt="League" width="25" height="25" loading="lazy" />
                      </span>
                      <span className="goal--text" >Referee</span>
                    </div>
                    <div className="goal-center-data">
                      <span> {referee}</span>
                    </div>
                  </div>
                  <div className="goal-center-list">
                    <div className="goal-center-data">


                      <span className="goal--image" >
                        <img src="/assets/image/match-date-time.svg" alt="League" width="25" height="25" loading="lazy" />
                      </span>
                      <span className="goal--text" >Date and Time</span>
                    </div>
                    <div className="goal-center-data">
                      <span> {utctime} </span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="game-status-row-list">
              <div className="game-status-row-data">
                <div className="league-center-title">
                  <div className="imageflex">

                    <img src="/assets/image/goal-status.svg" alt="League" width="25" height="25" className="league-imageflex" loading="lazy" />

                    <h4 className="league-heading-sub"> Goal Status </h4>
                  </div>
                </div>
                <div className="goal-center-details">
                  <div className="goal-center-list">
                    <div className="goal-center-data">
                      <span className="goal--image" >
                        <img src="/assets/image/match-goal.svg" alt="League" width="25" height="25" loading="lazy" />
                      </span>
                      <span className="goal--text" >Goals</span>



                    </div>
                    <div className="goal-center-data text-game-left">
                      <span> {goaltimehome} </span> -  <span> {goaltimeaway} </span>
                    </div>
                  </div>
                  <div className="goal-center-list">
                    <div className="goal-center-data">

                      <span className="goal--image" >
                        <img src="/assets/image/match-halftime.svg" alt="League" width="25" height="25" loading="lazy" />
                      </span>
                      <span className="goal--text" >Halftime</span>

                    </div>
                    <div className="goal-center-data text-game-left">
                      <span> {halftimehome} </span> -  <span> {halftimeaway} </span>
                    </div>
                  </div>
                  <div className="goal-center-list">
                    <div className="goal-center-data">
                      <span className="goal--image" >
                        <img src="/assets/image/match-fulltime.svg" alt="League" width="25" height="25" loading="lazy" />
                      </span>
                      <span className="goal--text" >Fulltime</span>

                    </div>
                    <div className="goal-center-data text-game-left">
                      <span> {fulltimehome} </span> -  <span>  {fulltimeaway} </span>
                    </div>
                  </div>
                  <div className="goal-center-list">
                    <div className="goal-center-data">


                      <span className="goal--image" >
                        <img src="/assets/image/match-extratime.svg" alt="League" width="25" height="25" loading="lazy" />
                      </span>
                      <span className="goal--text" >Extratime</span>
                    </div>
                    <div className="goal-center-data text-game-left">
                      <span>  {extratimehome}  </span> -  <span>  {extratimeaway}  </span>
                    </div>
                  </div>
                  <div className="goal-center-list">
                    <div className="goal-center-data">


                      <span className="goal--image" >
                        <img src="/assets/image/match-penalty.svg" alt="League" width="25" height="25" loading="lazy" />
                      </span>
                      <span className="goal--text" >Penalty</span>
                    </div>
                    <div className="goal-center-data text-game-left">
                      <span>   {penaltyhome} </span> -  <span>   {penaltyaway} </span>
                    </div>
                  </div>

                </div>

              </div>
            </div>
          </div>

        </div>
      </div>

      <MatchTab homeTeamIcon={homeTeamIcon} awayTeamIcon={awayTeamIcon} id={id} homeProvd_id={homeProvd_id} awayProvd_id={awayProvd_id} homeName={homeName} awayName={awayName} />
      <Oddsdata id={id} status={status} />

      {/* <Lineups  homeTeamIcon={homeTeamIcon} id={id} awayTeamIcon={awayTeamIcon}/> */}

    </>
  );

  /**
   * generate result html
   * @param {Object} fullStatus 
   * @param {Object} result 
   *  @param {string|number} time 
   * @returns {JSX.Element} 
   */
  function result(fullStatus, result, time) {
    fullStatus = JSON.parse(fullStatus);
    result = JSON.parse(result);
    time = LocalTime(time);

    let scoreHtml = '';

    let penaltyHome = '';
    let penaltyAway = '';

    if (result['penalty']['home'] !== null && result['penalty']['away'] !== null) {
      penaltyHome = `(${result['penalty']['home']})`;
      penaltyAway = `(${result['penalty']['away']})`;
    }
    if (result['goals'] && result['goals']['home'] !== null && result['goals']['away'] !== null) {
      scoreHtml = `${result['goals']['home']} ${penaltyHome} <span class="livedata-score-arrow">-</span> ${result['goals']['away']} ${penaltyAway}`;
    } else {
      if (result['halftime']['home'] !== null && result['halftime']['away'] !== null)
        scoreHtml = `${result['halftime']['home']} <span class="livedata-score-arrow">-</span> ${result['halftime']['away']}`;
      if (result['fulltime']['home'] !== null && result['fulltime']['away'] !== null)
        scoreHtml = `${result['fulltime']['home']}  ${penaltyHome} <span class="livedata-score-arrow">-</span> ${result['fulltime']['away']} ${penaltyAway}`;
      if (result['extratime']['home'] !== null && result['extratime']['away'] !== null)
        scoreHtml = `${result['extratime']['home']} ${penaltyHome} <span class="livedata-score-arrow">-</span> ${result['extratime']['away']} ${penaltyAway}`;
    }


    return (
      <div className="next-match-item">
        <p className="matchscore">{fullStatus['long']}</p>
        <h2 className="livedata-score">
          {new HtmlToReactParser().parse(scoreHtml)}
        </h2>
        <p>
          <span className="live-time">{time}</span>
        </p>
      </div>
    );
  }

  /**
   * generate team html
   * @param {Object} data 
   * @returns {JSX.Element} 
   */
  function team(data) {
    return (
      <div className="next-match-item">
        <div className="next-match-title">
          <div className="match-image">
            <img src={data['icon'] ? data['icon'] : defaultImage} className="small-images" alt={data['name']} width="70" height="70" onError={(e) => { e.target.src = defaultImage; }} loading="lazy" />
          </div>
          <h3 className="match-title">{data['display_name']}</h3>
        </div>
      </div>
    );
  }
}

export default MatchBanner;