import React, { useEffect, useState } from "react";
import '.././Components.css';

// import { useParams } from 'react-router-dom';
import LocalTime from "../../../utility/LocalTime";
const HtmlToReactParser = require('html-to-react').Parser;
import { useParams } from 'react-router-dom';
import Oddsdata from "./Oddsdata";


function GameScore() {
  const { id } = useParams();
  const [gameData, setGameMatch] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const gameAPI = `/api/sports/rugby/game/${id}`;

  useEffect(() => {
    fetch(gameAPI, { method: 'POST' })
      .then(response => response.json())
      .then(json => {

        //console.log('Fetched match data:', json);
        if (json['status'] !== 'true') {
          return;
        }

        if (json && json['data']) {
          setGameMatch(json['data']); // Store the entire game data
        } else {
          setError('Game not found');
        }
        setLoading(false);
      })

      .catch(err => {
        console.error('Error fetching match season:', err);
        setLoading(false);
      });
  }, [id]);

  // validate response
  if (loading)
    return <div>Loading...</div>;
  if (error)
    return <div>{error}</div>;
  if (!gameData)
    return <div>No game data available.</div>;

  const resultHtml = result(gameData['full_status'], gameData['result'], gameData['time']);
  const homeHtml = gameData['home'] ? team(gameData['home']) : '';
  const awayHtml = gameData['away'] ? team(gameData['away']) : '';


  // const resultHtml1 = location(gameData['halftime'], gameData['fulltime'], gameData['extratime'] , gameData['goals']);

  //console.log(homeTeam.icon);


  const resultData = JSON.parse(gameData.result);

  const homeData = resultData.home;
  const awayData = resultData.away;



  // const formatInnings = (innings) => {
  //     return Object.entries(innings)
  //         .map(([inning, value]) => ` ${value ?? "0"}`);

  // };

  //   const location = gameData.location && gameData.location !== "" ? JSON.parse(gameData.location) : {};
  // const locationCity = location.city && location.city !== "" ? location.city : "-";
  // const locationName = location.name && location.name !== "" ? location.name : "-";


  const moreinfo = JSON.parse(gameData.more_info);
  const referee = moreinfo.referee && moreinfo.referee !== null ? moreinfo.referee : "-";

  const periods = moreinfo && moreinfo.periods || {};

  const firstPeriodAway = periods.first?.away || 0; // Default to 0 if data is unavailable
  const firstPeriodHome = periods.first?.home || 0;

  const secondPeriodAway = periods.second?.away || 0;
  const secondPeriodHome = periods.second?.home || 0;

  const overtimePeriodAway = periods.overtime?.away || 0;
  const overtimePeriodHome = periods.overtime?.home || 0;

  const second_overtimePeriodAway = periods.second_overtime?.away || 0;
  const second_overtimePeriodHome = periods.second_overtime?.home || 0;



  const hometime = gameData.time;
  const utctime = LocalTime(hometime);
  // console.log("resultData", utctime);
  let defaultImage = '/assets/image/rugby/rugby-default.svg';

  const homeTeamIcon = gameData.home ? gameData.home.icon : defaultImage;
  const awayTeamIcon = gameData.away ? gameData.away.icon : defaultImage;

  const homeProvd_id = gameData.home ? gameData.home.provd_id : '';
  const awayProvd_id = gameData.away ? gameData.away.provd_id : '';

  const homeTeam = gameData.home || {};
  const awayTeam = gameData.away || {};

  const bgimage = homeTeam.icon ? homeTeam.icon : awayTeam.icon;

  const status = gameData.status;
  //  console.log("status", status);

  const homeName = homeTeam.display_name;
  const awayName = awayTeam.display_name;


  return (
    <>
      <div className="game-container" key={gameData['id']} id="game-banner-top">
        <div className="league-main-container bg-image-color">
          <div className="league-main-bg" style={{ backgroundImage: `url(${bgimage})` }}></div>
          <div className="Next-match-container" >
            <div className="Next-match-section-one"></div>
            <div className="Next-match-section-two">
              {homeHtml}
              {resultHtml}
              {awayHtml}
            </div>
            <div className="Next-match-section-one"></div>
          </div>
        </div>

        <div className="league-main-container-two">
          <div className="game-status-row ">
            <div className="game-status-row-list">
              <div className="game-status-row-data">
                <div className="league-center-title">
                  <div className="imageflex">

                    <img src="/assets/image/more-info.svg" alt="League" width="25" height="25" className="league-imageflex" loading="lazy" />

                    <h4 className="league-heading-sub"> More Info</h4>
                  </div>
                </div>
                <div className="goal-center-details">
                  <div className="goal-center-list">
                    <div className="goal-center-data">

                      <span className="goal--image" >
                        <img src="/assets/image/match-location.svg" alt="League" width="25" height="25" loading="lazy" />
                      </span>
                      <span className="goal--text" >Location</span>
                    </div>
                    <div className="goal-center-data">
                      <span>citydemo </span>
                    </div>
                  </div>
                  <div className="goal-center-list">
                    <div className="goal-center-data">


                      <span className="goal--image" >
                        <img src="/assets/image/match-city.svg" alt="League" width="25" height="25" loading="lazy" />
                      </span>
                      <span className="goal--text" >City</span>
                    </div>
                    <div className="goal-center-data">
                      <span> citydemo</span>
                    </div>
                  </div>
                  <div className="goal-center-list">
                    <div className="goal-center-data">

                      <span className="goal--image" >
                        <img src="/assets/image/match-referee.svg" alt="League" width="25" height="25" loading="lazy" />
                      </span>
                      <span className="goal--text" >Referee</span>
                    </div>
                    <div className="goal-center-data">
                      <span> {referee}</span>
                    </div>
                  </div>
                  <div className="goal-center-list">
                    <div className="goal-center-data">


                      <span className="goal--image" >
                        <img src="/assets/image/match-date-time.svg" alt="League" width="25" height="25" loading="lazy" />
                      </span>
                      <span className="goal--text" >Date and Time</span>
                    </div>
                    <div className="goal-center-data">
                      <span> {utctime} </span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="game-status-row-list">
              <div className="game-status-row-data">
                <div className="league-center-title">
                  <div className="imageflex">

                    <img src="/assets/image/goal-status.svg" alt="League" width="25" height="25" className="league-imageflex" loading="lazy" />

                    <h4 className="league-heading-sub"> Goal Status </h4>
                  </div>
                </div>
                <div className="goal-center-details">

                  <div className="goal-center-list">
                    <div className="goal-center-data">
                      <span className="goal--image" >
                        <img src="/assets/image/match-halftime.svg" alt="League" width="25" height="25" loading="lazy" />
                      </span>
                      <span className="goal--text" >First</span>



                    </div>
                    <div className="goal-center-data text-game-left">
                      <span> {firstPeriodHome} -  {firstPeriodAway} </span>
                    </div>
                  </div>

                  <div className="goal-center-list">
                    <div className="goal-center-data">
                      <span className="goal--image" >
                        <img src="/assets/image/match-fulltime.svg" alt="League" width="25" height="25" loading="lazy" />
                      </span>
                      <span className="goal--text" >Second</span>

                    </div>
                    <div className="goal-center-data text-game-left">
                      <span>  {secondPeriodHome} -  {secondPeriodAway} </span>
                    </div>
                  </div>

                  <div className="goal-center-list">
                    <div className="goal-center-data">
                      <span className="goal--image" >
                        <img src="/assets/image/match-extratime.svg" alt="League" width="25" height="25" loading="lazy" />
                      </span>
                      <span className="goal--text" >Overtime</span>

                    </div>
                    <div className="goal-center-data text-game-left">
                      <span>  {overtimePeriodAway} -  {overtimePeriodHome} </span>
                    </div>
                  </div>

                  <div className="goal-center-list">
                    <div className="goal-center-data">
                      <span className="goal--image" >
                        <img src="/assets/image/match-extratime.svg" alt="League" width="25" height="25" loading="lazy" />
                      </span>
                      <span className="goal--text" >Second Overtime</span>

                    </div>
                    <div className="goal-center-data text-game-left">
                      <span>  {second_overtimePeriodAway} -  {second_overtimePeriodHome} </span>
                    </div>
                  </div>

                </div>


              </div>
            </div>
          </div>

        </div>
      </div>

      <Oddsdata id={id} status={status} />

      {/* <Lineups  homeTeamIcon={homeTeamIcon} id={id} awayTeamIcon={awayTeamIcon}/> */}

    </>
  );

  /**
   * generate result html
   * @param {Object} fullStatus 
   * @param {Object} result 
   *  @param {string|number} time 
   * @returns {JSX.Element} 
   */
  function result(fullStatus, result, time) {
    fullStatus = JSON.parse(fullStatus);
    result = JSON.parse(result);
    time = LocalTime(time);

    let displayResult;

    if (Array.isArray(result) && result.length === 0) {
      // If result is an empty array, set a placeholder
      displayResult = '-';
    } else if (result && result.home && result.away) {
      // If result contains scores, display them

      const resultHome = result.home;
      const resultAway = result.away;
      displayResult = `${resultHome} - ${resultAway}`;
    } else {
      // Default fallback
      displayResult = '-';
    }




    return (
      <div className="next-match-item">
        <p className="matchscore">{fullStatus['long']}</p>
        <h2 className="livedata-score">
          {new HtmlToReactParser().parse(displayResult)}
        </h2>
        <p>
          <span className="live-time">{time}</span>
        </p>
      </div>
    );
  }

  // function location(){

  //   return ( 

  //     <>

  //     </>
  //   );

  // }

  /**
   * generate team html
   * @param {Object} data 
   * @returns {JSX.Element} 
   */
  function team(data) {
    return (
      <div className="next-match-item">
        <div className="next-match-title">
          <div className="match-image">
            <img src={data['icon'] ? data['icon'] : defaultImage} className="small-images" alt={data['name']} width="70" height="70" onError={(e) => { e.target.src = defaultImage; }} loading="lazy" />
          </div>
          <h3 className="match-title">{data['display_name']}</h3>
        </div>
      </div>
    );
  }
}

export default GameScore;