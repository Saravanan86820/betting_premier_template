import React, { useEffect, useState } from "react";
import '.././Components.css';
import { Helmet } from 'react-helmet';
// import { useParams } from 'react-router-dom';
import LocalTime from "../../../utility/LocalTime";
const HtmlToReactParser = require('html-to-react').Parser;
import { useParams } from 'react-router-dom';
import Oddsdata from "./Oddsdata";
import Event from "./Event";

function GameScore() {
  const { id } = useParams();
  const [gameData, setGameMatch] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const gameAPI = `/api/sports/ice-hockey/game/${id}`;

  useEffect(() => {
    fetch(gameAPI, { method: 'POST' })
      .then(response => response.json())
      .then(json => {

        //console.log('Fetched match data:', json);
        if (json['status'] !== 'true') {
          return;
        }

        if (json && json['data']) {
          setGameMatch(json['data']); // Store the entire game data
        } else {
          setError('Game not found');
        }
        setLoading(false);
      })

      .catch(err => {
        console.error('Error fetching match season:', err);
        setLoading(false);
      });
  }, [id]);

  // validate response
  if (loading)
    return <div>Loading...</div>;
  if (error)
    return <div>{error}</div>;
  if (!gameData)
    return <div>No game data available.</div>;

  const resultHtml = result(gameData['full_status'], gameData['result'], gameData['time']);
  const homeHtml = gameData['home'] ? team(gameData['home']) : '';
  const awayHtml = gameData['away'] ? team(gameData['away']) : '';


  // const resultHtml1 = location(gameData['halftime'], gameData['fulltime'], gameData['extratime'] , gameData['goals']);

  //console.log(homeTeam.icon);


  const resultData = JSON.parse(gameData.result);

  //   const location = gameData.location && gameData.location !== "" ? JSON.parse(gameData.location) : {};
  // const locationCity = location.city && location.city !== "" ? location.city : "-";
  // const locationName = location.name && location.name !== "" ? location.name : "-";

  const location = gameData.location && gameData.location.trim() !== "" ? JSON.parse(gameData.location) : null;
  const locationCity = location && location.city ? location.city : "-";
  const locationName = location && location.name ? location.name : "-";


  const moreinfo = JSON.parse(gameData.more_info);
  const referee = moreinfo.referee && moreinfo.referee !== null ? moreinfo.referee : "-";

  const periods = moreinfo && moreinfo.periods || {};

  const periodFirst = moreinfo.periods && moreinfo.periods.first !== null ? moreinfo.periods.first : "-";
  // const spacedValue = periodFirst.split("-").join(" - ");
  const periodSecond = moreinfo.periods && moreinfo.periods.second !== null ? moreinfo.periods.second : "-";
  const periodThird = moreinfo.periods && moreinfo.periods.third !== null ? moreinfo.periods.third : "-";
  const periodOvertime = moreinfo.periods && moreinfo.periods.overtime !== null ? moreinfo.periods.overtime : "-";
  const periodPenalties = moreinfo.periods && moreinfo.periods.penalties !== null ? moreinfo.periods.penalties : "-";




  const hometime = gameData.time;
  const utctime = LocalTime(hometime);
  // console.log("resultData", utctime);
  let defaultImage = '/assets/image/ice-hockey/hockey-default.svg';

  const homeTeamIcon = gameData.home ? gameData.home.icon : defaultImage;
  const awayTeamIcon = gameData.away ? gameData.away.icon : defaultImage;

  const homeProvd_id = gameData.home ? gameData.home.provd_id : '';
  const awayProvd_id = gameData.away ? gameData.away.provd_id : '';

  const homeTeam = gameData.home || {};
  const awayTeam = gameData.away || {};

  const bgimage = homeTeam.icon ? homeTeam.icon : awayTeam.icon;

  const status = gameData.status;
  //  console.log("status", status);

  const homeName = homeTeam.display_name;
  const awayName = awayTeam.display_name;


  return (
    <>

      <Helmet>
        <title>{`${gameData.name} Game Summary`}</title>
        <meta name="description" content={`Catch up on the ${gameData.name} result, including score, summary, and post-match analysis. Hear from the coaches, players, and more.`} />
      </Helmet>

      <div className="game-container" key={gameData['id']} id="game-banner-top">
        <div className="league-main-container bg-image-color">
          <div className="league-main-bg" style={{ backgroundImage: `url(${bgimage})` }}></div>
          <div className="Next-match-container" >
            <div className="Next-match-section-one"></div>
            <div className="Next-match-section-two">
              {homeHtml}
              {resultHtml}
              {awayHtml}
            </div>
            <div className="Next-match-section-one"></div>
          </div>
        </div>

        <div className="league-main-container-two">
          <div className="game-status-row ">
            <div className="game-status-row-list">
              <div className="game-status-row-data">
                <div className="league-center-title">
                  <div className="imageflex">

                    <img src="/assets/image/more-info.svg" alt="League" width="25" height="25" className="league-imageflex" loading="lazy" />

                    <h4 className="league-heading-sub"> More Info</h4>
                  </div>
                </div>
                <div className="goal-center-details">
                  <div className="goal-center-list">
                    <div className="goal-center-data">

                      <span className="goal--image" >
                        <img src="/assets/image/match-location.svg" alt="League" width="25" height="25" loading="lazy" />
                      </span>
                      <span className="goal--text" >Location</span>
                    </div>
                    <div className="goal-center-data">
                      <span> {locationCity} </span>
                    </div>
                  </div>
                  <div className="goal-center-list">
                    <div className="goal-center-data">


                      <span className="goal--image" >
                        <img src="/assets/image/match-city.svg" alt="League" width="25" height="25" loading="lazy" />
                      </span>
                      <span className="goal--text" >City</span>
                    </div>
                    <div className="goal-center-data">
                      <span> {locationName} </span>
                    </div>
                  </div>
                  <div className="goal-center-list">
                    <div className="goal-center-data">

                      <span className="goal--image" >
                        <img src="/assets/image/match-referee.svg" alt="League" width="25" height="25" loading="lazy" />
                      </span>
                      <span className="goal--text" >Referee</span>
                    </div>
                    <div className="goal-center-data">
                      <span> {referee}</span>
                    </div>
                  </div>
                  <div className="goal-center-list">
                    <div className="goal-center-data">


                      <span className="goal--image" >
                        <img src="/assets/image/match-date-time.svg" alt="League" width="25" height="25" loading="lazy" />
                      </span>
                      <span className="goal--text" >Date and Time</span>
                    </div>
                    <div className="goal-center-data">
                      <span> {utctime} </span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="game-status-row-list">
              <div className="game-status-row-data">
                <div className="league-center-title">
                  <div className="imageflex">

                    <img src="/assets/image/ice-hockey/ice-goal-status.svg" alt="League" width="25" height="25" className="league-imageflex" loading="lazy" />

                    <h4 className="league-heading-sub"> Goal Status </h4>
                  </div>
                </div>
                <div className="goal-center-details">
                  <div className="goal-center-list">
                    <div className="goal-center-data">
                      <span className="goal--image" >
                        <img src="/assets/image/match-halftime.svg" alt="League" width="25" height="25" loading="lazy" />
                      </span>
                      <span className="goal--text" >First</span>



                    </div>
                    <div className="goal-center-data text-game-left">
                      <span>  {periodFirst} </span>
                    </div>
                  </div>
                  <div className="goal-center-list">
                    <div className="goal-center-data">

                      <span className="goal--image" >
                        <img src="/assets/image/match-mediumtime.svg" alt="League" width="25" height="25" loading="lazy" />
                      </span>
                      <span className="goal--text" >Second</span>

                    </div>
                    <div className="goal-center-data text-game-left">
                      <span>{periodSecond} </span>
                    </div>
                  </div>
                  <div className="goal-center-list">
                    <div className="goal-center-data">
                      <span className="goal--image" >
                        <img src="/assets/image/match-fulltime.svg" alt="League" width="25" height="25" loading="lazy" />
                      </span>
                      <span className="goal--text" >Third</span>

                    </div>
                    <div className="goal-center-data text-game-left">
                      <span>{periodThird} </span>
                    </div>
                  </div>
                  <div className="goal-center-list">
                    <div className="goal-center-data">


                      <span className="goal--image" >
                        <img src="/assets/image/match-extratime.svg" alt="League" width="25" height="25" loading="lazy" />
                      </span>
                      <span className="goal--text" >Overtime</span>
                    </div>
                    <div className="goal-center-data text-game-left">
                      <span> {periodOvertime}  </span>
                    </div>
                  </div>
                  <div className="goal-center-list">
                    <div className="goal-center-data">


                      <span className="goal--image" >
                        <img src="/assets/image/ice-hockey/match-ice-penalty.svg" alt="League" width="25" height="25" loading="lazy" />
                      </span>
                      <span className="goal--text" >Penalties</span>
                    </div>
                    <div className="goal-center-data text-game-left">
                      <span>   {periodPenalties} </span>
                    </div>
                  </div>

                </div>

              </div>
            </div>
          </div>

        </div>
      </div>
      <Event id={id} homeProvd_id={homeProvd_id} awayProvd_id={awayProvd_id} homeName={homeName} awayName={awayName} />
      <Oddsdata id={id} status={status} />


      {/* <Lineups  homeTeamIcon={homeTeamIcon} id={id} awayTeamIcon={awayTeamIcon}/> */}

    </>
  );

  /**
   * generate result html
   * @param {Object} fullStatus 
   * @param {Object} result 
   *  @param {string|number} time 
   * @returns {JSX.Element} 
   */
  function result(fullStatus, result, time) {
    fullStatus = JSON.parse(fullStatus);
    result = JSON.parse(result);
    time = LocalTime(time);

    // console.log("result", result);

    let displayResult;

    if (Array.isArray(result) && result.length === 0) {
      // If result is an empty array, set a placeholder
      displayResult = '-';
    } else if (result && result.home != null && result.away != null) {
      const resultHome = result.home ?? 0;
      const resultAway = result.away ?? 0;
      displayResult = `${resultHome} - ${resultAway}`;
    } else {
      displayResult = '-';
    }


    return (
      <div className="next-match-item">
        <p className="matchscore">{fullStatus['long']}</p>
        <h2 className="livedata-score">
          {new HtmlToReactParser().parse(displayResult)}
        </h2>
        <p>
          <span className="live-time">{time}</span>
        </p>
      </div>
    );
  }

  // function location(){

  //   return ( 

  //     <>

  //     </>
  //   );

  // }

  /**
   * generate team html
   * @param {Object} data 
   * @returns {JSX.Element} 
   */
  function team(data) {
    return (
      <div className="next-match-item">
        <div className="next-match-title">
          <div className="match-image">
            <img src={data['icon'] ? data['icon'] : defaultImage} className="small-images" alt={data['name']} width="70" height="70" onError={(e) => { e.target.src = defaultImage; }} loading="lazy" />
          </div>
          <h3 className="match-title">{data['display_name']}</h3>
        </div>
      </div>
    );
  }
}

export default GameScore;