import React, { useEffect, useState } from "react";
import { useParams, Link } from 'react-router-dom';
import LocalTime from "../../utility/LocalTime";
import { useLocation } from "react-router-dom";



const MatchPage = () => {
  const { id } = useParams();
  const location = useLocation();
  const slug = location.pathname.split("/")[1];

  const AllMatchSeason = `/api/sports/${slug}/season/${id}`;
  const Allmatch = `/api/sports/${slug}/season/${id}/game`;

  const [matchSeason, setMatchseason] = useState(null);
  const [months, setMonths] = useState([]);
  const [matches, setMatches] = useState([]);
  const [filteredMatches, setFilteredMatches] = useState([]);
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(true);
  const [gameMatch, setGameMatch] = useState({});

  const [currentMonthIndex, setCurrentMonthIndex] = useState(0);

  const [searchTerm, setSearchTerm] = useState("");

  const monthNames = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];

  useEffect(() => {
    fetch(AllMatchSeason, { method: 'POST' })
      .then(response => response.json())
      .then(json => {
        setMatchseason(json.data);
        if (json.data && json.data.length > 0) {
          const { start, end } = json.data[0];
          const startDate = new Date(start);
          const endDate = new Date(end);

          // console.log("startDate", startDate);
          // console.log("endDate", endDate);

          const monthsArray = getMonthsBetween(startDate, endDate);

          //console.log("monthsArray", monthsArray);

          setMonths(monthsArray);

          //  console.log("monthsArray", monthsArray);
          // Set default to current month index if within the range; otherwise, the first available month
          const today = new Date();
          const formattedToday = `${monthNames[today.getMonth()]} ${today.getFullYear()}`;
          const initialIndex = monthsArray.includes(formattedToday) ? monthsArray.indexOf(formattedToday) : 0;
          setCurrentMonthIndex(initialIndex);


        }
      })
      .catch(error => console.error('Error fetching match season:', error));
  }, []);

  // const getMonthsBetween = (start, end) => {
  //     const monthsArray = [];
  //     // let current = new Date(start);
  //     let current = new Date(start);
  //   //  console.log("current", current);
  //     while (current <= end) {
  //         const monthYear = `${monthNames[current.getMonth()]} ${current.getFullYear()}`;
  //         monthsArray.push(monthYear);
  //         current.setMonth(current.getMonth() + 1);
  //     }
  //     return monthsArray;
  // };

  const getMonthsBetween = (start, end) => {
    const monthsArray = [];
    let currentYear = start.getFullYear();
    let currentMonth = start.getMonth();

    while (currentYear < end.getFullYear() || (currentYear === end.getFullYear() && currentMonth <= end.getMonth())) {
      const monthYear = `${monthNames[currentMonth]} ${currentYear}`;
      monthsArray.push(monthYear);

      // Increment month manually and handle year change
      currentMonth++;
      if (currentMonth > 11) { // If month exceeds December
        currentMonth = 0; // Reset to January
        currentYear++;    // Move to the next year
      }
    }
    return monthsArray;
  };


  useEffect(() => {
    if (months.length > 0) {
      fetchMatchesForMonth(months[currentMonthIndex]);
    }
  }, [currentMonthIndex, id, months]);

  const fetchMatchesForMonth = async (selectedMonth) => {
    setError(null);
    setLoading(true);
    try {
      const response = await fetch(Allmatch, { method: 'POST' });
      if (!response.ok) throw new Error("Network response was not ok");

      const json = await response.json();

      const allMatches = json?.data ?? [];

      const filtered = allMatches.filter(match => {
        if (!match.date) return false;
        const matchDate = new Date(match.date);

        const [monthName, year] = selectedMonth.split(" ");
        return (
          matchDate.getFullYear() === parseInt(year) &&
          monthNames[matchDate.getMonth()] === monthName
        );
      });

      setMatches(allMatches);
      setFilteredMatches(filtered);

      if (filtered.length > 0) {
        filtered.forEach(match => fetchGameDetails(match.id));
      }

    } catch (err) {
      // setError('Error fetching league data');
      console.error('Fetch error:', err);
    } finally {
      setLoading(false);
    }
  };

  const fetchGameDetails = (matchId) => {
    const LeagueGame = `/api/sports/${slug}/game/${matchId}`;
    fetch(LeagueGame, { method: 'POST' })
      .then(response => response.json())
      .then(json => {
        if (json && json.data) {
          //  console.log("match json", json);
          setGameMatch(prevState => ({
            ...prevState,
            [matchId]: json.data,
          }));
        } else {
          const errorMessage = `Game data not found for match ${matchId}`;
          console.error(errorMessage);
          //  setError(`Game data not found for match ${matchId}`);

        }
      })
      .catch(() => {
        const errorMessage = `Error fetching game data for match ${matchId}`;
        console.error(errorMessage);
        // setError(errorMessage);
      });
  };

  const handleMonthChange = (event) => {
    const selectedMonth = event.target.value;
    // console.log("selectedMonth", selectedMonth);
    const index = months.indexOf(selectedMonth);
    //  console.log("index", index);
    setCurrentMonthIndex(index);
  };

  const handleNextMonth = () => {
    if (currentMonthIndex < months.length - 1) {
      setCurrentMonthIndex(prev => prev + 1);
    }
  };

  const handlePreviousMonth = () => {
    if (currentMonthIndex > 0) {
      setCurrentMonthIndex(prev => prev - 1);
    }
  };

  const handleSearch = (e) => {
    setSearchTerm(e.target.value);
  };

  const filteredBySearchTerm = filteredMatches.filter(match =>
    match.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  if (error) {
    return <div>{error}</div>;
  }

  if (loading) {
    return <div>Loading...</div>;
  }


  //All Games

  let defaultGame = "";

  if (slug === "football") {
    defaultGame = '/assets/image/game.svg';
  } else if (slug === "ice-hockey") {
    defaultGame = '/assets/image/ice-hockey/icehockeygame.svg';
  } else if (slug === "baseball") {
    defaultGame = '/assets/image/baseball/baseballgame.svg';
  } else if (slug === "basketball") {
    defaultGame = '/assets/image/basketball/basketballgame.svg';
  } else if (slug === "volleyball") {
    defaultGame = '/assets/image/volleyball/volleyballgame.svg';
  } else if (slug === "handball") {
    defaultGame = '/assets/image/handball/handball-game.svg';
  } else if (slug === "rugby") {
    defaultGame = '/assets/image/rugby/rugby-game.svg';
  } else {
    defaultGame = '/assets/image/game.svg';
  }

  //default image set
  let defaultImage = "";

  if (slug === "football") {
    defaultImage = '/assets/image/defaulticon.svg';
  } else if (slug === "ice-hockey") {
    defaultImage = '/assets/image/ice-hockey/field-hockey1.png';
  } else if (slug === "baseball") {
    defaultImage = '/assets/image/baseball/default-baseball-small.png';
  } else if (slug === "basketball") {
    defaultImage = '/assets/image/basketball/basketball-1.png';
  } else if (slug === "volleyball") {
    defaultImage = '/assets/image/volleyball/d-volleyball.svg';
  } else if (slug === "handball") {
    defaultImage = '/assets/image/handball/handball.svg';
  } else if (slug === "rugby") {
    defaultImage = '/assets/image/rugby/rugby.svg';
  } else {
    defaultImage = '/assets/image/defaulticon.svg';
  }

  return (
    <div className="league-main-container" id="all-game-page">
      <div className="league-main-row">
        <div className="league-center-title">
          <div className="imageflex">
            <img src={defaultGame} alt="League" width="36" height="36" className="league-imageflex" loading="lazy" />
            <h4 className="league-heading-sub">All Games </h4>
          </div>
        </div>
        <div className="container-search">
          <div className="container-search--row">
            <div className="select-dropdown">

              {/* <label htmlFor="month">Filter by Month:</label> */}
              <select id="month" onChange={handleMonthChange} value={months[currentMonthIndex]}>
                {months.map((month, index) => (
                  <option key={index} value={month}>
                    {month}
                  </option>
                ))}
              </select>
              <span className="icon--bar">
                <svg viewBox="0 0 16 16" height="25px" width="25px">
                  <defs>
                    <linearGradient id="gradientId" x1="0%" y1="0%" x2="100%" y2="100%">
                      <stop offset="0%" style={{ stopColor: "#f26633", stopOpacity: 1 }} />
                      <stop offset="100%" style={{ stopColor: "#ffcc33", stopOpacity: 1 }} />
                    </linearGradient>
                  </defs>
                  <path
                    fill="url(#gradientId)"
                    d="M4 .5a.5.5 0 00-1 0V1H2a2 2 0 00-2 2v1h16V3a2 2 0 00-2-2h-1V.5a.5.5 0 00-1 0V1H4V.5zM16 14V5H0v9a2 2 0 002 2h12a2 2 0 002-2zm-5.146-5.146l-3 3a.5.5 0 01-.708 0l-1.5-1.5a.5.5 0 01.708-.708L7.5 10.793l2.646-2.647a.5.5 0 01.708.708z"
                  />
                </svg>
              </span>
            </div>
          </div>
          <div className="container-search--row">

            <div className="search-bar--allmatch">
              {/* <label htmlFor="search">Search</label> */}

              <input
                id="search"
                type="text"
                value={searchTerm}
                onChange={handleSearch}
                placeholder="search match name"
              />
              <span className="icon--bar">
                <svg viewBox="0 0 24 24" height="40px" width="40px">

                  <defs>
                    <linearGradient id="gradientColor" x1="0%" y1="0%" x2="100%" y2="100%">
                      <stop offset="0%" style={{ stopColor: "#f26633", stopOpacity: 1 }} />
                      <stop offset="100%" style={{ stopColor: "#ffcc33", stopOpacity: 1 }} />
                    </linearGradient>
                  </defs>


                  <path
                    d="M11.5 9a2.5 2.5 0 000 5 2.5 2.5 0 000-5M20 4H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2m-3.21 14.21l-2.91-2.91c-.69.44-1.51.7-2.38.7C9 16 7 14 7 11.5S9 7 11.5 7a4.481 4.481 0 013.8 6.89l2.91 2.9-1.42 1.42z"
                    fill="url(#gradientColor)"
                  />
                </svg>

              </span>
            </div>
          </div>
          <div className="container-search--row">
            <div className="pagination-controls">
              <button onClick={handlePreviousMonth} disabled={currentMonthIndex === 0}>
                <span className="icon--bar--btn">


                  <svg
                    viewBox="0 0 24 24"
                    height="2em"
                    width="2em"

                  >

                    <defs>
                      <linearGradient id="gradientColor" x1="0%" y1="0%" x2="100%" y2="100%">
                        <stop offset="0%" style={{ stopColor: "#f26633", stopOpacity: 1 }} />
                        <stop offset="100%" style={{ stopColor: "#ffcc33", stopOpacity: 1 }} />
                      </linearGradient>
                    </defs>

                    <path d="M13.939 4.939L6.879 12l7.06 7.061 2.122-2.122L11.121 12l4.94-4.939z" fill="url(#gradientColor)" />
                  </svg>
                </span> </button>
              <button onClick={handleNextMonth} disabled={currentMonthIndex === months.length - 1}>
                <span className="icon--bar--btn">

                  <svg
                    viewBox="0 0 24 24"
                    height="2em"
                    width="2em"

                  >

                    <defs>
                      <linearGradient id="gradientColor" x1="0%" y1="0%" x2="100%" y2="100%">
                        <stop offset="0%" style={{ stopColor: "#f26633", stopOpacity: 1 }} />
                        <stop offset="100%" style={{ stopColor: "#ffcc33", stopOpacity: 1 }} />
                      </linearGradient>
                    </defs>

                    <path d="M10.061 19.061L17.121 12l-7.06-7.061-2.122 2.122L12.879 12l-4.94 4.939z" fill="url(#gradientColor)" />
                  </svg>

                </span> </button>
            </div>
          </div>
        </div>

        <div className="league-match-data-single">
          {filteredBySearchTerm && filteredBySearchTerm.length > 0 ? (
            filteredBySearchTerm.map(match => {
              const matchgame = gameMatch[match.id] || {};

              const homeTeam = matchgame.home || {};
              const awayTeam = matchgame.away || {};
              const hometime = matchgame.time;
              const utctime = LocalTime(hometime);
              const gamesurl = match['name'] ? match['name'].replace(/\s+/g, '-').replace(/\//g, '-').replace(/-+/g, '-').toLowerCase() : "";
              const idgame = match["id"] ? match["id"] : "";
              const gameurlslug = `${gamesurl}/${idgame}`;

              return (
                <Link to={`/${slug}/game/${gameurlslug}`} key={match.id}>
                  <div className="league-rows">
                    <div className="league-rows-iteam-match1">
                      <div className="league-rows-iteam-time">
                        <div className="match-date">
                          <div> {utctime} </div>
                        </div>
                        <div className="match-status">{matchgame.full_status && JSON.parse(matchgame.full_status).long}</div>
                      </div>
                    </div>
                    <div className="league-rows-iteam-match2">
                      <div className="league-match-data">
                        <div className="league-match-img">
                          <img
                            src={homeTeam.icon ? homeTeam.icon : defaultImage}
                            alt={homeTeam.display_name || 'league'}
                            className="league-live-img"
                            onError={(e) => { e.target.src = defaultImage; }}
                            loading="lazy" width="20" height="20"
                          />
                          <span>{homeTeam.display_name}</span>
                        </div>
                        <div className="league-match-score">

                          {slug === "football" && matchgame.result
                            ? (() => {
                              const result = JSON.parse(matchgame.result)?.fulltime || {};
                              const home = result.home !== null ? result.home : '-';

                              return `${home}`;
                            })()
                            : slug === "ice-hockey" && matchgame.result
                              ? (() => {
                                const result = JSON.parse(matchgame.result) || {};
                                const home = result.home !== null ? result.home : '-';
                                return home;
                              })()
                              : slug === "baseball" && matchgame.result
                                ? (() => {
                                  const result = JSON.parse(matchgame.result) || {};
                                  const total = result.home.total !== null ? result.home.total : '-';
                                  return total;
                                })()
                                : slug === "basketball" && matchgame.result
                                  ? (() => {
                                    const result = JSON.parse(matchgame.result) || {};
                                    const total = result.home.total !== null ? result.home.total : '-';
                                    return total;
                                  })()
                                  : slug === "volleyball" && matchgame.result
                                    ? (() => {
                                      const result = JSON.parse(matchgame.result) || {};
                                      const total = result.home !== null ? result.home : '-';
                                      return total;
                                    })()
                                    : slug === "handball" && matchgame.result
                                      ? (() => {
                                        const result = JSON.parse(matchgame.result) || {};
                                        const total = result.home !== null ? result.home : '-';
                                        return total;
                                      })()
                                      : slug === "rugby" && matchgame.result
                                        ? (() => {
                                          const result = JSON.parse(matchgame.result) || {};
                                          const total = result.home !== null ? result.home : '-';
                                          return total;
                                        })()
                                        : '0'}


                        </div>
                      </div>
                      <div className="league-match-data">
                        <div className="league-match-img">
                          <img
                            src={awayTeam.icon ? awayTeam.icon : defaultImage}
                            alt={awayTeam.display_name || 'league'}
                            className="league-live-img"
                            onError={(e) => { e.target.src = defaultImage; }}
                            loading="lazy" width="20" height="20"
                          />
                          <span>{awayTeam.display_name}</span>
                        </div>
                        <div className="league-match-score">

                          {slug === "football" && matchgame.result
                            ? (() => {
                              const result = JSON.parse(matchgame.result)?.fulltime || {};
                              const away = result.away !== null ? result.away : '-';

                              return `${away}`;
                            })()
                            : slug === "ice-hockey" && matchgame.result
                              ? (() => {
                                const result = JSON.parse(matchgame.result) || {};
                                const away = result.away !== null ? result.away : '-';
                                return away;
                              })()
                              : slug === "baseball" && matchgame.result
                                ? (() => {
                                  const result = JSON.parse(matchgame.result) || {};
                                  const total = result.away.total !== null ? result.away.total : '-';
                                  return total;
                                })()
                                : slug === "basketball" && matchgame.result
                                  ? (() => {
                                    const result = JSON.parse(matchgame.result) || {};
                                    const total = result.away.total !== null ? result.away.total : '-';
                                    return total;
                                  })()
                                  : slug === "volleyball" && matchgame.result
                                    ? (() => {
                                      const result = JSON.parse(matchgame.result) || {};
                                      const total = result.away !== null ? result.away : '-';
                                      return total;
                                    })()
                                    : slug === "handball" && matchgame.result
                                      ? (() => {
                                        const result = JSON.parse(matchgame.result) || {};
                                        const total = result.away !== null ? result.away : '-';
                                        return total;
                                      })()
                                      : slug === "rugby" && matchgame.result
                                        ? (() => {
                                          const result = JSON.parse(matchgame.result) || {};
                                          const total = result.away !== null ? result.away : '-';
                                          return total;
                                        })()
                                        : '0'}


                        </div>
                      </div>
                    </div>
                  </div>
                </Link>
              );
            })
          ) : (
            <div className="no-matches">No Game found for {months[currentMonthIndex]}.</div>
          )}
        </div>


      </div>
    </div>
  );
};

export default MatchPage;
