/**
 * convert from timestamp to human readable local time
 * @param {string|number} timeStamp 
 * @returns 
 */
export default function LocalTime(timeStamp) {
  const timestamp = timeStamp;
  const date = new Date(timestamp * 1000); // convert to milliseconds
  const dateTime = date.toLocaleString([], {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
    hour: 'numeric',
    minute: 'numeric',
    hour12: true
  });
  return dateTime;
}