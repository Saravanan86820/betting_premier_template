import React, { useEffect, useState } from 'react';
// import ConfigUrl from './ConfigUrl';


function Footballblog() {

    const [posts, setPosts] = useState([]);
    const [error, setError] = useState('');

    useEffect(() => {
        const fetchPost = async () => {
            try {
                const response = await fetch(
                    '/blog/wp-json/custom/v2/posts'
                );
                const jsonresult = await response.json();

                if (response.ok) {
                    const limitedPosts = jsonresult.slice(0, 7); // Limit to 4 posts
                    setPosts(limitedPosts);

                    // console.log(jsonresult);
                } else {
                    setError('Failed to fetch posts'); // Handle unsuccessful response
                    console.log('Error:', jsonresult);
                }
            } catch (err) {
                setError('An error occurred while fetching data'); // Catch and handle network or other errors
                console.error('Error:', err);
            }
        };

        fetchPost();
    }, []);


    return (

        <>
            <div className="match">
                <div className="match-header">

                    <div className="match-tournament"> Football  Blog</div>
                </div>
                {error && <p className="error-message">{error}</p>}
                <div className="Recent-content-main">
                    {posts.map((post) => {
                        const category =
                            post.categories && post.categories.length > 0
                                ? post.categories[0]
                                : { name: 'Unknown' };
                        const categoryName = category.name;
                        const categoryUrl = category.url;
                        const imageUrl = post.featured_image_url || undefined;
                        return (
                            <a href={post.link} key={post.id} >
                                <div className="blog-row-main" >
                                    <div className="blog-row">
                                        <div className="blog-row-image">
                                       <img src={imageUrl} alt={post.title} className="blog-images-top" width="90"  height="80" loading="lazy"/>   
                                        </div>
                                        <div className="blog-row-content">

                                            {/* <h3 className="blog-sub-text mb">  {categoryName}  </h3> */}
                                            <h2 className="blog-sub-title">
                                                {post.title}
                                            </h2>

                                        </div>
                                    </div>
                                </div>  
                                 </a>
                        );
                    })}




                </div>
            </div>


        </>
    );
}

export default Footballblog;