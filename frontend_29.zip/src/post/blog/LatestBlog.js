import React, { useEffect, useState } from 'react';
// import ConfigUrl from './ConfigUrl';


function LatestBlog() {

    const [posts, setPosts] = useState([]);
    const [error, setError] = useState('');

    useEffect(() => {
        const fetchPost = async () => {
            try {
                const response = await fetch(
                        '/blog/wp-json/custom/v1/posts'
                );
                const jsonresult = await response.json();

                if (response.ok) {
                    const limitedPosts = jsonresult.slice(0, 4); // Limit to 4 posts
                    setPosts(limitedPosts); 
                
                    // console.log(jsonresult);
                } else {
                    setError('Failed to fetch posts'); // Handle unsuccessful response
                    console.log('Error:', jsonresult);
                }
            } catch (err) {
                setError('An error occurred while fetching data'); // Catch and handle network or other errors
                console.error('Error:', err);
            }
        };

        fetchPost();
    }, []);


    return (

        <>
            <div className="news-section"  id="recent-blog-home-top">
                <div className="news-section__header">

                    <h2> Recent  Blog</h2>
                    <div class="news-section__divider"></div>
                </div>
                {error && <p className="error-message">{error}</p>}
                <div class="news-section__news">
                    {posts.map((post) => {
                                  const category =
                                  post.categories && post.categories.length > 0
                                    ? post.categories[0]
                                    : { name: 'Unknown' };
                                const categoryName = category.name;
                                const categoryUrl = category.url;
                                const imageUrl = post.featured_image_url || undefined; 
                                return (
                                    <a href={post.link}  key={post.id} > 
                        <div class="news-section__news-card">
                            
                                <div class="news-section__news-image">
                                    <img src={imageUrl} alt={post.title} className="blog-images-top" width="90"  height="80" loading="lazy"/>
                                </div>
                                <div class="news-section__news-content">
                                    <p class="news-section__news-date">{post.date}</p>
                                    <h3 className="news-section__news-title">   {categoryName}   </h3>
                                    <h2 className="news-section__news-desc">  
                                {post.title}
                             </h2>

                                </div>
                            
                        </div>
                        </a>
                          );
                    })}
                  



                </div>
            </div>


        </>
    );
}

export default LatestBlog;