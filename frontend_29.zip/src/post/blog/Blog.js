import React, { useEffect, useState } from 'react';
// import '../../index.css';
import  Footballblog from './Footballblog';

import './blog.css';

import ConfigUrl from './ConfigUrl';

// home page after 10 more blog 

function Blog() {


    const [posts, setPosts] = useState([]);
    const [error, setError] = useState('');

    useEffect(() => {
        const fetchPost = async () => {
            try {
                const response = await fetch(
                         '/blog/wp-json/custom/v1/posts'
                         
                );

                   //   `${ConfigUrl.API_BASE_URL}/blog/wp-json/custom/v1/posts` 'https://bettingpremier.ewallhost.com/blog/wp-json/custom/v1/posts'


                const jsonresult = await response.json();

                if (response.ok) {
                    const limitedPosts = jsonresult.slice(10, 13); // Limit to 4 posts
                    setPosts(limitedPosts);

                    // console.log(jsonresult);
                } else {
                    setError('Failed to fetch posts'); // Handle unsuccessful response
                    console.log('Error:', jsonresult);
                }
            } catch (err) {
                setError('An error occurred while fetching data'); // Catch and handle network or other errors
                console.error('Error:', err);
            }
        };

        fetchPost();
    }, []);



    return (

        <>

            <div className="container-more-blog" id="more-post-section">
                <div className="container-score">

                    <div className="column-score large">
                        <div className="blog-container">
                            <div className="header-bg-slide" id="morenews-bottom">
                                <div className="header-flex-home">
                                    <h3 className="text-slide">More News</h3>

                                </div>
                            </div>

                            <div className="moreblog-container">

                                {error && <p className="error-message">{error}</p>}

                                <ul className="mvp-main-blog-wrap">



                                    {posts.map((post) => {
                                        const category =
                                            post.categories && post.categories.length > 0
                                                ? post.categories[0]
                                                : { name: 'Unknown' };
                                        const categoryName = category.name;
                                        const categoryUrl = category.url;
                                        const imageUrl = post.featured_image_url || undefined; 
                                        return (

                                            <li className="mvp-blog-story-wrap" key={post.id}>
                                                <div className="mvp-blog-story-row">

                                                    <div className="mvp-blog-story-image">

                                                        <div className="blog-story-img">
                                                        <a href={post.link}>   <img src={imageUrl} alt={post.title}  width="300"  height="180"
                                                         loading="lazy"/>  </a>  
                                                        </div>

                                                    </div>

                                                    <div className=" mvp-blog-story-text ">

                                                        <div className="mvp-post-info-top">
                                                            <h5 className="blog-sub-text"> <span className="cat-heading">   <a
                                                                href={categoryUrl}
                                                                className="linkcat-btn"
                                                            >  {categoryName} </a></span>   <span className="slaph"> / </span>{post.date}</h5>
                                                        </div>
                                                        <div className="mvp-blog-story-info">
                                                            <div>
                                                                <a href={post.link} className="linkcat-btn">
                                                                    <h2 className="blog-title-more">
                                                                        {post.title}</h2>   </a>
                                                            </div>
                                                            <div>
                                                                <p className="blog-para"> {post.content} </p>
                                                            </div>


                                                        </div>
                                                        <div className="blog-btn"><a href={post.link} className="linkbutton"  >READ MORE</a></div>
                                                    </div>
                                                </div>
                                            </li>

                                        );
                                    })}



                                </ul>
                                <div className="blog-more-btn">
                                    <a href="/blog/">
                                        <button className="bet-button">
                                            Show More News <span className="svgspan"></span>
                                        </button>
                                    </a>


                                </div>
                            </div>
                        </div>
                    </div>

                    <div className="column-score small">

                        <div className="container-slide-main">
                            <div className="container-slide">

                                 
                              <Footballblog/>

                            </div>

                        </div>

                    </div>

                </div>
            </div>

        </>
    );
}

export default Blog