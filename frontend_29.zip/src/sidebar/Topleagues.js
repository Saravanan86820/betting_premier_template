import React, { useState, useEffect } from "react";
import './NewTopLeagues.css';
import { useParams, Link } from 'react-router-dom';
import { useLocation } from "react-router-dom";

function Topleagues() {

    const location = useLocation();
    const slug = location.pathname.split("/")[1];
    const dynamicSlug = slug || "football";


    const [footballdata, setFootballData] = useState([]);
    const [icedata, setIceData] = useState([]);
    const [baseballdata, setBaseballData] = useState([]);
    const [basketballdata, setBasketballData] = useState([]);
    const [volleyballdata, setVolleyballData] = useState([]);
    const [error, setError] = useState('');

    const league = `/api/widget/top-leagues-football`;

    useEffect(() => {
        fetch(league, { method: 'POST' })
            .then(response => response.json())
            .then(json => {

                if (json.status === "true" && json.data) {

                    const targetData = json.data.find((item) => item.name === "top-leagues-football");

                    if (targetData && targetData.data) {
                        const parsedData = JSON.parse(targetData.data);
                        //  console.log("API parsedData:", parsedData);
                        setFootballData(parsedData);
                    } else {
                        setError("Invalid data format or missing data.");
                    }

                } else {
                    setError("API response error.");
                }

            })
            .catch(err => {
                console.error('Error fetching lineups:', err);
                setError('Error fetching data');
            });
    }, []);

    const leagueTwo = `/api/widget/top-leagues-ice-hockey`;

    useEffect(() => {
        fetch(leagueTwo, { method: 'POST' })
            .then(response => response.json())
            .then(json => {

                if (json.status === "true" && json.data) {

                    const targetData = json.data.find((item) => item.name === "top-leagues-ice-hockey");


                    if (targetData && targetData.data) {
                        const parsedData = JSON.parse(targetData.data);
                        //  console.log("API setIceData:", parsedData);
                        setIceData(parsedData);
                    } else {
                        setError("Invalid data format or missing data.");
                    }

                } else {
                    setError("API response error.");
                }

            })
            .catch(err => {
                console.error('Error fetching lineups:', err);
                setError('Error fetching data');
            });
    }, []);

    const leagueThree = `/api/widget/top-leagues-baseball`;

    useEffect(() => {
        fetch(leagueThree, { method: 'POST' })
            .then(response => response.json())
            .then(json => {

                if (json.status === "true" && json.data) {

                    const targetData = json.data.find((item) => item.name === "top-leagues-baseball");


                    if (targetData && targetData.data) {
                        const parsedData = JSON.parse(targetData.data);
                        //  console.log("API setIceData:", parsedData);
                        setBaseballData(parsedData);
                    } else {
                        setError("Invalid data format or missing data.");
                    }

                } else {
                    setError("API response error.");
                }

            })
            .catch(err => {
                console.error('Error fetching lineups:', err);
                setError('Error fetching data');
            });
    }, []);

    const leagueBasketball = `/api/widget/top-leagues-basketball`;

    useEffect(() => {
        fetch(leagueBasketball, { method: 'POST' })
            .then(response => response.json())
            .then(json => {

                if (json.status === "true" && json.data) {

                    const targetData = json.data.find((item) => item.name === "top-leagues-basketball");


                    if (targetData && targetData.data) {
                        const parsedData = JSON.parse(targetData.data);
                        //  console.log("API setIceData:", parsedData);
                        setBasketballData(parsedData);
                    } else {
                        setError("Invalid data format or missing data.");
                    }

                } else {
                    setError("API response error.");
                }

            })
            .catch(err => {
                console.error('Error fetching lineups:', err);
                setError('Error fetching data');
            });
    }, []);

    const leagueVolleyball = `/api/widget/top-leagues-volleyball`;

    useEffect(() => {
        fetch(leagueVolleyball, { method: 'POST' })
            .then(response => response.json())
            .then(json => {

                if (json.status === "true" && json.data) {

                    const targetData = json.data.find((item) => item.name === "top-leagues-volleyball");


                    if (targetData && targetData.data) {
                        const parsedData = JSON.parse(targetData.data);
                        //  console.log("API setIceData:", parsedData);
                        setVolleyballData(parsedData);
                    } else {
                        setError("Invalid data format or missing data.");
                    }

                } else {
                    setError("API response error.");
                }

            })
            .catch(err => {
                console.error('Error fetching lineups:', err);
                setError('Error fetching data');
            });
    }, []);

    // useEffect(() => {
    //     const fetchData = async () => {
    //         const response = await fetch('/blog/wp-json/custom/v5/top-league/api');
    //         const jsonData = await response.json();
    //         setData(jsonData);
    //       //  console.log(jsonData);
    //     }
    //     fetchData();
    // }, []);

    return (
        <>
            <div className="top-leagues-section" id="top-league">
                <div className="top-leagues-section__header">
                    <h2>Top Leagues</h2>
                    <div class="top-leagues-section__divider"></div>
                </div>

                <div className="top-leagues-section__top-leagues">
                        

                            {dynamicSlug === "football" && footballdata.map((league, index) => (
                                <div key={index} className="top-leagues-section__league">
                                    <Link to={league.link}>
                                        <img src={league.icon} alt={league.alt} className="top-leagues-section__league-logo"  loading="lazy" />
                                        <span className="top-leagues-section__league-name">{league.league_name}</span>
                                    </Link>
                                </div>
                            ))}

                            {dynamicSlug === "ice-hockey" && icedata.map((league, index) => (
                                <div key={index} className="top-leagues-section__league">
                                    <Link to={league.link}>
                                        <img src={league.icon} alt={league.alt} className="top-leagues-section__league-logo"  loading="lazy" />
                                        <span className="top-leagues-section__league-name">{league.league_name}</span>
                                    </Link>
                                </div>
                            ))}

                            {dynamicSlug === "baseball" && baseballdata.map((league, index) => (
                                <div key={index} className="top-leagues-section__league">
                                    <Link to={league.link}>
                                        <img src={league.icon} alt={league.alt} className="top-leagues-section__league-logo"  loading="lazy" />
                                        <span className="top-leagues-section__league-name">{league.league_name}</span>
                                    </Link>
                                </div>
                            ))}

                            {dynamicSlug === "basketball" && basketballdata.map((league, index) => (
                                <div key={index} className="top-leagues-section__league">
                                    <Link to={league.link}>
                                        <img src={league.icon} alt={league.alt} className="top-leagues-section__league-logo"  loading="lazy" />
                                        <span className="top-leagues-section__league-name">{league.league_name}</span>
                                    </Link>
                                </div>
                            ))}

                            {dynamicSlug === "volleyball" && volleyballdata.map((league, index) => (
                                <div key={index} className="top-leagues-section__league">
                                    <Link to={league.link}>
                                        <img src={league.icon} alt={league.alt} className="top-leagues-section__league-logo"  loading="lazy" />
                                        <span className="top-leagues-section__league-name">{league.league_name}</span>
                                    </Link>
                                </div>
                            ))}

                            {/* <li className="list-leagues-item">
                                <img src="/bet-assets/site/image/football/league/serie-a-6700e7c2ec98a866.png" alt="France" className="leagues-icon" />
                                <Link to="/football/serie-a/75">    <span className="list-leagues"> Serie A </span> </Link>

                            </li>
                           */}

                    </div>
                
            </div>
        </>
    );
}

export default Topleagues;