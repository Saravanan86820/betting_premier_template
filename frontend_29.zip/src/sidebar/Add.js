import React from 'react';
import '../index.css';


function Add() {


    return (

        <>
            <div className="match" id="match-add">
                <div className="match-content1">
                    <div className="slidebar-ads">
                    <a href="/blog/bet365-games/" >
                    <img  src="/assets/image/common/bet365-addrun.svg" alt="bet365" width="273"  height="455"  className="slidebar-ads-image" loading="lazy"/>
                    </a>
                    
                    </div>
                </div>
            </div>


        </>
    );
}

export default Add;