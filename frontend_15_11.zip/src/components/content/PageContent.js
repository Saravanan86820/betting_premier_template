import React, { useState, useEffect } from 'react';
import parse from 'html-react-parser';

/**
 * Fetch and display content for a specific page
 * @param {Object} props 
 * @returns 
 */
export default function PageContent(props) {
  const pageName = props.pageName;
  const api = `/api/widget/${pageName}-page-content`;
  const [pageData, setPageData] = useState({});
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // unescape html characters
  const unescapeHtml = (unsafe) => {
    return unsafe
      .replace(/&amp;/g, "&")
      .replace(/&lt;/g, "<")
      .replace(/&gt;/g, ">")
      .replace(/&quot;/g, "\"")
      .replace(/&#039;/g, "'");
  };

  // get page content data
  useEffect(() => {
    setLoading(true);
    fetch(api, { method: 'POST' })
      .then(resp => resp.json())
      .then(respData => {
        if (respData.status !== 'true') throw new Error(respData.message);
        let data = respData.data[0].data;
        setPageData(unescapeHtml(data));
        setLoading(false);
      })
      .catch(error => {
        console.error('Error:', error);
        setLoading(false);
        setError(error);
      });
  }, [pageName]);

  if (loading) return null;
  if (error) return <div>Page Content Error: {error.message}</div>;

  return (
    <div className="bet-page-content">
      {parse(pageData)}
    </div>
  );
}