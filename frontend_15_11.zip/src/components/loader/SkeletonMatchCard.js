import React from "react";
import "./Skeleton.css";

export default function SkeletonMatchCard() {
  return (
    <div className="bet-skeleton-wrap">
      {[1, 2, 3, 4, 5, 6].map((i) => (
        <div className="bet-match-card-block" key={i}>
          <div className="bet-skeleton-line bet-skeleton-title"></div>

          <div className="bet-skeleton-game-row">
            <div className="bet-skeleton-logo"></div>
            <div className="bet-skeleton-line short"></div>
            <div className="bet-skeleton-line score"></div>
          </div>

          <div className="bet-skeleton-game-row">
            <div className="bet-skeleton-logo"></div>
            <div className="bet-skeleton-line short"></div>
            <div className="bet-skeleton-line score"></div>
          </div>
        </div>
      ))}
    </div>
  );
}

