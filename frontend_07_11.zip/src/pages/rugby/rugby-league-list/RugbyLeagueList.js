
import React from "react";

function RugbyLeagueList() {



    return (

        <>
            <div className="league-main-container  bg-image-color" data-color="blue" id="league-banner-top">
                <div className="league-main-bg" ></div>
                <div className="league-main-row" >
                    <div className="league-main-images">
                        <div className="league-main-imageslist">
                            <img
                                src="/bet-assets/site/image/football/league/premier-league-670512275ca0f775.png"
                                alt="league-banner"
                                className="league-images-nav"
                                loading="lazy" width="100" height="100"
                            />

                        </div>
                        <div className="league-content-list">
                            <h4 className="league-heading">
                                Premier League Handball   </h4>

                            <div className="country-image mtb">
                                <div className="country-image-span">
                                    <span>

                                        <img
                                            src="/bet-assets/site/image/country/gb-eng.svg"
                                            alt='data'
                                            width="26"
                                            height="26"
                                            className="league-images-sub"
                                            loading="lazy"
                                        />

                                        <span className="country_name"> England </span>
                                    </span>
                                </div>

                                <div className="select-dropdown">



                                </div>

                            </div>


                            <div>



                                <div>
                                    <div className="Box progress-match">
                                        <div className="Box cezFoR sc-8d2eba24-0 progress-match--value" ></div>
                                    </div>
                                    <div className="percentage-value">
                                        <div className="percentage--value-date">
                                            Aug 16, 2024
                                        </div>
                                        <div className="percentage--value-date">
                                            May 25, 2025
                                        </div>
                                    </div>

                                </div>

                            </div>


                        </div>
                    </div>
                </div>
            </div>

        </>

    );
}

export default RugbyLeagueList;