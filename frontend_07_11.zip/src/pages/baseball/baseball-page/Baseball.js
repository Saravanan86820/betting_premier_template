import React from "react";
import '../../../index.css';
import { Helmet } from 'react-helmet';
import BaseballScorelist from "./BaseballScorelist";


import Topleagues from "../../../sidebar/Topleagues";
import Alleagues from "../../../sidebar/Alleagues";
import Add from "../../../sidebar/Add";

function Basketball() {



  return (
    <>

      <Helmet>
        <title>Baseball News, Fixtures, Scores & Updates</title>
        <meta
          name="description" content=" Your one-stop destination for Baseball news, fixtures, Standings, scores, and updates. Get the latest from the world of Baseball, all in one place."
        />
      </Helmet>

      <div className="mvp-main-box-cont">
        <div className="container-scorelist container-betting-tools">
          <div className="container-score">

            <div className="column-score large">
              <div className="basketball-page-container" id="basketball-page">
                <BaseballScorelist />

              </div>
            </div>

            <div className="column-score small">

              <div className="container-slide">

                {/* <FeatureMatch /> */}
                <Topleagues />
                <Add />
                <Alleagues />

              </div>

            </div>
          </div>
        </div>
      </div>

    </>
  );

}

export default Basketball;