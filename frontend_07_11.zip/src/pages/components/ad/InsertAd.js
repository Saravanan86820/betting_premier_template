import React, { useEffect } from "react";

let adScriptLoaded = false; // Global flag

const InsertAd = () => {
  useEffect(() => {
    if (!adScriptLoaded) {
      const script = document.createElement('script');
      script.src = '/direct/insert-ad.js';
      script.async = true;
      document.body.appendChild(script);
      adScriptLoaded = true; // Set the flag

      return () => {
        // Cleanup: Remove the script when the component unmounts
        // or flag might be set to false here, but that is not really needed in this case.
      };
    }
  }, []);

  return <></>;
};

export default InsertAd;