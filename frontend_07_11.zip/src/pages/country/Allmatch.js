import React, { useState, useEffect } from 'react';
import '../../index.css';

import { Link } from 'react-router-dom';
import { useLocation } from "react-router-dom";

function Allmatch({ matchCode }) {

  const location = useLocation();
  const slug = location.pathname.split("/")[1];

  const [leagues, setLeagues] = useState([]);


  const gameURL = `/api/sports/${slug}/country/${matchCode}/league`;

  useEffect(() => {
    fetch(gameURL, { method: 'GET' }) 
      .then(response => response.json())
      .then(json => {

        if (json.data && json.data.length > 0) {
          // console.log('Fetched countries:', json.data);
          setLeagues(json.data);
        } else {
          console.log('No countries found or data is empty.');
        }
      })
      .catch(error => console.error('Error fetching countries:', error));
  }, [matchCode]);



  let defaultImage = "";

  if (slug === "football") {
    defaultImage = '/assets/image/defaulticon.svg';
  } else if (slug === "ice-hockey") {
    defaultImage = '/assets/image/ice-hockey/hockey-default.svg';
  } else if (slug === "baseball") {
    defaultImage = '/assets/image/baseball/default-baseball-small.png';
  } else if (slug === "basketball") {
    defaultImage = '/assets/image/basketball/basketball-1.png';
  } else if (slug === "volleyball") {
    defaultImage = '/assets/image/volleyball/d-volleyball.svg';
  } else if (slug === "handball") {
    defaultImage = '/assets/image/handball/handball.svg';
  } else if (slug === "rugby") {
    defaultImage = '/assets/image/rugby/rugby-default.svg';
  }
  else {
    defaultImage = '/assets/image/defaulticon.svg';
  }


  return (
    <>
      <div className="league-section-live" id="gamelive-page">


        <div className="league-section-row">

          <div className="country-container">

            <div className="league-heading-sub">
              <img
                src={`/bet-assets/site/image/country/${matchCode}.svg`}
                alt="League"
                width="25"
                height="25"
                className="country_icon"
                loading="lazy"
              />
              <h1>All leagues</h1>
            </div>
            <div class="league-heading-divider" style={{width:120}}></div>



            {leagues && leagues.length > 0 ? (

              <div className="country-row">

                {leagues.map((league, index) => {

                  const leagueurl = league["display_name"] ? league["display_name"].replace(/[^\w\s]/g, "").replace(/\//g, '-').replace(/\s+/g, "-").toLowerCase() : "";

                  const leagueid = league["id"] ? league["id"] : "";

                  const leagueslug = `${leagueurl}/${leagueid}`;


                  return (
                    // <div className="country-list" key={index}>
                      <Link to={`/${slug}/${leagueslug}`} className="country-list" key={index}> 
                      <div className='league-country-items' >
                        <div className="league-country-image">
                        <img
                          src={league.icon ? league.icon : defaultImage}
                          alt={league.display_name || 'league-banner'}
                          className="league-images-nav"
                          onError={(e) => { e.target.src = defaultImage; }}
                          loading="lazy" width="100" height="100"
                        />

                      </div>
                      <div className="league-country-name">
                         {league.display_name} 
                      </div>

                      </div>
                      </Link>
                      
                    // </div>
                  );
                }

                )}


              </div>
            ) :
              (<div className="country-row">

                <p className="no-leagues">No leagues available</p>

              </div>)}
          </div>
        </div>


      </div>
    </>
  );
}

export default Allmatch;