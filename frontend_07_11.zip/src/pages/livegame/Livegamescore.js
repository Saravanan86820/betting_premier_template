import React, { useEffect, useState } from 'react';
import '../../index.css';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import LocalTime from "../../utility/LocalTime";
import { useLocation } from "react-router-dom";



export default function Livescore() {
    
    const location = useLocation();
    const slug = location.pathname.split("/")[1]; 

    const [livescore, setLivescore] = useState([]); // State to hold live scores
    const [loading, setLoading] = useState(true); // State for loading status
    const [error, setError] = useState(null); // State for error handling
    const [gameMatch, setGameMatch] = useState({});
    const [currentPage, setCurrentPage] = useState(1);
    const itemsPerPage = 15;

    const Gamelive = `/api/sports/${slug}/game/live`;

    useEffect(() => {
        const fetchData = async () => {
            try {
                const response = await fetch(Gamelive, { method: 'POST' });
                const json = await response.json();
              //  console.log('Fetched all Gamelive:', json);
                setLivescore(json.data); // Set the fetched data
            } catch (err) {
                const errorMessage = `Error fetching Gamelive data`;
                console.error(errorMessage); 
              //  setError('Error fetching Gamelive data');
            } finally {
                setLoading(false); // Always stop loading once data is fetched
            }
        };

        fetchData();
    }, []);

    useEffect(() => {
        if (livescore && livescore.length > 0) {
            livescore.forEach(live => {
                if (!gameMatch[live.id]) {
                    fetchGameDetails(live.id);
                }
            });
        }
    }, [livescore]);

    const fetchGameDetails = (liveid) => {

        const LeagueGame = `/api/sports/football/game/${liveid}`;
        //console.log("LeagueGameURL", LeagueGame);

        fetch(LeagueGame, { method: 'POST' })
            .then(response => response.json())
            .then(json => {
                if (json && json.data) {
                    setGameMatch(prevState => ({
                        ...prevState,
                        [liveid]: json.data,
                    }));
                } else {
                    const errorMessage = `Game data not found for match ${liveid}`;
                   // setError(errorMessage); // Set the error in your state or display logic
                    console.error(errorMessage);
                }
            })
           .catch(() => {
                const errorMessage = `Error fetching game data for match ${liveid}`;
                console.error(errorMessage);
                // setError(errorMessage);
            });
    };

    // Handle next and previous pagination
    const handleNext = () => {
        if (currentPage < Math.ceil(Object.keys(gameMatch).length / itemsPerPage)) {
            setCurrentPage(currentPage + 1);
        }
    };

    const handlePrevious = () => {
        if (currentPage > 1) {
            setCurrentPage(currentPage - 1);
        }
    };

    if (loading) {
        return <div>Loading...</div>;
    }

    if (error) {
        return <div>Error: {error}</div>;
    }

    const startIndex = (currentPage - 1) * itemsPerPage;
    const currentItems = Object.entries(gameMatch).slice(startIndex, startIndex + itemsPerPage);

    // console.log("currentItems", currentItems);
    // console.log("startIndex", startIndex);

    let defaultImage = '/assets/image/defaulticon.svg';

    return (

       <>  


        <div className="league-section-live" id="gamelive-page">
            <div className="league-section-row">

                <div className="header-bg-slide">
                    <div className="header-flex">
                        <div className="country-images">


                            <img
                                src="/assets/image/live3.svg"
                                alt="live"
                                width="26"
                                height="26"
                                className="country-icon"
                            />
                        </div>

                        <div className="country-content">
                            <span className="country-name">

                            </span>
                            <h3 className="text-slide">
                                Live Game

                            </h3>
                        </div>
                    </div>
                </div>



                {currentItems && currentItems.length > 0 ? (
                    <div className="league-container">
                        {currentItems.map(([liveid, match]) => {
                            const fullStatus = JSON.parse(match.full_status);
                            const resultData = JSON.parse(match.result);

                            const hometime = match.time;
                            const utctime = LocalTime(hometime);

                            const homeScore = resultData.goals && resultData.goals.home !== null ? resultData.goals.home :
                            resultData.fulltime.home !== null ? resultData.fulltime.home : '-';

                            const awayScore = resultData.goals && resultData.goals.away !== null ? resultData.goals.away :
                            resultData.fulltime.away !== null ? resultData.fulltime.away : '-';
  
                            let gameslugeurl =   match['name'] ? match['name'].replace(/\s+/g, '-').replace(/\//g, '-').replace(/-+/g, '-').toLowerCase() : "";
                            
                            return (
                                
                                <Link to={`/football/game/${gameslugeurl}/${liveid}`}  key={liveid}>
                                     

                                    <div className="league-rows" data-id={liveid}>
                                        <div className="league-rows-iteam-match1">
                                            <div className="league-rows-iteam-time">
                                                <div className="match-date">
                                                    <span className="live-date">{utctime}</span>
                                                </div>
                                                <div className="match-status">{fullStatus.long}</div>
                                            </div>
                                        </div>
                                        <div className="league-rows-iteam-match2">
                                            <div className="league-match-data">
                                                <div className="league-match-img">
                                                <img
                                                            src={match.home.icon ? match.home.icon : defaultImage}
                                                            alt={match.home.display_name || 'league'}
                                                            className="league-live-img"
                                                            onError={(e) => { e.target.src = defaultImage; }}
                                                             width="20"  height="20"
                                                        />
                                                    <span>{match.home.display_name}</span>
                                                </div>
                                                <div className="league-match-score">
                                                {homeScore}
                                                </div>
                                            </div>
                                            <div className="league-match-data">
                                                <div className="league-match-img">
                                                <img
                                                            src={match.away.icon ? match.away.icon : defaultImage}
                                                            alt={match.away.display_name || 'league'}
                                                            className="league-live-img"
                                                            onError={(e) => { e.target.src = defaultImage; }}
                                                             width="20"  height="20"
                                                        />
                                                    <span>{match.away.display_name}</span>
                                                </div>
                                                <div className="league-match-score">
                                                {awayScore}
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </Link>
                            );
                        })}
                    </div>
                ) : (
                    <div className="live-games--score">No game matches available.</div>
                )}

                {Object.keys(gameMatch).length > 15 && (

                    <div className="pagination-buttons">
                        <button onClick={handlePrevious} disabled={currentPage === 1} className="game-button">
                            Previous
                        </button>
                        <button onClick={handleNext} disabled={currentPage === Math.ceil(Object.keys(gameMatch).length / itemsPerPage)} className="game-button">
                            Next
                        </button>
                    </div>

                )}
            </div>

        </div>
        </>
    );
         
}
