import React, { useState, useEffect } from 'react';

import Navbar from "./components/navbar/Navbar";
import Sidebar from "./components/navbar/Sidebar";
import { BrowserRouter, Routes, Route, useLocation } from "react-router-dom";
import Home from "./pages/home/Home";
import ScrollToTop from './pages/home/ScrollToTop';
import Footer from "./components/fotter/Footer"

import Livegame from "./pages/livegame/Livegame";
import Leaguelist from "./pages/league-list/League-list";
import MatchSummary from "./pages/match-summary/MatchSummary";
import AllMatch from "./pages/allmatch/AllMatch";
import NotFound from './pages/404/NotFound';
import Loader from "./pages/loader/Loader";

import Countrymatch from "./pages/country/Countrymatch";

import Popup from './pages/components/ad/Pop';
import Venue from './pages/venue/Venue';
import Sports from './components/sports/Sports';
import Live from './components/sports/Live';



// The main App component that will contain the routes and hooks
const App = () => {
  // You must call the hook inside the component function
  const location = useLocation();
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setLoading(false);
  }, []);

  // Now, this check will work correctly
  if (location.pathname.startsWith('/blog/')) {
    return null;
  }
  return (
    <div className="App">
      {loading && <Loader />}
      <Navbar />
      <Sidebar />
      
      <ScrollToTop />
      <Routes>
        <Route path="/" element={<Home />} />

        {/* Sports routes */}
        <Route path="/football" element={<Sports />} />
        <Route path="/ice-hockey" element={<Sports />} />
        <Route path="/baseball" element={<Sports />} />
        <Route path="/basketball" element={<Sports />} />
        <Route path="/handball" element={<Sports />} />
        <Route path="/rugby" element={<Sports />} />
        <Route path="/volleyball" element={<Sports />} />

        {/* Live games routes */}
        <Route path="/:slug/live" element={<Live />} />

        {/* All your other routes */}
        <Route path="/:slug/:code" element={<Countrymatch />} />
        <Route path="/:slug/game/:formattedName/:id" element={<MatchSummary />} />
        <Route path="/:slug/:display_name/:id" element={<Leaguelist />} />
        <Route path="/:slug/:display_name/:id/season/:seasonYear" element={<Leaguelist />} />
        <Route path="/:slug/matches/:id" element={<AllMatch />} />
        <Route path="/:sport/venue/:id" element={<Venue />} />

        {/* 404 page */}                         
        <Route path="*" element={<NotFound />} />
      </Routes>
      <Footer />
      <Popup />
      
    </div>
  );
};

// Wrap the App component with BrowserRouter at the top level
const RootApp = () => (
  <BrowserRouter>
    <App />
  </BrowserRouter>
);

export default RootApp;
