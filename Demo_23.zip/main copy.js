

// Match detail overlay functionality
document.addEventListener('DOMContentLoaded', function() {
    // Constants and configuration
    // League and Match Data
    const LEAGUE_DATA = {
    "france_ligue1": {
        country: "France",
        league: "Ligue 1",
        flag: "https://upload.wikimedia.org/wikipedia/en/c/c3/Flag_of_France.svg",
        matches: [1, 2, 3, 4] // Match IDs from MATCH_DATA
    },
    "england_premier": {
        country: "England",
        league: "Premier League",
        flag: "https://upload.wikimedia.org/wikipedia/en/b/be/Flag_of_England.svg",
        matches: [5, 6, 7, 8]
    },
    "spain_laliga": {
        country: "Spain",
        league: "La Liga",
        flag: "https://upload.wikimedia.org/wikipedia/en/9/9a/Flag_of_Spain.svg",
        matches: [9, 10, 11, 12]
    },
    "germany_bundesliga": {
        country: "Germany",
        league: "Bundesliga",
        flag: "https://upload.wikimedia.org/wikipedia/en/b/ba/Flag_of_Germany.svg",
        matches: [13, 14, 15, 16]
    },
    "italy_seriea": {
        country: "Italy",
        league: "Serie A",
        flag: "https://upload.wikimedia.org/wikipedia/en/0/03/Flag_of_Italy.svg",
        matches: [17, 18, 19, 20]
    }
};

const MATCH_DATA = {
    // France Ligue 1 Matches
    1: {
        team1: { name: "PSG", logo: "img/teams/psg.png" },
        team2: { name: "Olympique Marseille", logo: "img/teams/Olympique.png" },
        date: "Today, 18:00",
        venue: "Parc des Princes",
        competition: "Ligue 1",
        status: "LIVE 65'",
        score: "2 - 1",
        stats: {
            possession: "58% - 42%",
            shots: "14 - 8",
            corners: "6 - 3",
            fouls: "12 - 15"
        }
    },
    2: {
        team1: { name: "Lyon", logo: "img/teams/lyon.png" },
        team2: { name: "Monaco", logo: "img/teams/monaco.png" },
        date: "Today, 20:00",
        venue: "Groupama Stadium",
        competition: "Ligue 1",
        status: "UPCOMING",
        score: "- - -",
        stats: {
            possession: "-",
            shots: "-",
            corners: "-",
            fouls: "-"
        }
    },
    3: {
        team1: { name: "Lille", logo: "img/teams/lille.png" },
        team2: { name: "Nice", logo: "img/teams/nice.png" },
        date: "Today, 16:30",
        venue: "Stade Pierre-Mauroy",
        competition: "Ligue 1",
        status: "LIVE 45'",
        score: "1 - 0",
        stats: {
            possession: "62% - 38%",
            shots: "9 - 4",
            corners: "4 - 1",
            fouls: "8 - 12"
        }
    },
    4: {
        team1: { name: "Rennes", logo: "img/teams/rennes.png" },
        team2: { name: "Lens", logo: "img/teams/lens.png" },
        date: "Today, 22:00",
        venue: "Roazhon Park",
        competition: "Ligue 1",
        status: "UPCOMING",
        score: "- - -",
        stats: {
            possession: "-",
            shots: "-",
            corners: "-",
            fouls: "-"
        }
    },

    // England Premier League Matches
    5: {
        team1: { name: "Arsenal", logo: "img/teams/arsenal.png" },
        team2: { name: "Manchester City", logo: "img/teams/mancity.png" },
        date: "Today, 15:00",
        venue: "Emirates Stadium",
        competition: "Premier League",
        status: "LIVE 72'",
        score: "1 - 1",
        stats: {
            possession: "48% - 52%",
            shots: "10 - 12",
            corners: "5 - 7",
            fouls: "9 - 11"
        }
    },
    6: {
        team1: { name: "Liverpool", logo: "img/teams/liverpool.png" },
        team2: { name: "Chelsea", logo: "img/teams/chelsea.png" },
        date: "Today, 17:30",
        venue: "Anfield",
        competition: "Premier League",
        status: "UPCOMING",
        score: "- - -",
        stats: {
            possession: "-",
            shots: "-",
            corners: "-",
            fouls: "-"
        }
    },
    7: {
        team1: { name: "Manchester United", logo: "img/teams/man-ltd.png" },
        team2: { name: "Tottenham", logo: "img/teams/tottenham.png" },
        date: "Today, 20:00",
        venue: "Old Trafford",
        competition: "Premier League",
        status: "LIVE 35'",
        score: "0 - 0",
        stats: {
            possession: "55% - 45%",
            shots: "6 - 4",
            corners: "3 - 2",
            fouls: "7 - 9"
        }
    },
    8: {
        team1: { name: "Newcastle", logo: "img/teams/newcastle.png" },
        team2: { name: "Aston Villa", logo: "img/teams/astonvilla.png" },
        date: "Tomorrow, 15:00",
        venue: "St James' Park",
        competition: "Premier League",
        status: "UPCOMING",
        score: "- - -",
        stats: {
            possession: "-",
            shots: "-",
            corners: "-",
            fouls: "-"
        }
    },

    // Spain LaLiga Matches
    9: {
        team1: { name: "Real Madrid", logo: "img/teams/realmadrid.png" },
        team2: { name: "Barcelona", logo: "img/teams/nice.png" },
        date: "Today, 21:00",
        venue: "Santiago Bernabéu",
        competition: "LaLiga",
        status: "LIVE 60'",
        score: "2 - 1",
        stats: {
            possession: "51% - 49%",
            shots: "13 - 9",
            corners: "6 - 4",
            fouls: "14 - 16"
        }
    },
    
    11: {
         team1: { name: "Atletico Madrid", logo: "img/teams/atletico.png" },
        team2: { name: "Sevilla", logo: "img/teams/sevilla.png" },
        date: "Today, 18:00",
        venue: "Mestalla",
        competition: "LaLiga",
        status: "LIVE 72'",
        score: "1 - 2",
        stats: {
            possession: "47% - 53%",
            shots: "8 - 11",
            corners: "3 - 5",
            fouls: "12 - 10"
        }
    },
    12: {
        team1: { name: "Real Sociedad", logo: "img/teams/realsociedad.png" },
        team2: { name: "Athletic Bilbao", logo: "img/teams/athletic.png" },
        date: "Tomorrow, 20:00",
        venue: "Anoeta",
        competition: "LaLiga",
        status: "UPCOMING",
        score: "- - -",
        stats: {
            possession: "-",
            shots: "-",
            corners: "-",
            fouls: "-"
        }
    },

    // Germany Bundesliga Matches
    13: {
        team1: { name: "Bayern Munich", logo: "img/teams/bayern.png" },
        team2: { name: "Borussia Dortmund", logo: "img/teams/dortmund.png" },
        date: "Today, 18:30",
        venue: "Allianz Arena",
        competition: "Bundesliga",
        status: "LIVE 78'",
        score: "3 - 2",
        stats: {
            possession: "59% - 41%",
            shots: "16 - 8",
            corners: "7 - 3",
            fouls: "10 - 14"
        }
    },
    14: {
        team1: { name: "Bayer Leverkusen", logo: "img/teams/leverkusen.png" },
        team2: { name: "RB Leipzig", logo: "img/teams/leipzig.png" },
        date: "Today, 16:30",
        venue: "BayArena",
        competition: "Bundesliga",
        status: "UPCOMING",
        score: "- - -",
        stats: {
            possession: "-",
            shots: "-",
            corners: "-",
            fouls: "-"
        }
    },
    

    // Italy Serie A Matches
    17: {
        team1: { name: "Inter Milan", logo: "img/teams/inter.png" },
        team2: { name: "AC Milan", logo: "img/teams/ac.png" },
        date: "Today, 20:45",
        venue: "San Siro",
        competition: "Serie A",
        status: "LIVE 55'",
        score: "1 - 0",
        stats: {
            possession: "53% - 47%",
            shots: "11 - 7",
            corners: "4 - 3",
            fouls: "9 - 11"
        }
    },
    
    19: {
        team1: { name: "Roma", logo: "img/teams/roma.webp" },
        team2: { name: "Lazio", logo: "img/teams/lazio.png" },
        date: "Today, 15:00",
        venue: "Stadio Olimpico",
        competition: "Serie A",
        status: "FINISHED",
        score: "1 - 1",
        stats: {
            possession: "49% - 51%",
            shots: "9 - 10",
            corners: "4 - 5",
            fouls: "13 - 15"
        }
    },
    20: {
        team1: { name: "Atalanta", logo: "img/teams/atalanta.png" },
        team2: { name: "Fiorentina", logo: "img/teams/fiorentina.png" },
        date: "Tomorrow, 20:45",
        venue: "Gewiss Stadium",
        competition: "Serie A",
        status: "UPCOMING",
        score: "- - -",
        stats: {
            possession: "-",
            shots: "-",
            corners: "-",
            fouls: "-"
        }
    }
};
   
    
    const SLIDE_INTERVAL = 3000;
    
    // DOM Elements
    const elements = {
        matchDetailOverlay: document.getElementById('matchDetailOverlay'),
        matchDetailContent: document.getElementById('matchDetailContent'),
        defaultMatchContent: document.getElementById('defaultMatchContent'),
        closeBtn: document.getElementById('closeMatchDetail'),
        track: document.querySelector('.match-slider__track'),
        slides: document.querySelectorAll('.match-slider__slide'),
        prevButton: document.querySelector('.match-slider__button--prev'),
        nextButton: document.querySelector('.match-slider__button--next'),
        indicators: document.querySelectorAll('.match-slider__indicator'),
        leagueHeaders: document.querySelectorAll('.league-list__header'),
        countryHeaders: document.querySelectorAll('.leagues-container__country-header')
    };
    
    // State
    let currentSlide = 0;
    
    // Function to populate leagues with matches
    function populateLeagues() {
        const leagueContainers = document.querySelectorAll('.league-list__matches');
        
        leagueContainers.forEach((container, index) => {
            const leagueKey = Object.keys(LEAGUE_DATA)[index];
            const league = LEAGUE_DATA[leagueKey];
            
            container.innerHTML = ''; // Clear existing content
            
            league.matches.forEach(matchId => {
                const match = MATCH_DATA[matchId];
                if (match) {
                    const matchElement = createMatchElement(match, matchId);
                    container.appendChild(matchElement);
                }
            });
        });
        
        // Re-initialize match item event listeners after populating
        initializeMatchItemListeners();
    }

    // Function to create match element
    function createMatchElement(match, matchId) {
        const isLive = match.status.includes('LIVE');
        const isFinished = match.status.includes('FINISHED');
        const isUpcoming = match.status.includes('UPCOMING');
        
        const statusClass = isLive ? 'match-item--live' : 
                           isFinished ? 'match-item--finished' : 
                           'match-item--upcoming';
        
        const [homeScore, awayScore] = match.score.split(' - ');
        const [date, time] = match.date.split(', ');
        const statusText = isLive ? match.status : (isUpcoming ? time : 'FT');
        
        const matchDiv = document.createElement('div');
        matchDiv.className = `match-item ${statusClass}`;
        matchDiv.setAttribute('data-match', matchId);
        matchDiv.innerHTML = `
            <div class="match-item__time">
                <div class="match-item__date">${date}</div>
                <div class="match-item__status">${statusText}</div>
            </div>
            <div class="match-item__details">
                <div class="match-item__team">
                    <div class="match-item__team-info">
                        <img class="match-item__team-logo" src="${match.team1.logo}" alt="${match.team1.name}">
                        <span class="match-item__team-name">${match.team1.name}</span>
                    </div>
                    <div class="match-item__score">${homeScore}</div>
                </div>
                <div class="match-item__team">
                    <div class="match-item__team-info">
                        <img class="match-item__team-logo" src="${match.team2.logo}" alt="${match.team2.name}">
                        <span class="match-item__team-name">${match.team2.name}</span>
                    </div>
                    <div class="match-item__score">${awayScore}</div>
                </div>
            </div>
        `;
        
        return matchDiv;
    }

    // Initialize match item event listeners
    function initializeMatchItemListeners() {
        const matchItems = document.querySelectorAll('.match-item');
        
        matchItems.forEach(item => {
            item.addEventListener('click', function() {
                const matchId = this.getAttribute('data-match');
                showMatchDetail(matchId);
            });
        });
    }
    
    // Match Detail Functions
    function showMatchDetail(matchId) {
        const match = MATCH_DATA[matchId];
        if (!match) return;
        
        matchDetailContent.innerHTML = createMatchDetailHTML(match);
        elements.matchDetailOverlay.style.display = 'flex';
        elements.defaultMatchContent.style.display = 'none';
        
        const matchDetails = document.querySelector('.match-details');
        matchDetails.classList.add('match-details--overlay-open');
        matchDetails.scrollIntoView({ 
            behavior: 'smooth', 
            block: 'start',
            inline: 'nearest'
        });
    }
    
function createMatchDetailHTML(match) {
    const [homeScore, awayScore] = match.score.split(' - ');
    const isLive = match.status.includes('LIVE');
    const isFinished = match.status.includes('FINISHED');
    const minute = isLive ? match.status.split(' ')[1] : '';
    const [possessionHome, possessionAway] = match.stats.possession.split(' - ');
    const [shotsHome, shotsAway] = match.stats.shots.split(' - ');
    const [cornersHome, cornersAway] = match.stats.corners.split(' - ');
    const [foulsHome, foulsAway] = match.stats.fouls.split(' - ');
    
    // Create a unique identifier for the match
    const matchSlug = `${match.team1.name.toLowerCase()}-vs-${match.team2.name.toLowerCase()}-${Date.now()}`.replace(/\s+/g, '-');
    
    return `
    <div class="match-overview">
        <div class="match-overview__teams">
            <div class="match-overview__team">
                <img src="${match.team1.logo}" alt="${match.team1.name}" class="match-overview__team-logo">
                <span class="match-overview__team-name">${match.team1.name}</span>
            </div>
            <div class="match-overview__score">
                <span class="match-overview__score-home">${homeScore}</span>
                <span class="match-overview__vs">-</span>
                <span class="match-overview__score-away">${awayScore}</span>
            </div>
            <div class="match-overview__team">
                <img src="${match.team2.logo}" alt="${match.team2.name}" class="match-overview__team-logo">
                <span class="match-overview__team-name">${match.team2.name}</span>
            </div>
        </div>
        <div class="match-overview__status">
            <span class="match-overview__minute">${minute}</span>
            <span class="match-overview__live">${isLive ? 'LIVE' : isFinished ? 'FINISHED' : 'UPCOMING'}</span>
        </div>
        <button class="match-overview__full-details-btn" data-match-id="${matchSlug}">
            <svg width="16" height="16" viewBox="0 0 16 16" fill="currentColor">
                <path d="M6 14L5 13L10 8L5 3L6 2L12 8L6 14Z"/>
            </svg>
            Full View Details
        </button>
    </div>
    
    <div class="match-detail-overlay__info">
        <div class="match-detail-overlay__info-row">
            <span class="match-detail-overlay__info-label">Date & Time:</span>
            <span class="match-detail-overlay__info-value">${match.date}</span>
        </div>
        <div class="match-detail-overlay__info-row">
            <span class="match-detail-overlay__info-label">Venue:</span>
            <span class="match-detail-overlay__info-value">${match.venue}</span>
        </div>
        <div class="match-detail-overlay__info-row">
            <span class="match-detail-overlay__info-label">Competition:</span>
            <span class="match-detail-overlay__info-value">${match.competition}</span>
        </div>
        <div class="match-detail-overlay__info-row">
            <span class="match-detail-overlay__info-label">Referee:</span>
            <span class="match-detail-overlay__info-value">Clément Turpin</span>
        </div>
    </div>
    
    <div class="match-stats">
        <h4 class="match-stats__title">Statistics</h4>
        ${createStatBarHTML('Possession', possessionHome, possessionAway)}
        ${createStatBarHTML('Shots', shotsHome, shotsAway, shotsHome === '-' ? '50%' : '55%', shotsHome === '-' ? '50%' : '45%')}
        ${createStatBarHTML('Corners', cornersHome, cornersAway, cornersHome === '-' ? '50%' : '60%', cornersHome === '-' ? '50%' : '40%')}
        ${createStatBarHTML('Fouls', foulsHome, foulsAway, foulsHome === '-' ? '50%' : '45%', foulsHome === '-' ? '50%' : '55%')}
    </div>
`;
}

// Function to open full match details in new page
function openFullMatchDetails(matchId) {
    // Find the match data from MATCH_DATA
    const match = Object.values(MATCH_DATA).find(m => {
        const slug = `${m.team1.name.toLowerCase()}-vs-${m.team2.name.toLowerCase()}`.replace(/\s+/g, '-');
        return matchId.includes(slug);
    });
    
    if (!match) {
        console.error('Match not found:', matchId);
        return;
    }
    
    // Store match data in sessionStorage
    sessionStorage.setItem('fullMatchData', JSON.stringify(match));
    sessionStorage.setItem('matchSlug', matchId);
    
    // Open new page
    window.open('match-details.html', '_blank');
}

// Add event listener for full details buttons
function initializeFullDetailsButtons() {
    document.addEventListener('click', function(e) {
        if (e.target.closest('.match-overview__full-details-btn')) {
            const button = e.target.closest('.match-overview__full-details-btn');
            const matchId = button.getAttribute('data-match-id');
            openFullMatchDetails(matchId);
        }
    });
}
    
    function createStatBarHTML(label, homeValue, awayValue, homeWidth = homeValue, awayWidth = awayValue) {
        return `
            <div class="match-stats__item">
                <span class="match-stats__label">${label}</span>
                <div class="match-stats__bar">
                    <div class="match-stats__bar-home" style="width: ${homeWidth}">${homeValue}</div>
                    <div class="match-stats__bar-away" style="width: ${awayWidth}">${awayValue}</div>
                </div>
            </div>
        `;
    }
    
    function closeMatchDetail() {
        elements.matchDetailOverlay.style.display = 'none';
        elements.defaultMatchContent.style.display = 'block';
        
        const matchDetails = document.querySelector('.match-details');
        matchDetails.classList.remove('match-details--overlay-open');
    }
    
    // Slider Functions
    function updateSlider() {
        elements.track.style.transform = `translateX(-${currentSlide * 100}%)`;
        
        elements.indicators.forEach((indicator, index) => {
            indicator.classList.toggle('match-slider__indicator--active', index === currentSlide);
        });
    }
    
    function nextSlide() {
        currentSlide = (currentSlide + 1) % elements.slides.length;
        updateSlider();
    }
    
    function prevSlide() {
        currentSlide = (currentSlide - 1 + elements.slides.length) % elements.slides.length;
        updateSlider();
    }
    
    function goToSlide(index) {
        currentSlide = index;
        updateSlider();
    }
    
    // League Functions
    function toggleLeagueSection(header) {
        const matchesSection = header.nextElementSibling;
        const isVisible = matchesSection.classList.contains('league-list__matches--visible');
        
        // Close all other sections
        document.querySelectorAll('.league-list__matches--visible').forEach(section => {
            section.classList.remove('league-list__matches--visible');
        });
        
        // Toggle the clicked section if it wasn't already open
        if (!isVisible) {
            matchesSection.classList.add('league-list__matches--visible');
        }
    }
    
    function toggleLeagues(element) {
        const allLists = document.querySelectorAll('.leagues-container__league-list');
        const allIcons = document.querySelectorAll('.leagues-container__toggle-icon');
        const leagueList = element.nextElementSibling;
        const icon = element.querySelector('.leagues-container__toggle-icon');
        
        // Close all other sections
        allLists.forEach((list) => {
            if (list !== leagueList) {
                list.classList.add('leagues-container__league-list--hidden');
            }
        });
        
        // Reset all icons to '+'
        allIcons.forEach((i) => (i.textContent = '+'));
        
        // Toggle the clicked one
        const isHidden = leagueList.classList.toggle('leagues-container__league-list--hidden');
        icon.textContent = isHidden ? '+' : '−';
    }
    
    // Event Listeners
    function initializeEventListeners() {
        // League country headers
        elements.countryHeaders.forEach(header => {
            header.addEventListener('click', function() {
                toggleLeagues(this);
            });
        });
        
        // Close button
        elements.closeBtn.addEventListener('click', closeMatchDetail);
        
        // Slider controls
        elements.nextButton.addEventListener('click', nextSlide);
        elements.prevButton.addEventListener('click', prevSlide);
        
        // Slider indicators
        elements.indicators.forEach((indicator, index) => {
            indicator.addEventListener('click', () => goToSlide(index));
        });
        
        // League headers
        elements.leagueHeaders.forEach(header => {
            header.addEventListener('click', () => toggleLeagueSection(header));
        });
    }
    
    // Initialize
    function initialize() {

// Add dynamic styles first
    // addDynamicStyles();
    
    // Initialize Leagues Manager
    // const leaguesManager = new leaguesManager();
    // window.leaguesManager = leaguesManager; // Make it globally accessible
    
    // Populate leagues and initialize event listeners
    populateLeagues();
    initializeEventListeners();
    initializeFullDetailsButtons(); // Add this line
    
    // Auto-advance slides
    setInterval(nextSlide, SLIDE_INTERVAL);
    
    // Open the first league by default
    if (elements.leagueHeaders.length > 0) {
        toggleLeagueSection(elements.leagueHeaders[0]);
    }
    
    // Log statistics for debugging
    // console.log('Leagues Manager initialized:', leaguesManager.getStats());

        // populateLeagues(); // Populate leagues FIRST
        // initializeEventListeners();
        
        // // Auto-advance slides
        // setInterval(nextSlide, SLIDE_INTERVAL);
        
        // // Open the first league by default
        // if (elements.leagueHeaders.length > 0) {
        //     toggleLeagueSection(elements.leagueHeaders[0]);
        // }



    }
    



    // Start the application
    initialize();
});