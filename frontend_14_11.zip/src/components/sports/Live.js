import { Link, useLocation } from "react-router-dom";
import React, { useState, useEffect } from 'react';
import Topleagues from "../../sidebar/Topleagues";
import Alleagues from "../../sidebar/Alleagues";
import Add from "../../sidebar/Add";
import useCountryList from "../country/useCountryList";
import Meta from "../content/Meta";
import PageContent from "../content/PageContent";
import SimpleCard from "../score/SimpleCard";
import './Sports.css';
import Tab from "../tab/Tab";
import SortGames from "./SortGames";
import  LatestBlog from '../../post/blog/LatestBlog';
import  Footballblog from '../../post/blog/Footballblog';

/**
 * Main page for sports
 * @returns {JSX.Element}
 */
export default function Live() {
  const location = useLocation();

  // get sports name from url
  const sportsName = location.pathname.split("/")[1];

  // page name
  const pageName = `${sportsName}-live`;

  // schedule state
  const [schedule, setSchedule] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // api endpoint and data (refreshed when selectedDate changes)
  let api = `/api/sports/${sportsName}/game/live`;

  // get schedule data from api
  useEffect(() => {
    setSchedule([]);
    setLoading(true);
    setError(null);

    // abort controller to cancel fetch if component unmounts
    const controller = new AbortController();
    const signal = controller.signal;

    fetch(api, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      signal,
    })
      .then(response => response.json())
      .then(respData => {
        if (respData.status !== 'true')
          throw new Error(respData.message);
        setSchedule(respData.data);
        setLoading(false);
      })
      .catch(error => {
        if (error.name === 'AbortError') return; // fetch aborted
        setError(error);
        setLoading(false);
      });

    // Cleanup function cancels fetch if params change or component unmounts
    return () => {
      controller.abort();
    };
  }, [api]);

  const { gameList, leagueList, leagueOrder } = SortGames(schedule, {
    mode: 'live',
  });

  // get list of countries
  const countryList = useCountryList();
  if (!countryList || Object.keys(countryList).length === 0)
    return <div>Loading...</div>;

  if (loading)
    return <div>Loading schedule for {sportsName}...</div>;

  if (error)
    return <div>Error: {error.toString()}</div>;

  return (
    <>
      <Meta pageName={sportsName} />

      <div className="mvp-main-box-cont">
        <div className="container-match-page">

            <div className="column-match main">
              <div className="container-match">
                <div className="column-match large_column  league_cont">
              <div className="bet-page-top">
                <Tab items={
                  [
                    { name: "ALL", link: `/${sportsName}` },
                    { name: "LIVE", link: `/${sportsName}/live`, active: true },
                  ]
                } />
              </div>

              <div className="football-page-container" id="football-page">
                <div className="league-section-main">
                  {/* loop through league list */}
                  {leagueOrder.map(leagueId => {
                    const league = leagueList[leagueId];
                    const country = countryList[league.country_code] || null;
                    const leagueLink = `/${sportsName}/${league.name}/${leagueId}`;

                    const games = gameList[leagueId] || [];

                    return (
                      <div className="league-section-row" key={leagueId} data-id={leagueId}>
                        <div className="league-list__header">
                          
                            <div className="league-list__flag">
                              <img
                                src={`/bet-assets/site/image/country/${league.country_code}.svg`}
                                alt={country.display_name || league.country_code}
                                width="20"
                                height="20"
                                // className="country-icon"
                                loading="lazy" />
                            </div>
                            <div className="league-list__league-info">
                                                          <Link to={leagueLink}>
                                                            <span className="league-list__country-name">{country.display_name || league.country_code}</span>
                                                            <h3 className="league-list__league-title">{league.display_name}</h3>
                                                          </Link>
                                                        </div>

                        </div>

                        <div className="league-container sport-loop" id="sport_data-loop">
                          {/* loop through games */}
                          {games.map(game => {
                            return (<SimpleCard key={game.id} sports={sportsName} game={game} />);
                          })}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              <PageContent pageName={pageName} />
            </div>
                <div className="column-match small_column">
                <Topleagues />
                <Alleagues />

                </div>
              </div>
            </div>

            <div className="column-match side">

              <div className="container-slide">
                <Add />
                <LatestBlog />
                <Footballblog />
              </div>
            </div>
          </div>
        
      </div >
    </>
  );
};

