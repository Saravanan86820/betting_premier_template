import React, { useEffect, useState } from "react";
import { useParams } from 'react-router-dom';
import { Helmet } from "react-helmet";
import '../components/Components.css';
import './Venue.css';
import RecentBlog from "../../sidebar/RecentBlog";
import InsertAd from "../components/ad/InsertAd";
import SafeImage from "../../utility/Safeimage";

export default function Venue() {
  const { sport, id } = useParams();
  let [data, setData] = useState(null);
  let [countryData, setCountryData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const api = `/api/sports/${sport}/venue/${id}`;

  useEffect(() => {
    fetch(api, { method: 'GET' })
      .then(response => response.json())
      .then(respData => {
        if (respData['status'] !== 'true')
          return;
        if (respData && respData['data'] && respData['data'].length > 0) {
          respData = respData['data'][0];
          if (typeof respData['more'] === 'string')
            respData['more'] = JSON.parse(respData['more']);

          // get country details
          let countryData = getCountry(respData['country_code']);

          // set data
          setData(respData);

          // console.log(respData);
          
          setCountryData(countryData);
        }
        else
          setError('Venue not found');
        setLoading(false);
      })
      .catch(err => {
        console.error('Error fetching venue details:', err);
        setLoading(false);
      });
  }, []);

  // validate response
  if (loading)
    return <div>Loading...</div>;
  if (error)
    return <div>{error}</div>;
  if (!data || typeof data !== 'object')
    return <div>Venue data not available.</div>;

  const countryIcon = `/bet-assets/site/image/country/${data['country_code']}.svg`;
  const defaultImage = '/bet-assets/site/image/football/venue/venue-default.png';

  return (
    <>
      <Helmet>
        <title>{`${data['name']} Venue`}</title>
        <meta name="description" content={`${data['name']} is a ${sport} venue in ${data['more']['country']}`} />
      </Helmet>

      <div className="mvp-main-box-cont" data-page="venue">
        <div className="main-box-container">
          <div className="container-match">
            <div className="column-match large_column">

              <div className="stadium">
      {/* Stadium Header */}
      <div className="stadium__header">
        <img
          src={countryIcon} 
           alt={countryData['name']}
          className="stadium__flag"
        />
        <div className="stadium__header-text">
          <h1 className="stadium__name">{data['name']}</h1>
          <p className="stadium__location">{data['more']['country']}</p>
        </div>
      </div>

      {/* Stadium Image */}
      <div className="stadium__image">
        <SafeImage
           src={data['more']['image']}
          // src="/bet-assets/site/image/games/1.jpg"
          className="stadium__photo"
           fallbackSrc={defaultImage}
           alt={data['name']}
        />
      </div>

      {/* Stadium Details */}
      <div className="stadium__details">
        <div className="stadium__detail-item">
          <div className="stadium__detail-icon">
            <img src="/bet-assets/site/image/venue/name.png"></img>
          </div>
          <div className="stadium__detail-content">
            <span className="stadium__detail-label">Name</span>
            <span className="stadium__detail-value">{data['name']}</span>
          </div>
        </div>
        <div className="stadium__detail-item">
          <div className="stadium__detail-icon">
            <img src="/bet-assets/site/image/venue/location.png" style={{width:20,height:25}}></img>
          </div>
          <div className="stadium__detail-content">
            <span className="stadium__detail-label">Address</span>
            <span className="stadium__detail-value">{data['more']['address']}</span>
          </div>
        </div>
        <div className="stadium__detail-item">
          <div className="stadium__detail-icon">
            <img src="/bet-assets/site/image/venue/city.png"></img>
          </div>
          <div className="stadium__detail-content">
            <span className="stadium__detail-label">City</span>
            <span className="stadium__detail-value">{data['more']['city']}</span>
          </div>
        </div>
        
        <div className="stadium__detail-item">
          <div className="stadium__detail-icon">
            <img src="/bet-assets/site/image/venue/country.png" style={{width:22,height:26}}></img>
          </div>
          <div className="stadium__detail-content">
            <span className="stadium__detail-label">Country</span>
            <span className="stadium__detail-value">{data['more']['country']}</span>
          </div>
        </div>
        <div className="stadium__detail-item">
          <div className="stadium__detail-icon">
            <img src="/bet-assets/site/image/venue/surface.png"></img>
          </div>
          <div className="stadium__detail-content">
            <span className="stadium__detail-label">Surface</span>
            <span className="stadium__detail-value">{data['more']['surface']}</span>
          </div>
        </div>
        <div className="stadium__detail-item">
          <div className="stadium__detail-icon">
            <img src="/bet-assets/site/image/venue/capacity.png"></img>
          </div>
          <div className="stadium__detail-content">
            <span className="stadium__detail-label">Capacity</span>
            <span className="stadium__detail-value">{data['more']['capacity']}</span>
          </div>
        </div>

        
      </div>

      {/* Stadium Description */}
      {/* <div className="stadium__description">
        <h2 className="stadium__description-title">About the Stadium</h2>
        <p className="stadium__description-text">
          Old Trafford, often called "The Theatre of Dreams", is one of the most iconic football stadiums in the world.
          Located in Greater Manchester, it has hosted countless Premier League and international matches. Known for its
          rich history and passionate atmosphere, it remains the proud home of Manchester United.
        </p>
        <p className="stadium__description-text">
          The stadium has undergone several renovations over the years, most notably after damage sustained during World
          War II. With its distinctive red seating and the iconic Sir Alex Ferguson Stand, Old Trafford continues to be a
          landmark destination for football fans worldwide.
        </p>
      </div> */}
    </div>

            </div>

            <div className="column-match small_column">
              <RecentBlog />
              <div className="match bet-ad-insert js-bet-ad-insert">
                <InsertAd />
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );

  async function getCountry(code) {
    const response = await fetch(`/api/country/${code}`, { method: 'POST' });
    const respData = await response.json();
    if (respData['status'] !== 'true')
      setError('Country data not found');
    if (respData && respData['data'])
      setCountryData(respData['data']);
    else
      setError('Country data not found');
  }
}
