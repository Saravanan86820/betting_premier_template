import React, { useEffect, useState } from "react";
import '.././Components.css';
import { Helmet } from 'react-helmet';
// import { useParams } from 'react-router-dom';
import LocalTime from "../../../utility/LocalTime";
const HtmlToReactParser = require('html-to-react').Parser;
import { Link, useParams } from 'react-router-dom';
import Oddsdata from "./Oddsdata";

function GameScore() {
    const { id } = useParams();
    const [gameData, setGameMatch] = useState(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

    const gameAPI = `/api/sports/baseball/game/${id}`;

    useEffect(() => {
        fetch(gameAPI, { method: 'POST' })
            .then(response => response.json())
            .then(json => {

                //console.log('Fetched match data:', json);
                if (json['status'] !== 'true') {
                    return;
                }

                if (json && json['data']) {
                    setGameMatch(json['data']); // Store the entire game data
                } else {
                    setError('Game not found');
                }
                setLoading(false);
            })

            .catch(err => {
                console.error('Error fetching match season:', err);
                setLoading(false);
            });
    }, [id]);

    // validate response
    if (loading)
        return <div>Loading...</div>;
    if (error)
        return <div>{error}</div>;
    if (!gameData)
        return <div>No game data available.</div>;

    const resultHtml = result(gameData['full_status'], gameData['result'], gameData['time']);
    const homeHtml = gameData['home'] ? team(gameData['home']) : '';
    const awayHtml = gameData['away'] ? team(gameData['away']) : '';


    // const resultHtml1 = location(gameData['halftime'], gameData['fulltime'], gameData['extratime'] , gameData['goals']);

    //console.log(homeTeam.icon);


    const resultData = JSON.parse(gameData.result);

    const homeData = resultData.home;
    const awayData = resultData.away;

    const inningsKeys = Object.keys(homeData.innings);

    // const formatInnings = (innings) => {
    //     return Object.entries(innings)
    //         .map(([inning, value]) => ` ${value ?? "0"}`);

    // };

    //   const location = gameData.location && gameData.location !== "" ? JSON.parse(gameData.location) : {};
    // const locationCity = location.city && location.city !== "" ? location.city : "-";
    // const locationName = location.name && location.name !== "" ? location.name : "-";

    const location = gameData.location && gameData.location.trim() !== "" ? gameData.location: "-";
   const locationname = location.name && location.name !== null ? location.name : "-";



    const moreinfo = JSON.parse(gameData.more_info);
    const referee = moreinfo.referee && moreinfo.referee !== null ? moreinfo.referee : "-";

    const hometime = gameData.time;
    const utctime = LocalTime(hometime);
    // console.log("resultData", utctime);
    let defaultImage = '/bet-assets/site/image/baseball/baseball-default.svg';

    const homeTeamIcon = gameData.home ? gameData.home.icon : defaultImage;
    const awayTeamIcon = gameData.away ? gameData.away.icon : defaultImage;

    const homeProvd_id = gameData.home ? gameData.home.provd_id : '';
    const awayProvd_id = gameData.away ? gameData.away.provd_id : '';

    const homeTeam = gameData.home || {};
    const awayTeam = gameData.away || {};

    
  const league = gameData.league || {};
  const leagueName = league.display_name;
  const leagueLink = `/baseball/${league.name}/${league.id}`;

    const bgimage = homeTeam.icon ? homeTeam.icon : awayTeam.icon;

    const status = gameData.status;
    //  console.log("status", status);

    const homeName = homeTeam.display_name;
    const awayName = awayTeam.display_name;

    

  // location
  const venueID = gameData.venue_id ? gameData.venue_id : null;


    return (
        <>

            <Helmet>
                <title>{`${gameData.name} Game Summary`}</title>
                <meta name="description" content={`Catch up on the ${gameData.name} result, including score, summary, and post-match analysis. Hear from the coaches, players, and more.`} />
            </Helmet>

            <div className="game-container" key={gameData['id']} id="game-banner-top">
                <div className="breadcrumb">
                          <Link to="/baseball" className="breadcrumb__link">
                            Baseball
                          </Link>
                          <span className="breadcrumb__separator">{">"}</span>
                          <Link to={leagueLink} className="breadcrumb__link">
                            {leagueName}
                          </Link>
                          <span className="breadcrumb__separator">{">"}</span>
                          <h1 className="breadcrumb__current">{gameData.name}</h1>
                        </div>
                
                
                
                <div className="league-main-container bg-image-color">
                    {/* <div className="league-main-bg" style={{ backgroundImage: `url(${bgimage})` }}></div> */}
                    <div className="Next-match-container" >
                        <div className="Next-match-section-one"></div>
                        <div className="Next-match-section-two">
                            {homeHtml}
                            {resultHtml}
                            {awayHtml}
                        </div>
                        <div className="Next-match-section-one">
                            <div className="match-banner__details">
                              <div className="match-banner__detail-item">
                                <img src="/bet-assets/site/image/event.png" alt="Date" className="match-banner__detail-icon" />
                                <span>{utctime.date}</span>/<span>{utctime.time}</span>
                                
                              </div>
                            
                              <div className="match-banner__detail-item">
                                <Link to={leagueLink} className="detail-items">
                                  <img src="/bet-assets/site/image/trophy.png" alt="League" className="match-banner__detail-icon" />
                                  <span>{leagueName}</span>
                                </Link>
                                
                              </div>
                            
                              <div className="match-banner__detail-item">
                                {venueID ? (
                                  <Link to={`/baseball/venue/${venueID}`} className="detail-items">
                                  <img src="/bet-assets/site/image/venue.png" alt="Venue" className="match-banner__detail-icon" />
                                  <span>{locationname}</span>
                                  </Link>
                                ) : (
                                  <div className="detail-items">
                                  <img src="/bet-assets/site/image/venue.png" alt="Venue" className="match-banner__detail-icon" />
                                  <span>{locationname}</span>
                                  </div>
                                )}
                              </div>

                              <div className="match-banner__detail-item">
                                <img src="/bet-assets/site/image/referee.png" alt="referee_icon" className="match-banner__detail-icon" />
                                <span>{referee}</span>
                                
                              </div>


                            </div>

                        </div>
                    </div>
                </div>

                <div className="league-main-container-two ">

                    <div className="cards-section__card">
  <div className="cards-section__card-header">
    <img src="/bet-assets/site/image/goal_status.png" alt="Goal_status" />
    <div className="cards-section__card-title">Goal Stats</div>
  </div>

  <div className="cards-section__divider"></div>


    <div className="score-table-container">
      <table className="score-table">
        <thead>
          <tr>
            {inningsKeys.map((inning, index) => (
                <th key={index}>{inning}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          <tr>
            {inningsKeys.map((inning, index) => (
                <td key={index}>{homeData.innings[inning] ?? "0"}</td>
            ))}
          </tr>
          <tr>
            {inningsKeys.map((inning, index) => (
                <td key={index}>{awayData.innings[inning] ?? "0"}</td>
            ))}
          </tr>
        </tbody>
      </table>
    </div>


    
  </div>
                    </div>

                      
               
                    <Oddsdata id={id} status={status} />





                    <div className="game-status-row ">
                        
                    </div>

                </div>
           


            {/* <Lineups  homeTeamIcon={homeTeamIcon} id={id} awayTeamIcon={awayTeamIcon}/> */}

        </>
    );

    /**
     * generate result html
     * @param {Object} fullStatus 
     * @param {Object} result 
     *  @param {string|number} time 
     * @returns {JSX.Element} 
     */
    function result(fullStatus, result, time) {
        fullStatus = JSON.parse(fullStatus);
        result = JSON.parse(result);
        time = LocalTime(time);

        const parsedResult = result;

        // Extract home and away data
        const homeData = parsedResult.home;
        const awayData = parsedResult.away;
        // console.log("parsedResult", parsedResult);

        // // Extract home and away data

        // console.log("homeData 1", homeData);
        // console.log("awayData2", awayData);



        return (
            <div className="next-match-item">
                
                <h2 className="livedata-score">
                    {homeData.total !== null && awayData.total !== null ? (
                        <>
                            {homeData.total} <span className="livedata-score-arrow">-</span>{" "}
                            {awayData.total}
                        </>
                    ) : (
                        ""
                    )}
                </h2>
                <p className="matchscore">{fullStatus['long']}</p>
            </div>
        );
    }

    // function location(){

    //   return ( 

    //     <>

    //     </>
    //   );

    // }

    /**
     * generate team html
     * @param {Object} data 
     * @returns {JSX.Element} 
     */
    function team(data) {
        return (
            <div className="next-match-item">
                <div className="next-match-title">
                    <div className="match-image">
                        <img src={data['icon'] ? data['icon'] : defaultImage} className="small-images" alt={data['name']} width="70" height="70" onError={(e) => { e.target.src = defaultImage; }} loading="lazy" />
                    </div>
                    <h3 className="match-title">{data['display_name']}</h3>
                </div>
            </div>
        );
    }
}

export default GameScore;