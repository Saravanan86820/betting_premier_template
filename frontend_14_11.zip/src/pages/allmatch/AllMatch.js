import React from "react";

// import FeatureMatch from "../../sidebar/FeaturedMatch";
import Topleagues from "../../sidebar/Topleagues";
// import Alleagues from "../../sidebar/Alleagues";
import Add from "../../sidebar/Add";
import RecentBlog from "../../sidebar/RecentBlog";

import MatchPage from "../../pages/allmatch/MatchPage";

function AllMatch() {


  return (
    <>
      <div className="mvp-main-box-cont" id="more-blog-section">

        <div className="main-box-container">
          <div className="container-league-page">

            <div className="column-league large">

              <MatchPage />

            </div>

            <div className="column-league small">

              <div className="container-slide">
                {/* <FeatureMatch /> */}
                <Add />
                {/* <Alleagues/> */}
                <RecentBlog />
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

export default AllMatch;