import { useState, useEffect } from 'react';
import { getFromDB, setToDB } from '../../utility/DB';

/**
 * Custom React hook to get list of countries by Slug from API ("/api/widget/${endpoint}"),
 * with IndexedDB caching using the utility functions.
 * @param {string} dynamicSlug 
 * @returns 
 */
export default function useTopLeagueList(dynamicSlug) {
  const [leagueData1, setLeagueData1] = useState([]);   // State variable to hold league array
  const [loading, setLoading] = useState(true);    // For Loading State
  const [error, setError] = useState("");

  const endpoint = `top-leagues-${dynamicSlug}`
  const api = `/api/widget/${endpoint}`; //API endpoint for fetching Top league data by Slug
  const CACHE_KEY = `top_leagues_${dynamicSlug}`; // Key under which data is stored in IndexedDB

  useEffect(() => {
    let isMounted = true;  // Flag to prevent state updates after component unmount

    /**
     * Fetch countries code by slug from IndexedDB cache first.
     * If not present, fetch from API and cache the result.
     */
    async function fetchAndCache() {
      try {
        setLoading(true);


        // Try to retrieve cached countries from IndexedDB
        const cached = await getFromDB(CACHE_KEY);

        // If countries exist in cache and not empty, set to state
        if (cached && cached.length > 0) {
          if (isMounted) {
            setLeagueData1(cached);
            setLoading(false);
          }
        } else {
          // Not in cache: fetch from API, store in state and cache
          const resp = await fetch(api, { method: 'POST' });          // API fetch (GET method)
          const json = await resp.json();                            // Parse JSON response
          // console.log("toplegue",json);
          const data = json?.data || [];

          if (isMounted) {
            setLeagueData1(data);          // Set state with fetched data
            setLoading(false);
          }

        
          await setToDB(CACHE_KEY, data);       // Save fetched data to IndexedDB
        }

      } catch (error) {
        // Handle errors (IndexedDB or fetch failed): fallback to API fetch
        console.error("IndexedDB or fetch error:", error);

        if (isMounted) {
          setLeagueData1([]);
          setLoading(false);
        }
      }
    }

    
    // Begin fetch-and-cache logic on component mount/update
    fetchAndCache();

    // Cleanup function to prevent state updates after unmount
    return () => { isMounted = false };

  }, [api]);

  // At the end of your hook, before return
// console.log('Hook returning:', { countries, loading });

  return { leagueData1, loading };
}
