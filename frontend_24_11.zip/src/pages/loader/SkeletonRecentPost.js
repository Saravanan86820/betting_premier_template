import React from "react";
import "./Loader.css";

export default function SkeletonRecentPost() {
  return (
        <div className="news-skeleton">
        {[1, 2, 3, 4].map((i) => (
            <div className="news-skeleton-card" key={i}>
                <div className="skeleton-img"></div>
                <div className="skeleton-content">
                    <div className="skeleton-line line-sm"></div>
                    <div className="skeleton-line line-md"></div>
                    <div className="skeleton-line line-lg"></div>
                </div>
            </div>
        ))}
    </div>
  );
}
