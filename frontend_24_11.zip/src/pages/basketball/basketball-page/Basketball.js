import React from "react";
import '../../../index.css';
import { Helmet } from 'react-helmet';
import BasketballScorelist from "./BasketballScorelist";


import Topleagues from "../../../sidebar/Topleagues";
import Alleagues from "../../../sidebar/Alleagues";
import NewTopLeagues from "../../../sidebar/NewTopLeagues";
// import Add from "../../sidebar/Add";

function Basketball() {
  return (
    <>

      <Helmet>
        <title>Basketball News, Fixtures, Scores & Updates</title>
        <meta
          name="description" content=" Your one-stop destination for Basketball news, fixtures, Standings, scores, and updates. Get the latest from the world of Basketball, all in one place."
        />
      </Helmet>


      <div className="mvp-main-box-cont">
        <div className="container-scorelist container-betting-tools">
          <div className="container-score">

            <div className="column-score large">
              <div className="basketball-page-container" id="basketball-page">
                <BasketballScorelist />

              </div>
            </div>

            <div className="column-score small">

              <div className="container-slide">

                {/* <FeatureMatch /> */}
                <NewTopLeagues sports="basketball" />
                {/* <Add /> */}
                <Alleagues />

              </div>

            </div>
          </div>
        </div>
      </div>

    </>
  );

}

export default Basketball;