import React, { useEffect, useState , useRef} from 'react';
import { Link, useLocation } from 'react-router-dom'; // Import Link for routing if necessary
import './Navbar.css'; // Make sure to link to your CSS file

function Navbar() {

  const [showPopup, setShowPopup] = useState(false);
const [sidebarOpen, setSidebarOpen] = useState(false);
const location = useLocation();

  // Close sidebar when clicking outside (only on mobile)
  useEffect(() => {
    const handleClickOutside = (e) => {
      const sidebar = document.querySelector(".sidebar"); 
      const hamburger = document.querySelector(".mobile-hamburger");
      if (
        sidebarOpen &&  
        sidebar && hamburger &&
        !sidebar.contains(e.target) &&
        !hamburger.contains(e.target)
      ) {
        setSidebarOpen(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, [sidebarOpen]);

  // Add or remove open class from existing sidebar
  useEffect(() => {
    const sidebar = document.querySelector(".sidebar");
    if (sidebar) {
      if (sidebarOpen) {
        sidebar.classList.add("sidebar--open");
      } else {
        sidebar.classList.remove("sidebar--open");
      }
    }
  }, [sidebarOpen]);

   useEffect(() => {
    setSidebarOpen(false);
  }, [location]); //  whenever URL changes, close sidebar


  useEffect(() => {
  const popup = document.querySelector(".mobile-search-popup");
  const openBtn = document.querySelector(".mobile-search-icon");

  // Close when clicking outside
  const handleOutside = (e) => {
    if (showPopup && popup && !popup.contains(e.target) && !openBtn.contains(e.target)) {
      setShowPopup(false);
    }
  };

  // Close when screen becomes bigger than 865px
  const handleResize = () => {
    if (window.innerWidth > 865) {
      setShowPopup(false);
    }
  };

  document.addEventListener("mousedown", handleOutside);
  window.addEventListener("resize", handleResize);

  return () => {
    document.removeEventListener("mousedown", handleOutside);
    window.removeEventListener("resize", handleResize);
  };
}, [showPopup]);


 
  return (

    <>
      <header className="header">

          {/* Mobile Hamburger Icon */}
  <button
    className="ham-icon"
    onClick={() => setSidebarOpen(!sidebarOpen)} // optional if you have sidebar toggle
  >


    <img
      src="/bet-assets/site/image/hamburger.svg"
      alt="menu"
    />
  </button>


        {/* Logo */}
        <div className="header__img">
          <Link to="/">
            <img src="/bet-assets/site/image/common/logo.svg" alt="BettingPremier" width="150" height="50" loading="lazy" />
          </Link>
        </div>

      {/* Search */}
 {/* Search form (visible on desktop) */}
      <form
        role="search"
        method="get"
        action="/blog/"
        className="header__search-form desktop-search"
      >
        <div className="header__search">
          <img
            src="/bet-assets/site/image/common/search.svg"
            alt="search-icon"
            className="header__search-icon"
          />
          <input
            type="search"
            name="s"
            placeholder="Search..."
            className="header__search-input"
            required
          />
        </div>
      </form>

      

      {/* Popup for mobile search */}
      {showPopup && (
        <div className="mobile-search-popup">
          <div className="mobile-search-content">
            <form
              role="search"
              method="get"
              action="/blog/"
              className="mobile__search-form"
            >
              <img
                src="/bet-assets/site/image/common/search.svg"
                alt="search-icon"
                className="header__search-icon"
              />
              <input
                type="search"
                name="s"
                placeholder="Search..."
                className="header__search-input"
                autoFocus
                
              />
              <button
                type="button"
                className="close-btn"
                onClick={() => setShowPopup(false)}
              >
                ✕
              </button>
            </form>
          </div>
        </div>
      )}

      {/* Settings & Icons */}
      <div className="header__settings">

        {/* Mobile icon (click to open popup) */}
      <button
        className="mobile-search-icon"
        onClick={() => setShowPopup(true)}
      >
        <img
          src="/bet-assets/site/image/common/search.svg"
          alt="search"
          
        />
      </button>
        <a href="/blog/">
          <div className="header__items header__items--latest">
            <img src="/bet-assets/site/image/common/latest_new.svg" alt="latest" />
            
              <div className="header__tooltip">Blog</div>
          </div>
        </a>

        {/* <a href="#">
          <div className="header__items header__items--setting">
            <img src="/bet-assets/site/image/common/setting.svg" alt="setting" />
          </div>
        </a>

        <div className="header__dark-mode-toggle">
          <img src="/bet-assets/site/image/common/dark-mode-toggle.svg" alt="dark-mode-toggle" />
        </div> */}
      </div>
    </header>

    {sidebarOpen && <div className="sidebar-overlay" onClick={() => setSidebarOpen(false)}></div>}

    </>
  );

}


export default Navbar;


