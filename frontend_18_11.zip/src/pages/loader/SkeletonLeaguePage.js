import React from "react";
import "./Loader.css";

export default function SkeletonLeaguePage() {
  return (
    <div className="bet-skeleton-league-page bet-skeleton-wrap">

      {/* Header Section */}
      <div className="bet-header-skeleton">
        <div className="bet-skeleton-logo skeleton-logo"></div>

        <div className="bet-header-text">
          <div className="skeleton-line bet-skeleton-line bet-title"></div>
          <div className="skeleton-line bet-skeleton-line bet-country"></div>

          <div className="skeleton-line bet-skeleton-line bet-season"></div>
          <div className="skeleton-progress bet-skeleton-line"></div>
        </div>
      </div>

      {/* <div className="bet-content"> */}

        {/* Game Section */}
        {/* <div className="bet-card-skeleton">
          <div className="bet-card-title bet-skeleton-line"></div>

          {[1, 2, 3, 4, 5].map((i) => (
            <div className="bet-game-row-skeleton" key={i}>
              <div className="bet-team">
                <div className="bet-team-logo bet-skeleton-logo"></div>
                <div className="bet-team-name bet-skeleton-line"></div>
              </div>

              <div className="bet-score bet-skeleton-line"></div>
            </div>
          ))}
        </div> */}

        {/* Standings Section */}
        {/* <div className="bet-card-skeleton">
          <div className="bet-card-title bet-skeleton-line"></div>

          {[1, 2, 3, 4, 5, 6, 7, 8].map((i) => (
            <div className="bet-standing-row-skeleton" key={i}>
              <div className="bet-row-circle bet-skeleton-logo"></div>
              <div className="bet-row-team-name bet-skeleton-line"></div>

              <div className="bet-row-small bet-skeleton-line"></div>
              <div className="bet-row-small bet-skeleton-line"></div>
              <div className="bet-row-small bet-skeleton-line"></div>

              <div className="bet-form-box bet-skeleton-line"></div>
            </div>
          ))}
        </div> */}

      {/* </div> */}

    </div>
  );
}
