import React, { useState, useEffect } from 'react';

import { useParams } from 'react-router-dom';

import HandballLeagueList from "./HandballLeagueList";
import HandballStandings from "./HandballStandings";
import HandballMatch from "./HandballMatch";


import Topleagues from "../../../sidebar/Topleagues";
import Alleagues from "../../../sidebar/Alleagues";
import Add from "../../../sidebar/Add";
import RecentBlog from "../../../sidebar/RecentBlog";


function HandballLeague() {



  return (
    <>


      <div className="mvp-main-box-cont" id="more-blog-section">

        <div className="main-box-container">
          <div className="container-score">

            <div className="column-score large">
              <HandballLeagueList />
              <HandballStandings />
              <HandballMatch />

            </div>

            <div className="column-score small">

              <div className="container-slide">

                <Topleagues />
                <Add />
                <Alleagues />
                <RecentBlog />
              </div>
            </div>
          </div>
        </div>

      </div>
    </>
  );
}

export default HandballLeague;