import React, { useEffect, useState } from 'react';
import '../../index.css';
import { Link } from 'react-router-dom';
import LocalTime from "../../utility/LocalTime";

export default function Livescore() {
  const [livescore, setLivescore] = useState([]); // State to hold live scores
  const [loading, setLoading] = useState(true); // State for loading status
  const [error, setError] = useState(null); // State for error handling
  const [gameMatch, setGameMatch] = useState({});

  const Gamelive = "/api/sports/football/game/live";

  useEffect(() => {
    fetch(Gamelive, { method: 'POST' })
      .then(response => response.json())
      .then(json => {
        //console.log('Fetched all Gamelive:', json);
        setLoading(false);
        setLivescore(json.data); // Set full country data (as object)
      })
      .catch(() => {
        setError('Error fetching Gamelive data');
        setLoading(false);
      });
  }, []);

  useEffect(() => {
    if (livescore && livescore.length > 0) {
      livescore.forEach(live => {
        if (!gameMatch[live.id]) {
          fetchGameDetails(live.id);
        }
      });
    }
  }, [livescore]);

  const fetchGameDetails = (liveid) => {
    const LeagueGame = `/api/sports/football/game/${liveid}`;
    //console.log("LeagueGameURL", LeagueGame);

    fetch(LeagueGame, { method: 'POST' })
      .then(response => response.json())
      .then(json => {
        if (json && json.data) {
          setGameMatch(prevState => ({
            ...prevState,
            [liveid]: json.data,
          }));
        } else {
          setError(`Game data not found for match ${liveid}`);
        }
      })
      .catch(() => setError(`Error fetching game data for match ${liveid}`));
  };

  if (loading) {
    return <div>Loading...</div>;
  }

  if (error) {
    return <div>Error: {error}</div>;
  }

  let defaultImage = '/bet-assets/site/image/defaulticon.svg';

  return (
    <div className="league-section-main">
      <div className="league-section-row">

        <div className="header-bg-slide">
          <div className="header-flex">
            <div className="country-images">


              <img
                src="/assets/image/live3.svg"
                alt="live"
                width="26"
                height="26"
                className="country-icon"
                loading="lazy"
              />
            </div>

            <div className="country-content">
              <Link to='/football/live'>
                <span className="country-name">

                </span>
                <h3 className="text-slide">
                  Live Game

                </h3>
              </Link>
            </div>
          </div>
        </div>


        {Object.keys(gameMatch).length > 0 ? (
          <div className="league-container">
            {Object.entries(gameMatch)
              .slice(0, 10) // Limit to the first 10 game matches
              .map(([liveid, match]) => {
                // Parse the full_status JSON string
                const fullStatus = JSON.parse(match.full_status);
                const resultData = JSON.parse(match.result);
                const now = Date.now();

                // Skip games older than 24 hours ago OR scheduled in the future
                if (match.time + 24 * 60 * 60 * 1000 < now || match.time > now)
                  return;

                const hometime = match.time;
                const utctime = LocalTime(hometime);

                const homeScore = resultData.goals && resultData.goals.home !== null ? resultData.goals.home :
                  resultData.fulltime.home !== null ? resultData.fulltime.home : '-';

                const awayScore = resultData.goals && resultData.goals.away !== null ? resultData.goals.away :
                  resultData.fulltime.away !== null ? resultData.fulltime.away : '-';

                let gameslugeurl = match['name'] ? match['name'].replace(/\s+/g, '-').replace(/-+/g, '-').toLowerCase() : "";

                return (

                  <Link to={`/football/game/${gameslugeurl}/${liveid}`} key={liveid} >
                    <div className="league-rows" data-id={liveid}>
                      <div className="league-rows-iteam-match1">
                        <div className="league-rows-iteam-time">
                          <div className="match-date">
                            <span className="live-date">{utctime}</span>
                          </div>
                          <div className="match-status">{fullStatus.long}</div>
                        </div>
                      </div>
                      <div className="league-rows-iteam-match2">
                        <div className="league-match-data">
                          <div className="league-match-img">
                            <img
                              src={match.home.icon ? match.home.icon : defaultImage}
                              alt={match.home.display_name || 'league'}
                              className="league-live-img"
                              onError={(e) => { e.target.src = defaultImage; }}
                              loading="lazy"
                            />

                            <span>{match.home.display_name}</span>

                          </div>
                          <div className="league-match-score">

                            {homeScore}

                          </div>
                        </div>

                        <div className="league-match-data">
                          <div className="league-match-img">
                            <img
                              src={match.away.icon ? match.away.icon : defaultImage}
                              alt={match.away.display_name || 'league'}
                              className="league-live-img"
                              onError={(e) => { e.target.src = defaultImage; }}
                              loading="lazy"
                            />

                            <span>{match.away.display_name}</span>
                          </div>
                          <div className="league-match-score">
                            {awayScore}
                          </div>
                        </div>
                      </div>
                    </div>
                  </Link>
                );


              })}
          </div>
        ) : (
          <div className="live-games--score">No game matches available.</div>
        )}

      </div>

      {Object.keys(gameMatch).length > 8 && (
        <div className="blog-more-btn">
          <Link to='/football/live'>
            <button className="game-button">
              All Live Games <span className="svgspan"> </span>
            </button>
          </Link>
        </div>
      )}
    </div>
  );
}
