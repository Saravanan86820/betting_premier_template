import React, { useState, useEffect } from 'react';

import SkeletonLeagueStand from '../../loader/SkeletonLeagueStand';

function VolleyballStanding({ selectedSeason }) {

    const [standings, setStandings] = useState([]);
    const [selectedGroup, setSelectedGroup] = useState(''); // Default group is empty
    const [groupNames, setGroupNames] = useState([]); // To store unique group names
    const [isDropdownOpen, setIsDropdownOpen] = useState(false); // State to manage dropdown visibility

    const [matchSeason, setMatchseason] = useState(null);
    const [showStandings, setShowStandings] = useState(false);
    const [showdata, setShowData] = useState(null);

    
    const [loading, setLoading] = useState(false);

    useEffect(() => {
        if (selectedSeason) {
            
    setLoading(true); // Set loading state
            const AllMatchSeason = `/api/sports/volleyball/season/${selectedSeason.id}`; // Construct the URL with the selected season ID

            //  console.log('Current STMatchSeason:', AllMatchSeason);

            fetch(AllMatchSeason, { method: 'POST' }) // Assuming it's a POST request; adjust method if needed
                .then(response => response.json())
                .then(json => {
                    //console.log('API Response:', json);
                    if (json && json.data && json.data.length > 0) {
                        // Extracting the status value
                        const seasonData = json.data[0];
                        const status = seasonData.status;
                        //console.log('Season Status:', status);

                        // Parsing the coverage JSON
                        const coverage = JSON.parse(seasonData.coverage);
                        const standingsEnabled = coverage.standings; // Accessing the standings property
                        // console.log('Standings Enabled:', standingsEnabled);

                        setShowStandings(standingsEnabled);

                        setMatchseason(seasonData); // Store the entire season data
                        //console.log('Set match season data:', seasonData);
                    }
                    setLoading(false);
                })
                .catch(err => {
                    setLoading(false);
                    //console.error('Error fetching game data:', err);
                });
        }
    }, [selectedSeason]);


    useEffect(() => {
        if (!selectedSeason) {
            // Clear standings when no season is selected
            setShowStandings(false);
            setStandings([]);
            setGroupNames([]);
            setSelectedGroup('');

            return;
        }
        
    setLoading(true); // Set loading state

        const Allstandard = `/api/sports/volleyball/season/${selectedSeason.id}/statics/standings`;
            // console.log('Current Allstandard:', Allstandard);

        // Fetch standings data from the API
        fetch(Allstandard, { method: 'POST' })
            .then(response => response.json())
            .then(json => {

                if (json['status'] !== 'true') {
                    setShowStandings(false);
                    setLoading(false);
                    return;
                }
                // console.log('API Response:', json);
                const apiData = json.data;
                //  console.log('API Response:', apiData);
                if (!apiData || apiData.data === "" || apiData.data.length === 0) {
                    setShowStandings(false);
                    setShowData(null);  // Hide standings
                    setStandings([]); // Clear standings if no data
                    setGroupNames([]); // Clear group names
                    setSelectedGroup(''); // Clear selected group
                    setLoading(false);

                    //console.log("No valid standings data.");
                    return;
                }

                const parsedData = JSON.parse(apiData.data);
                //   console.log('Parsed Standings Data:', parsedData);

                if (!parsedData || parsedData.length === 0) {
                    setShowStandings(false);
                    setLoading(false);
                    return;
                }

                const standings = parsedData.length > 0 && parsedData;

                //  console.log("standings",standings);

                let allStandings = [];

                if (standings.length === 1) {
                    allStandings = standings[0]; // Use the first array
                    //   console.log("allStandings",allStandings);
                    setStandings(allStandings);
                    setGroupNames([]); // Clear group names
                    setSelectedGroup(''); // No selected group
                } else {
                    allStandings = standings.reduce((accumulator, currentArray) => accumulator.concat(currentArray), []);
                    const uniqueGroups = [...new Set(allStandings.map(team => team.group))];
                    //   console.log("uniqueGroups",uniqueGroups);
                    setGroupNames(uniqueGroups);
                    setSelectedGroup(uniqueGroups[0]);
                }

                setShowData(apiData);
                setStandings(allStandings);

                setShowStandings(true);
                setLoading(false);
            })
            .catch(error => {
                console.error('Error fetching standings:', error);
                setShowStandings(false); // Hide standings if there's an error
                setLoading(false);
            });
    }, [selectedSeason]);

    // Filter standings by selected group if group names exist
    const filteredStandings = groupNames.length > 0
        ? standings.filter(team => team.group === selectedGroup)
        : standings; // If no groups, just show all standings
    // console.log(filteredStandings);
    const handleGroupSelect = (group) => {
        setSelectedGroup(group);
        setIsDropdownOpen(false); // Close the dropdown after selection
    };

    let defaultImage = '/bet-assets/site/image/volleyball/volleyball.svg';

    if (!showdata) return null;

    return (
        <>
            {showStandings && (
                <div className="league-main-container"  id="league-standings-icehockey">
                    <div className="league-main-row">
                        <div className="league-center-title">
                            <div className="imageflex"><div className="league-heading-sub">
            <img src="/bet-assets/site/image/trophy1.png" alt="League" width="30" height="30" className="league-imageflex" loading="lazy" />
            <h4>Standings</h4>
           </div>
                                <div className="league-heading-divider"></div> 
                            </div>
                        </div>

                        <div className="league-main-tabel">
                            <div className="tabsection-container">
                                {loading && <SkeletonLeagueStand />}
                                <div>
                                    {groupNames && groupNames.length > 0 && ( // Only show dropdown if there are multiple groups
                                        <div className="custom-dropdown">
                                            <button onClick={() => setIsDropdownOpen(!isDropdownOpen)} className="dropdown-toggle">
                                                {/* {selectedGroup || 'Select Group'} */}
                                                {/* Show arrow based on dropdown state */}
                                                {selectedGroup?.name || 'Select Group'}
                                                {isDropdownOpen ? (
                                                    <span className="custom-dropdown-arrow">
                                                        <svg width="20px" height="20px" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                            <rect width="48" height="48" fill="white" fillOpacity="0.01" />
                                                            <path d="M13 30L25 18L37 30" stroke="#000000" strokeWidth="4" strokeLinecap="round" strokeLinejoin="round" />
                                                        </svg> </span>
                                                ) : (
                                                    <span className="custom-dropdown-arrow">
                                                        <svg width="20px" height="20px" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                            <rect width="48" height="48" fill="white" fillOpacity="0.01" />
                                                            <path d="M37 18L25 30L13 18" stroke="#000000" strokeWidth="4" strokeLinecap="round" strokeLinejoin="round" />
                                                        </svg>  </span>
                                                )}


                                            </button>
                                            {isDropdownOpen && (
                                                <div className="dropdown-menu">
                                                    {groupNames.map((group, index) => (
                                                        <div
                                                            key={index}
                                                            onClick={() => handleGroupSelect(group)}
                                                            className="dropdown-item"
                                                        >
                                                             {group.name}
                                                        </div>
                                                    ))}
                                                </div>
                                            )}
                                        </div>
                                    )}

                                    <div className="all-table-data">
                                        <div className="ptable">
                                            <table id="tablefull">
                                                <thead>
                                                    <tr className="col">
                                                        <th style={{ width: '2%' }}>#</th>
                                                        <th style={{ width: '58%' }}>Team</th>
                                                        <th>Played</th>
                                                        <th>Win</th>
                                                        <th>Loss</th>

                                                        <th>Points</th>
                                                        <th>Form</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    {filteredStandings.map((team, index) => (
                                                        <tr key={index} className="wpos">
                                                            <td>{index + 1}</td>
                                                            <td className="imagtile">
                                                                <img
                                                                    className="participant__image"
                                                                    alt={team.team?.display_name}
                                                                    src={team.team.icon ? team.team.icon : team.team.logo ? team.team.logo : defaultImage}
                                                                    width="15" height="15"
                                                                    onError={(e) => { e.target.src = defaultImage; }}
                                                                    loading="lazy"
                                                                />{' '}
                                                                <span className="standing_name">     {team.team && team.team?.display_name ? team.team?.display_name : team.team?.name} </span>
                                                            </td>
                                                            <td>  {team.games.played}</td>
                                                            <td>  {team.games.win.total}</td>
                                                            <td>  {team.games.lose.total}</td>
                                                            <td>  {team.points.for != null ? team.points.for : 0}</td>
                                                            <td>
                                                                {team.form ? (
                                                                    <div className="winsection">
                                                                        {team.form.split('').reverse().map((result, i) => (
                                                                            <span
                                                                                key={i}
                                                                                className={
                                                                                    result === 'W' ? 'win' :
                                                                                        result === 'L' ? 'lost' :
                                                                                            result === 'O' ? 'overtime' :
                                                                                                result === 'D' ? 'draw' : ''

                                                                                }
                                                                            >
                                                                                {result}
                                                                            </span>
                                                                        ))}
                                                                    </div>
                                                                ) : (
                                                                    <span>- </span> // Render an empty span if form is null
                                                                )}
                                                            </td>
                                                        </tr>
                                                    ))}
                                                </tbody>
                                            </table>
                                        </div>

                                        <div className="key-tabel">
                                            <div className="key-tabel-title">
                                                Key
                                            </div>
                                            <div className="key-tabel-list">
                                                <ol className="tabel-ul">
                                                    <li className="tabel-li">Win</li>
                                                    <li className="tabel-li">Loss</li>
                                                    <li className="tabel-li">Draw</li>

                                                </ol>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            )}


        </>
    );
}

export default VolleyballStanding;