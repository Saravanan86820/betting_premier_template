import React, { useState, useEffect } from 'react';
import './alleagues.css';
// import '../index.css';
import { useParams, Link } from 'react-router-dom';
import { useLocation } from "react-router-dom";
import useCountryList from '../components/country/useCountryList';

import Spinner from '../pages/loader/Spinner';
// import errcountry from '../../assets/image/imageapi/errcountry.svg';

const LeagueData = () => {
  // const { football } = useParams();
  const location = useLocation();
  const slug = location.pathname.split("/")[1];
  const dynamicSlug = slug || "football";

  const [countries, setCountries] = useState([]); // List of country codes
  const [leagues, setLeagues] = useState([]); // List of leagues for selected country
  const [selectedCountry, setSelectedCountry] = useState(null); // Currently selected country

  const [loading, setLoading] = useState(false);


  const AllcountryUrl = "/api/country";
  const countryUrl = `/api/sports/${dynamicSlug}/country`; // API to fetch country codes

  // console.log('Fetching countries from:', countryUrl);


  // get list of countries
  const countryList = useCountryList();


  // Fetch country codes on initial render
  useEffect(() => {
    fetch(countryUrl, { method: 'GET' })
      .then(response => response.json())
      .then(json => {
        //console.log('Fetched countries:', json);
        //setCountries(json.data); // Assuming 'json.data' contains the list of country codes
        if (json.data && json.data.length > 0) {
          //  console.log('Fetched countries:', json.data);
          setCountries(json.data); // Assuming 'json.data' contains the list of country codes
        } else {
          console.log('No countries found or data is empty.');
        }
      })
      .catch(error => console.error('Error fetching countries:', error));
  }, []);

  // Handle country click and fetch leagues
  const handleCountryClick = (countryCode) => {
    // If the clicked country is already selected, collapse it
    if (selectedCountry === countryCode) {
      setSelectedCountry(null); // Collapse if clicked again

    } else {
      setSelectedCountry(countryCode); // Expand this country

      setLeagues([]);   // Clear the previous leagues data immediately
      setLoading(true); // Start loading


      const leagueUrl = `/api/sports/${dynamicSlug}/country/${countryCode}/league`; // Dynamic URL for leagues
      //  console.log(leagueUrl);
      // Fetch league data for the selected country
      
      fetch(leagueUrl, { method: 'GET' })
        .then(response => response.json())
        .then(json => {
          // console.log(`Fetched leagues for ${countryCode}:`, json);

          setLeagues(json.data);   // Assuming 'json.data' contains the list of leagues
          setLoading(false);
        })
        .catch(error => {
          console.error('Error fetching leagues:', error);
          setLoading(false); // Stop loading on error
        });
      // .catch(error => console.error('Error fetching leagues:', error));
    }
  };

  // Convert the countryList object to an array of country data
  const allCountryData = countryList ? Object.values(countryList) : [];

  



  return (
    <div class="leagues-container">
      <div class="leagues-container__title">
          <h2>All Leagues</h2>
          <div class="leagues-container__divider"></div>
      </div>
      

      <div className="match-content-league">
        {countries.map((country, index) => {
          // Find the matching country in the allCountryData
          const matchingCountry = allCountryData.find(item => item.code === country);
          const matchDisplayName = matchingCountry?.display_name || "";
          // const matchDisplayName =  matchingCountry && matchingCountry["display_name"] ? matchingCountry['display_name'] : "";
          const matchCode = matchingCountry && matchingCountry["code"] ? matchingCountry["code"] : "";

          // If there's a matching country, display the display_name
          return matchingCountry ? (


            <div className="leagues-container__country" key={index} data-id-league={index}>
              <div
                onClick={() => handleCountryClick(country)}
                style={{ cursor: 'pointer' }} className="leagues-container__country-header"
              >
                <div className="leagues-container__country-info" data-id-country={matchingCountry.code}>

                    {matchingCountry && (
                      <img
                        src={`/bet-assets/site/image/country/${matchingCountry.code}.svg`}
                        alt={matchingCountry.display_name}
                        // width="20"
                        // height="20"
                        // className="country-icon"
                        loading="lazy"

                      />
                    )}
                  
                  <span>  {matchingCountry.display_name}</span>
                </div>
                {/* Change the symbol based on whether the country is selected */}
                <div className="leagues-container__toggle-icon">
                  {selectedCountry === country ? "−" : "+"}
                </div>
              </div>


              {selectedCountry === country && (
                <div className="leagues-container__league-list">

                  {loading ? (
                    <Spinner />
                    // <div className="no-leagues"> Loading...</div>
                  ) : leagues && leagues.length > 0 ? (
                    <ul>
                      {leagues.slice(0, 20).map((league, index) => {

                        const leagueurl = league["display_name"] ? league["display_name"].replace(/[^\w\s]/g, "").replace(/\//g, '-').replace(/\s+/g, "-").toLowerCase() : "";

                        const leagueid = league["id"] ? league["id"] : "";

                        const leagueslug = `${leagueurl}/${leagueid}`;

                        return (
                          <li key={index} className={`league-list__items ${dynamicSlug}`} >

                            
                            <Link to={`/${dynamicSlug}/${leagueslug}`}>
                              {league.display_name}
                            </Link>


                          </li>
                        );
                      })}

                      {leagues.length > 20 && (
                        <li className="league-list__items">
                          
                          <Link to={`/${dynamicSlug}/${matchCode}`}>All {matchDisplayName} </Link>
                        </li>
                      )}

                    </ul>
                  ) : (
                    <p className="no-leagues">No leagues available</p>
                  )}
                </div>
              )}
            </div>
          ) : null;
        })}
      </div>
    </div>
  );
};

export default LeagueData;
