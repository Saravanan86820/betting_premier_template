// src/components/Loader.js
import React from 'react';
import './Loader.css'; // Import the CSS file containing styles

const Loader = () => {

  // console.log("loading1");
  return (
    

    <div className="bet-page-loading">
      <div className="bet-page-loading-wrapper">
        <div>
          <img className="bet-page-loading__ball" src="/bet-assets/site/image/ball.svg" loading="lazy"/>
        </div>
        <img className="bet-page-loading__grass" src="/bet-assets/site/image/grass.png" loading="lazy"/>
      </div>
    </div>



  );
};

export default Loader;
