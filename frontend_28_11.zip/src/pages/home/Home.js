import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import '../../index.css';

import Blog from "../../post/blog/Blog";
// import Latest from "../../post/blog/Latest";
import About from "../../pages/about/About";
import Scorelist from "../../pages/home/Scorelist";
import Loader from "../../pages/loader/Loader";

function Home() {

  // const [loading, setLoading] = useState(true);


  // useEffect(() => {

  //   const timer = setTimeout(() => {
  //     setLoading(false);
  //   }, 1000); // 3000 milliseconds = 3 seconds


  //   return () => clearTimeout(timer);
  // }, []);

  // {loading ? (  <Loader /> ):();}

  return (
    <>
      <Helmet>
        <title>BettingPremier - Your Ultimate Sports and Betting Destination</title>
        <meta
          name="description" content="Stay ahead of the game with BettingPremier! Live sports scores, news, updates, and expert analysis. "
        />
      </Helmet>

      <div className="mvp-main-box-cont">
        <>
          <Scorelist />
          {/* <Latest /> */}
          <About />
          <Blog />
        </>
      </div >
    </>
  );
}

export default Home;
