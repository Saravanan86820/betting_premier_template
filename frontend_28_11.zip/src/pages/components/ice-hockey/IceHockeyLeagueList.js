import React, { useState, useEffect } from 'react';
import { useNavigate, useParams,Link, useLocation } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import useSportsList from '../../../components/content/useSportsList';
import SkeletonLeaguePage from '../../loader/SkeletonLeaguePage';


function IceHockeyLeagueList( { setSelectedSeason, selectedSeason }) {

   const { display_name, id, seasonYear } = useParams();
     const location = useLocation();
  const slug = location.pathname.split("/")[1];
      // console.log("seasonYear", seasonYear);
      const [league, setLeague] = useState(null);
      const [loading, setLoading] = useState(true);
      const [error, setError] = useState(null);
      const [season, setSeason] = useState([]);
      const [errormsg, setErrormsg] = useState(null);
      const [allcountries, setAllCountries] = useState({}); // Initialize as an object
      const navigate = useNavigate(); // Add the useNavigate hook
  
      const [matchSeason, setMatchseason] = useState(null);
  
  
      //  const defaultSeasonId = 75;
      // const [selectedSeason, setSelectedSeason] = useState(null);
  
      //   const defaultYear = 2024; // Default year set to 2024
  
      // const defaultYear = new Date().getFullYear();
  
      const AllcountryUrl = "/api/country";
  
      const AllLeagueUrl = `/api/sports/ice-hockey/league/${id}`;
      const AllSeason = `/api/sports/ice-hockey/league/${id}/season`;
  
      // console.log('Current AllSeason:', AllSeason);
  
  
      useEffect(() => {
          fetch(AllcountryUrl, { method: 'POST' })
              .then(response => response.json())
              .then(json => {
                  //console.log('Fetched all countries:', json);
                  setAllCountries(json.data); // Set full country data (as object)
              })
              .catch(error => console.error('Error fetching all countries:', error));
      }, []);
  
      // Fetch league data
      useEffect(() => {
          fetch(AllLeagueUrl, { method: 'POST' })
              .then((response) => response.json())
              .then((json) => {
                  if (json && json.data && Array.isArray(json.data) && json.data.length > 0) {
                      setLeague(json.data[0]);
                  } else {
                      setError('League not found');
                  }
                  setLoading(false);
              })
              .catch(() => {
                 // setError('Error fetching league data');
                  const errorMessage = `Error fetching league data`;
                  console.error(errorMessage);
  
                  setLoading(false);
              });
      }, [id]);
  
      // Fetch season data based on league ID
      useEffect(() => {
          setError(null);
          fetch(AllSeason, { method: 'POST' })
              .then((response) => {
                  if (!response.ok) {
                      throw new Error('Network response was not ok');
                  }
                  return response.json();
              })
              .then((json) => {
                  if (json && json.data && json.data.length > 0) {
                      // Sort the seasons in descending order by their `id` or another field
                      const sortedSeasons = json.data.sort((a, b) => parseInt(b.name) - parseInt(a.name)); 
                      setSeason(sortedSeasons);
                      // const defaultSeason = sortedSeasons.find(s => s.id === sortedSeasons[0]); // Default to season ID 13 or the first season  || sortedSeasons[0]
                      // setSelectedSeason(defaultSeason);
  
                      // const selectedSeasonFromURL = sortedSeasons.find(s => s.name === parseInt(seasonYear));
                      const selectedSeasonFromURL = sortedSeasons.find(s => s.status === 1);
                     
                      // Set the default season to the one found from URL, or fallback to the first one
                      const defaultSeason = selectedSeasonFromURL || sortedSeasons[0];
                      //console.log('defaultSeason:', defaultSeason);
                      setSelectedSeason(defaultSeason);
  
  
                      setLoading(false);
                  } else {
                      const noDataMessage = 'No season data found';
                      console.error(noDataMessage); // Log error to console
                     // setErrormsg(noDataMessage);
  
                  }
              })
              .catch(() => {
                 // setErrormsg('Error fetching season data');
                  const errorMessage = `Error fetching season data`;
                  console.error(errorMessage);
                  setLoading(false);
              });
      }, [id]);
  
      // Handle dropdown selection
      // const handleSeasonChange = (event) => {
      //     const selectedId = event.target.value;
      //     const selectedSeasonObj = season.find((item) => item.id === Number(selectedId));
      //     setSelectedSeason(selectedSeasonObj);
      //     console.log('Selected Season:', selectedSeasonObj);
      // };
  
      const handleSeasonChange = (e) => {
          const selectedId = e.target.value;
  
          if (selectedId === "") {
              // If default year is selected, handle it here
              setSelectedSeason(null); // Reset selection or handle it accordingly
          } else {
              const selectedSeason = season.find(s => s.id === parseInt(selectedId));
              setSelectedSeason(selectedSeason);
              navigate(`/ice-hockey/${display_name}/${id}/season/${selectedSeason.name}`);
          }
      };
  
      useEffect(() => {
          if (selectedSeason) {
              const AllMatchSeason = `/api/sports/ice-hockey/season/${selectedSeason.id}`; // Construct the URL with the selected season ID
  
              // console.log('Current AllMatchSeason:', AllMatchSeason);
  
              setLoading(true); // Optionally set loading state before starting the fetch
  
              fetch(AllMatchSeason, { method: 'POST' }) // Assuming it's a GET request; adjust method if needed
                  .then(response => response.json())
                  .then(json => {
                      //console.log('API Response:', json);
                      if (json && json.data && json.data.length > 0) {
                          setMatchseason(json.data[0]);// Store the entire game data
                          //console.log('Set match season data:', json.data[0]);
                      } else {
                          setError('Game not found');
                      }
                      setLoading(false); // Stop loading once data is fetched
                  })
                  .catch(err => {
                      console.error('Error fetching game data:', err);
                    //  setError('Error fetching game data');
                      setLoading(false); // Stop loading in case of an error
                  });
          }
      }, [selectedSeason]); // Trigger the effect when selectedSeason changes
  
  
      if (loading) {
          return <SkeletonLeaguePage />;
      }
  
      if (error) {
          return <div>{error}</div>;
      }
  
      if (!league) {
          return <div>No league data available.</div>;
      }
  
      if (errormsg) {
          return <div>{errormsg}</div>;
      }
  
      const allCountryData = allcountries ? Object.values(allcountries) : [];
  
      const matchingCountry = allCountryData.find(item => item.code === league.country_code);
  
      // Calculate the progress bar width based on year gap
      // const currentYear = new Date().getFullYear();
      // const totalYears = selectedSeason ? selectedSeason.end - selectedSeason.start : 1; // Assuming the selected season has year_start and year_end
      // const yearsPassed = Math.max(0, currentYear - selectedSeason?.start || 0); // Calculate years passed
      // const widthPercentage = (yearsPassed / totalYears) * 100;
  
      // console.log("widthPercentage", totalYears);
  
      let defaultImage = '/bet-assets/site/image/ice-hockey/hockey-default.svg';
  
      return (
          <>

            <Helmet>
                          <title>{`${league.display_name} Standings, Scores & Fixtures`}</title>
                          <meta name="description" content={`Get the latest ${league.display_name} standings, scores, and fixtures. Stay ahead of the game with in-depth analysis, team stats, and player profiles.`} />
                      </Helmet>
  
         <div className="breadcrumb">
                <Link to={`/${slug}`} className="breadcrumb__link">
                  {useSportsList(slug)}
                </Link>
                <span className="breadcrumb__separator">{">"}</span>
                <h1 className="breadcrumb__current">{league.display_name}</h1>
              </div>
              <div className="league-main-container  bg-image-color" data-color="blue" id="league-banner-top"> 
                  <div className="league-main-bg" style={{ backgroundImage: `url(${league.icon})` }}></div>
                  <div className="league-main-row" data-is-league={id}>
                      <div className="league-main-images">
                          <div className="league-main-imageslist">
                              <img
                                  src={league.icon ? league.icon : defaultImage}
                                  alt={league.display_name || 'league-banner'}
                                  className="league-images-nav"
                                  onError={(e) => { e.target.src = defaultImage; }}
                                  loading="lazy"  width="100" height="100"
                              />
  
                          </div>
                          <div className="league-content-list">
                              <h2 className="league-heading">{league.display_name}    </h2>
                              {/* {selectedSeason ? ` ${selectedSeason.name}` : ''} */}
                              <div className="country-image mtb">
                                  <div className="country-image-span">
                                      <span>
                                          {league && (
                                              <img
                                                  src={`/bet-assets/site/image/country/${league.country_code}.svg`}
                                                  alt={league.country_code}
                                                  width="26"
                                                  height="26"
                                                  className="league-images-sub"
                                                  loading="lazy"
                                              />
                                          )}
                                          <span className="country_name"> {matchingCountry ? matchingCountry.display_name : league.country_code}</span>  
                                      </span>
                                  </div>
  
                                  <div className="select-dropdown">
  
  
                                      <select className='custom-select' onChange={handleSeasonChange} value={selectedSeason ? selectedSeason.id : ''}>
  
                                          {season.map((item) => (
                                              <option key={item.id} value={item.id}>
                                                  {item.name}
                                              </option>
                                          ))}
                                      </select>
                                  </div>
  
                              </div>
{/* 
                              && matchSeason.status === "1" */}
  
                              {matchSeason  && (
  
  
  
                                  // <div className="Box kUjBME">
                                  //     <div className="Box cezFoR sc-8d2eba24-0 bJmhQv" ></div>
                                  // </div>
  
                                  <div>
  
                                      {(() => {
  
                                          const startDatemonth = matchSeason.start
                                              ? new Date(matchSeason.start)
                                              : null;
                                          const endDatemonth = matchSeason.end
                                              ? new Date(matchSeason.end)
                                              : null;
  
                                          const formattedStartDate = startDatemonth
                                              ? startDatemonth.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })
                                              : 'N/A';
                                          const formattedEndDate = endDatemonth
                                              ? endDatemonth.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })
                                              : 'N/A';
  
                                          // Calculate the gap in days
  
                                          const start_tday = startDatemonth.getTime();
                                          const end_tday = endDatemonth.getTime();
                                          let dateGap = 'N/A';
                                          if (startDatemonth  && endDatemonth) {
                                           
                                              const timeDifference = end_tday - start_tday;
                                              //  dateGap = Math.ceil(timeDifference / (1000 * 60 * 60 * 24)); // Convert to days
                                              dateGap = timeDifference;
                                          }
  
                                          const startday = startDatemonth.getTime();
                                          const currentDate = new Date().getTime();
                                         
  
                                          const timeDiff = currentDate - startday;
                                          const progressPercentage = (timeDiff / dateGap) * 100;
  
                                          //console.log("timeDifference", timeDiff);
                                          //     console.log(`Start Date: ${formattedStartDate}`);
                                      //     console.log(`End Date: ${formattedEndDate}`);
                                      //     console.log(`Gap Days: ${dateGap}`);
                                      //     console.log(`Date startDatemonth: ${startDatemonth}`);
                                      //    console.log(`GstartDatemonths: ${startday}`);
                                      //    console.log(`Gap in currentday: ${currentDate}`);
                                      //   console.log(`Gap progressPercentage: ${progressPercentage}`);
                                          // const totalDays = endDatemonth && startDatemonth ? Math.ceil((endDatemonth - startDatemonth) / (1000 * 60 * 60 * 24)) : 1; // Avoid division by zero
                                          // const progressPercentage = totalDays ? (dateGap / totalDays) * 100 : 0;
                                          // console.log(`Gap: ${progressPercentage}`);
  
                                          return (
                                              <>
                                                  <div>
                                                      <div className="Box progress-match">
                                                          <div className="Box cezFoR sc-8d2eba24-0 progress-match--value" style={{ width: `${progressPercentage}%` }} ></div>
                                                      </div>
                                                      <div className="percentage-value">
                                                          <div className="percentage--value-date">
                                                              {formattedStartDate}
                                                          </div>
                                                          <div className="percentage--value-date">
                                                              {formattedEndDate}
                                                          </div>
                                                      </div>
  
                                                  </div>
  
                                              </>
                                          );
                                      })()}
                                  </div>
  
                              )}
                          </div>
                      </div>
                  </div>
              </div>
          </>
      );
}

export default IceHockeyLeagueList;