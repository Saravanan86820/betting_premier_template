import React, { useState, useEffect } from 'react';

function Lineupdata() {

    const [teams, setTeams] = useState([]);

    useEffect(() => {
        // Simulated API response
        const response = [
            {
                team: {
                    id: 50,
                    name: "Manchester City",
                    logo: "https://media.api-sports.io/football/teams/50.png",
                    colors: {
                        player: {
                            primary: "5badff",
                            number: "ffffff",
                            border: "99ff99",
                        },
                        goalkeeper: {
                            primary: "99ff99",
                            number: "000000",
                            border: "99ff99",
                        },
                    },
                },
                formation: "4-3-1-2",
                startXI: [

                    {
                        player: {
                            id: 618,
                            name: "Kyle Walker",
                            number: 31,
                            pos: "G",
                            grid: "1:1",
                        },
                    },
                    {
                        player: {
                            id: 619,
                            name: "John Stones",
                            number: 31,
                            pos: "G",
                            grid: "1:1",
                        },
                    },
                    {
                        player: {
                            id: 620,
                            name: "Oleksandr Zinchenko",
                            number: 31,
                            pos: "G",
                            grid: "1:1",
                        },
                    },

                    {
                        player: {
                            id: 18755,
                            name: "João Virgínia",
                            number: 31,
                            pos: "G",
                            grid: null,
                        },
                    },
                   
                   
                ],

                substitutes: [
                    {
                        player: {
                            id: 18755,
                            name: "João Virgínia",
                            number: 31,
                            pos: "G",
                            grid: null,
                        },
                    },
                    {
                        player: {
                            id: 618,
                            name: "Kyle Walker",
                            number: 31,
                            pos: "G",
                            grid: "1:1",
                        },
                    },
                    {
                        player: {
                            id: 619,
                            name: "John Stones",
                            number: 31,
                            pos: "G",
                            grid: "1:1",
                        },
                    },
                    {
                        player: {
                            id: 620,
                            name: "Oleksandr Zinchenko",
                            number: 31,
                            pos: "G",
                            grid: "1:1",
                        },
                    },
                    // ... other substitutes
                ],

                coach: {
                    id: 4,
                    name: "Guardiola",
                    photo: "https://media.api-sports.io/football/coachs/4.png",
                },
            },
            {
                team: {
                    id: 45,
                    name: "Everton",
                    logo: "https://media.api-sports.io/football/teams/45.png",
                    colors: {
                        player: {
                            primary: "070707",
                            number: "ffffff",
                            border: "66ff00",
                        },
                        goalkeeper: {
                            primary: "66ff00",
                            number: "000000",
                            border: "66ff00",
                        },
                    },
                },
                formation: "4-3-1-2",
                startXI: [

                    {
                        player: {
                            id: 719,
                            name: "Fernandinho",
                            number: 31,
                            pos: "G",
                            grid: "1:1",
                        },
                    },
                    {
                        player: {
                            id: 720,
                            name: "Oleksandr Zinchenko",
                            number: 31,
                            pos: "G",
                            grid: "1:1",
                        },
                    },

                    {
                        player: {
                            id: 18755,
                            name: "João Virgínia",
                            number: 31,
                            pos: "G",
                            grid: null,
                        },
                    },
                    {
                        player: {
                            id: 718,
                            name: "Kyle Walker",
                            number: 31,
                            pos: "G",
                            grid: "1:1",
                        },
                    },
                   
                    // ... other substitutes
                ],

                substitutes: [
                    {
                        player: {
                            id: 18755,
                            name: "João Virgínia",
                            number: 31,
                            pos: "G",
                            grid: null,
                        },
                    },
                    {
                        player: {
                            id: 718,
                            name: "Kyle Walker",
                            number: 31,
                            pos: "G",
                            grid: "1:1",
                        },
                    },
                    {
                        player: {
                            id: 719,
                            name: "John Stones",
                            number: 31,
                            pos: "G",
                            grid: "1:1",
                        },
                    },
                    {
                        player: {
                            id: 720,
                            name: "Oleksandr Zinchenko",
                            number: 31,
                            pos: "G",
                            grid: "1:1",
                        },
                    },
                    // ... other substitutes
                ],


                coach: {
                    id: 2407,
                    name: "C. Ancelotti",
                    photo: "https://media.api-sports.io/football/coachs/2407.png",
                },
            },
        ];

        // Simulating an API call
        setTeams(response);



        // console.log(response);

    }, []);


    return (
        <>
            <h2>data</h2>

            {teams && teams.length > 1 ? (
                <div>
                    {(() => {
                        const hometeam = teams[0];
                        const awayteam = teams[1];

                        return (
                            <>
                                <div key={hometeam.team.id}>
                                    <h3>Home Team</h3>
                                    <p>Coach: {hometeam.coach.name}</p>
                                    <p>Match Name: {hometeam.team.name}
                                        <img src={hometeam.team.logo} className="small-images" alt={`${hometeam.team.name}-logo`} width="24" height="24" />
                                    </p>

                                    <h4>Starting XI</h4>
                                    {/* Render starting XI players */}
                                    {hometeam.startXI && hometeam.startXI.length > 0 ? (
                                        hometeam.startXI.map((team, index) => (
                                            <p key={team.id || index} data-id={index}>
                                                {team.player.name} - {team.player.pos}
                                            </p>
                                        ))
                                    ) : (
                                        <p>No starting players</p>
                                    )}

                                    <h4>Substitutes</h4>
                                    {/* Map over substitutes array */}
                                    {hometeam.substitutes && hometeam.substitutes.length > 0 ? (
                                        hometeam.substitutes.map((sub, index) => (
                                            <p key={sub.player.id || index}>
                                                {sub.player.name} - {sub.player.pos} (#{sub.player.number})
                                            </p>
                                        ))
                                    ) : (
                                        <p>No substitutes</p>
                                    )}
                                </div>

                                <div key={awayteam.team.id}>
                                    <h3>Away Team</h3>
                                    <p>Coach: {awayteam.coach.name}</p>
                                    <p>Match Name: {awayteam.team.name}
                                        <img src={awayteam.team.logo} className="small-images" alt={`${awayteam.team.name}-logo`} width="24" height="24" />
                                    </p>

                                    <h4>Starting XI</h4>
                                    {/* Render starting XI players */}
                                    {awayteam.startXI && awayteam.startXI.length > 0 ? (
                                        awayteam.startXI.map((team, index) => (
                                            <p key={team.id || index}>
                                                {team.player.name} - {team.player.pos}
                                            </p>
                                        ))
                                    ) : (
                                        <p>No starting players</p>
                                    )}

                                    <h4>Substitutes</h4>
                                    {/* Map over substitutes array */}
                                    {awayteam.substitutes && awayteam.substitutes.length > 0 ? (
                                        awayteam.substitutes.map((sub, index) => (
                                            <p key={sub.player.id || index}>
                                                {sub.player.name} - {sub.player.pos} (#{sub.player.number})
                                            </p>
                                        ))
                                    ) : (
                                        <p>No substitutes</p>
                                    )}
                                </div>
                            </>
                        );
                    })()}
                </div>
            ) : (
                <div>No Data</div>
            )}



        </>
    );
}

export default Lineupdata;