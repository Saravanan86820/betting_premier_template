import React, { useState, useEffect } from 'react';
import '../../index.css';
import { useParams } from 'react-router-dom';


import Topleagues from "../../sidebar/Topleagues";
import Alleagues from "../../sidebar/Alleagues";
import Add from "../../sidebar/Add";
import RecentBlog from '../../post/blog/RecentBlog';
import Allmatch from "../../pages/country/Allmatch";

function Countrymatch() {

  const { code: matchCode } = useParams(); // Get matchCode from the URL


  return (

    <>
      <div className="mvp-main-box-cont">
        <div className="container-scorelist container-betting-tools">
          <div className="container-league-page">

            <div className="column-league large">
              <div className="country-page-container" id="country-page">
                <div>
                  <Allmatch matchCode={matchCode} />
                </div>
              </div>
            </div>

            <div className="column-league small">

              <div className="container-slide">

                {/* <FeatureMatch /> */}
                <Add />
                <RecentBlog />
                {/* <Topleagues /> */}
                {/* <Alleagues /> */}

              </div>

            </div>
          </div>
        </div>
      </div>
    </>
  );

}

export default Countrymatch;