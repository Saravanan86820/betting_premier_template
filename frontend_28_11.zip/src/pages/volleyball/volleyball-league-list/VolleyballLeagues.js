import React, { useState, useEffect } from 'react';

import { useParams } from 'react-router-dom';

import VolleyballLeagueList from "./VolleyballLeagueList";
import VolleyballStandings from "./VolleyballStandings";
import VolleyballMatch from "./VolleyballMatch";


import Topleagues from "../../../sidebar/Topleagues";
import Alleagues from "../../../sidebar/Alleagues";
import Add from "../../../sidebar/Add";
import RecentBlog from "../../../sidebar/RecentBlog";


function VolleyballLeagues() {



  return (
    <>


      <div className="mvp-main-box-cont" id="more-blog-section">

        <div className="main-box-container">
          <div className="container-score">

            <div className="column-score large">
              <VolleyballLeagueList />
              <VolleyballStandings />
              
              <VolleyballMatch />
            </div>

            <div className="column-score small">

              <div className="container-slide">

                <Topleagues />
                <Add />
                <Alleagues />
                <RecentBlog />
              </div>
            </div>
          </div>
        </div>

      </div>
    </>
  );
}

export default VolleyballLeagues;