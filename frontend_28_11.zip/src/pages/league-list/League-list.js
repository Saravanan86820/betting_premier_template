import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { useLocation } from "react-router-dom";

// import FeatureMatch from "../../sidebar/FeaturedMatch";
import Topleagues from "../../sidebar/Topleagues";
// import Alleagues from "../../sidebar/Alleagues";
import Add from "../../sidebar/Add";
import RecentBlog from "../../post/blog/RecentBlog";

import LeagueHeader from './LeagueHeader';
import LeagueStand from './LeagueStand';

//football
import Matches from "../components/football/Matches";
// import LeagueStanded from "../components/football/LeagueStanded";


// ice hockey
import IceHockeyMatches from "../../pages/components/ice-hockey/IceHockeyMatches";

// baseball code
import BaseBallMatches from "../../pages/components/baseball/BaseBallMatches";

// baseketball code
import BasketBallMatches from "../../pages/components/basketball/BasketBallMatches";

// volleyball code
import VolleyBallMatches from "../../pages/components/volleyball/VolleyBallMatches";

// handball code
import HandBallMatches from "../../pages/components/handball/HandBallMatches";

// rugby code
import RugbyMatches from "../../pages/components/rugby/RugbyMatches";


function Leaguelist() {

  const [selectedSeason, setSelectedSeason] = useState(null);
  const [activeTab, setActiveTab] = useState("matches");
  const [isMobile, setIsMobile] = useState(window.innerWidth <= 1200);
  const location = useLocation();
  // const slug = location.pathname.split("/").find((segment) => segment);

  const slug = location.pathname.split("/")[1];

  useEffect(() => {
    const handleResize = () => setIsMobile(window.innerWidth <= 1200);
    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, []);

  return (
    <>
      <div className="mvp-main-box-cont" id="more-blog-section">

        <div className="main-box-container">
          <div className="container-league-page">

            <div className="column-league large">

              {slug === "football" &&
                <>
                <LeagueHeader setSelectedSeason={setSelectedSeason} selectedSeason={selectedSeason}/>

                {/* --- Desktop Layout --- */}
                {!isMobile && (
                  <div className="container-league-detail">
                    <div className="column-league-detail small league_cont">
                      {selectedSeason && <Matches selectedSeason={selectedSeason} slug={slug} />}
                    </div>
                    <div className="column-league-detail large league_cont">
                      {selectedSeason && <LeagueStand selectedSeason={selectedSeason} slug={slug}/>}
                    </div>
                  </div>
                )}

                {/* --- Mobile Layout (Tab View) --- */}
                {isMobile && (
                  <div className="league-tabs">
                    <div className="league-tabs__header">
                
                
                      <div className="tab_buttons">
                        <button

                        className={`tab_button ${activeTab === "matches" ? "active" : ""}`}
                        onClick={() => setActiveTab("matches")}
                        >
                          <img src="/bet-assets/site/image/games/football.png" alt="League" width="20" height="20" className="league-imageflex" loading="lazy" />
                          
                          <span className="tab--name"> Game </span>
                        </button>
                        <button

                          className={`tab_button ${activeTab === "standings" ? "active" : ""}`}
                        onClick={() => setActiveTab("standings")}
                        >
                          <img src="/bet-assets/site/image/trophy1.png" alt="League" width="30" height="30" class="league-imageflex" loading="lazy"></img>
                          
                          <span className="tab--name"> Standings  </span>
                        </button>

                    </div>


                    </div>
                
                    <div className="league-tabs__content">
                      {activeTab === "matches" && selectedSeason && (
                        <Matches selectedSeason={selectedSeason} slug={slug} />
                      )}
                      {activeTab === "standings" && selectedSeason && (
                        <LeagueStand selectedSeason={selectedSeason} slug={slug}/>
                      )}
                    </div>
                  </div>
                )}
                </>

              }

              {slug === "ice-hockey" &&
                <>
                  <LeagueHeader setSelectedSeason={setSelectedSeason} selectedSeason={selectedSeason} />

                  {!isMobile && (
                    <div className='container-league-detail'>
                    <div className='column-league-detail small  league_cont'>
                      {selectedSeason && <IceHockeyMatches selectedSeason={selectedSeason} slug={slug} />}
                    </div>
                    <div className='column-league-detail large  league_cont'>
                      {selectedSeason && <LeagueStand selectedSeason={selectedSeason} slug={slug}/>}
                  </div>
                  </div>

                  )}

                  {isMobile && (
                  <div className="league-tabs">
                    <div className="league-tabs__header">
                
                
                      <div className="tab_buttons">
                        <button

                        className={`tab_button ${activeTab === "matches" ? "active" : ""}`}
                        onClick={() => setActiveTab("matches")}
                        >
                        <img src="/bet-assets/site/image/games/ice-hockey.png" alt="League" width="20" height="20" className="league-imageflex" loading="lazy" />
                          
                          <span className="tab--name"> Game </span>
                        </button>
                        <button

                          className={`tab_button ${activeTab === "standings" ? "active" : ""}`}
                        onClick={() => setActiveTab("standings")}
                        >
                        <img src="/bet-assets/site/image/trophy1.png" alt="League" width="30" height="30" class="league-imageflex" loading="lazy"></img>
                          
                          <span className="tab--name"> Standings  </span>
                        </button>

                    </div>


                    </div>
                
                    <div className="league-tabs__content">
                      {activeTab === "matches" && selectedSeason && (
                        <IceHockeyMatches selectedSeason={selectedSeason} slug={slug} />
                      )}
                      {activeTab === "standings" && selectedSeason && (
                        <LeagueStand selectedSeason={selectedSeason} slug={slug}/>
                      )}
                    </div>
                  </div>
                )}



                  
                </>
              }
              {slug === "baseball" &&
                <>
                  <LeagueHeader setSelectedSeason={setSelectedSeason} selectedSeason={selectedSeason} />

                  {!isMobile && (
                    <div className='container-league-detail'>
                    <div className='column-league-detail small  league_cont'>
                      {selectedSeason && <BaseBallMatches selectedSeason={selectedSeason} slug={slug} />}
                    </div>
                    <div className='column-league-detail large  league_cont'>
                      {selectedSeason && <LeagueStand selectedSeason={selectedSeason} slug={slug}/>}
                    </div>
                  </div>
                  )}

                  {isMobile && (
                  <div className="league-tabs">
                    <div className="league-tabs__header">
                
                
                      <div className="tab_buttons">
                        <button

                        className={`tab_button ${activeTab === "matches" ? "active" : ""}`}
                        onClick={() => setActiveTab("matches")}
                        >
                        <img src="/bet-assets/site/image/games/baseball.png" alt="League" width="20" height="20" className="league-imageflex" loading="lazy" />
                          
                          <span className="tab--name"> Game </span>
                        </button>
                        <button

                          className={`tab_button ${activeTab === "standings" ? "active" : ""}`}
                        onClick={() => setActiveTab("standings")}
                        >
                        <img src="/bet-assets/site/image/trophy1.png" alt="League" width="30" height="30" class="league-imageflex" loading="lazy"></img>
                          
                          <span className="tab--name"> Standings  </span>
                        </button>

                    </div>


                    </div>
                
                    <div className="league-tabs__content">
                      {activeTab === "matches" && selectedSeason && (
                        <BaseBallMatches selectedSeason={selectedSeason} slug={slug} />
                      )}
                      {activeTab === "standings" && selectedSeason && (
                        <LeagueStand selectedSeason={selectedSeason} slug={slug}/>
                      )}
                    </div>
                  </div>
                )}
                      
                </>
              }
              {slug === "basketball" &&
                <>
                  <LeagueHeader setSelectedSeason={setSelectedSeason} selectedSeason={selectedSeason} />


                  {!isMobile && (

                    <div className='container-league-detail'>
                    <div className='column-league-detail small  league_cont'>
                      {selectedSeason && <BasketBallMatches selectedSeason={selectedSeason} slug={slug} />}
                    </div>
                    <div className='column-league-detail large  league_cont'>
                      {selectedSeason && <LeagueStand selectedSeason={selectedSeason} slug={slug}/>}

                    </div>
                    </div>
                  )}

                  {isMobile && (
                  <div className="league-tabs">
                    <div className="league-tabs__header">
                
                
                      <div className="tab_buttons">
                        <button

                        className={`tab_button ${activeTab === "matches" ? "active" : ""}`}
                        onClick={() => setActiveTab("matches")}
                        >
                        <img src="/bet-assets/site/image/games/basketball.png" alt="League" width="20" height="20" className="league-imageflex" loading="lazy" />
                          
                          <span className="tab--name"> Game </span>
                        </button>
                        <button

                          className={`tab_button ${activeTab === "standings" ? "active" : ""}`}
                        onClick={() => setActiveTab("standings")}
                        >
                        <img src="/bet-assets/site/image/trophy1.png" alt="League" width="30" height="30" class="league-imageflex" loading="lazy"></img>
                          
                          <span className="tab--name"> Standings  </span>
                        </button>

                    </div>


                    </div>
                
                    <div className="league-tabs__content">
                      {activeTab === "matches" && selectedSeason && (
                        <BasketBallMatches selectedSeason={selectedSeason} slug={slug} />
                      )}
                      {activeTab === "standings" && selectedSeason && (
                        <LeagueStand selectedSeason={selectedSeason} slug={slug}/>
                      )}
                    </div>
                  </div>
                )}
                  

                </>
              }
              {
                slug === "rugby" &&
                <>
                  <LeagueHeader setSelectedSeason={setSelectedSeason} selectedSeason={selectedSeason} />

                  {!isMobile && (
                    <div className='container-league-detail'>
                    <div className='column-league-detail small  league_cont'>
                      {selectedSeason && <RugbyMatches selectedSeason={selectedSeason} slug={slug} />}
                    </div>
                    <div className='column-league-detail large  league_cont'>
                      {selectedSeason && <LeagueStand selectedSeason={selectedSeason} slug={slug}/>}

                    </div>
                    </div>
                  )}

                  {isMobile && (
                  <div className="league-tabs">
                    <div className="league-tabs__header">
                
                
                      <div className="tab_buttons">
                        <button

                        className={`tab_button ${activeTab === "matches" ? "active" : ""}`}
                        onClick={() => setActiveTab("matches")}
                        ><img src="/bet-assets/site/image/games/rugby.png" alt="League" width="20" height="20" className="league-imageflex" loading="lazy" />
                          
                          <span className="tab--name"> Game </span>
                        </button>
                        <button

                          className={`tab_button ${activeTab === "standings" ? "active" : ""}`}
                        onClick={() => setActiveTab("standings")}
                        >
                        <img src="/bet-assets/site/image/trophy1.png" alt="League" width="30" height="30" class="league-imageflex" loading="lazy"></img>
                          
                          <span className="tab--name"> Standings  </span>
                        </button>

                    </div>


                    </div>
                
                    <div className="league-tabs__content">
                      {activeTab === "matches" && selectedSeason && (
                        <RugbyMatches selectedSeason={selectedSeason} slug={slug} />
                      )}
                      {activeTab === "standings" && selectedSeason && (
                        <LeagueStand selectedSeason={selectedSeason} slug={slug}/>
                      )}
                    </div>
                  </div>
                )}
                  
                </>
              }
              {
                slug === "volleyball" &&
                <>
                  <LeagueHeader setSelectedSeason={setSelectedSeason} selectedSeason={selectedSeason} />

                  {!isMobile && (
                    
                    <div className='container-league-detail'>
                    <div className='column-league-detail small  league_cont'>
                      {selectedSeason && <VolleyBallMatches selectedSeason={selectedSeason} slug={slug} />}
                    </div>
                    <div className='column-league-detail large  league_cont'>
                      {selectedSeason && <LeagueStand selectedSeason={selectedSeason} slug={slug}/>}

                    </div>
                    </div>
                  )}

                  {isMobile && (
                  <div className="league-tabs">
                    <div className="league-tabs__header">
                
                
                      <div className="tab_buttons">
                        <button

                        className={`tab_button ${activeTab === "matches" ? "active" : ""}`}
                        onClick={() => setActiveTab("matches")}
                        ><img src="/bet-assets/site/image/games/volleyball.png" alt="League" width="20" height="20" className="league-imageflex" loading="lazy" />
                          
                          <span className="tab--name"> Game </span>
                        </button>
                        <button

                          className={`tab_button ${activeTab === "standings" ? "active" : ""}`}
                        onClick={() => setActiveTab("standings")}
                        >
                        <img src="/bet-assets/site/image/trophy1.png" alt="League" width="30" height="30" class="league-imageflex" loading="lazy"></img>
                          
                          <span className="tab--name"> Standings  </span>
                        </button>

                    </div>


                    </div>
                
                    <div className="league-tabs__content">
                      {activeTab === "matches" && selectedSeason && (
                        <VolleyBallMatches selectedSeason={selectedSeason} slug={slug} />
                      )}
                      {activeTab === "standings" && selectedSeason && (
                        <LeagueStand selectedSeason={selectedSeason} slug={slug}/>
                      )}
                    </div>
                  </div>
                )}
                  
                </>
              }
              {
                slug === "handball" &&
                <>
                  <LeagueHeader setSelectedSeason={setSelectedSeason} selectedSeason={selectedSeason} />

                  {!isMobile && (
                    
                    <div className='container-league-detail'>
                    <div className='column-league-detail small  league_cont'>
                      {selectedSeason && <HandBallMatches selectedSeason={selectedSeason} slug={slug} />}
                    </div>
                    <div className='column-league-detail large  league_cont'>
                      {selectedSeason && <LeagueStand selectedSeason={selectedSeason} slug={slug}/>}

                    </div>
                    </div>
                  )}

                  {isMobile && (
                  <div className="league-tabs">
                    <div className="league-tabs__header">
                
                
                      <div className="tab_buttons">
                        <button

                        className={`tab_button ${activeTab === "matches" ? "active" : ""}`}
                        onClick={() => setActiveTab("matches")}
                        ><img src="/bet-assets/site/image/games/handball.png" alt="League" width="20" height="20" className="league-imageflex" loading="lazy" />
                          
                          <span className="tab--name"> Game </span>
                        </button>
                        <button

                          className={`tab_button ${activeTab === "standings" ? "active" : ""}`}
                        onClick={() => setActiveTab("standings")}
                        >
                        <img src="/bet-assets/site/image/trophy1.png" alt="League" width="30" height="30" class="league-imageflex" loading="lazy"></img>
                          
                          <span className="tab--name"> Standings  </span>
                        </button>

                    </div>


                    </div>
                
                    <div className="league-tabs__content">
                      {activeTab === "matches" && selectedSeason && (
                        <HandBallMatches selectedSeason={selectedSeason} slug={slug} />
                      )}
                      {activeTab === "standings" && selectedSeason && (
                        <LeagueStand selectedSeason={selectedSeason} slug={slug}/>
                      )}
                    </div>
                  </div>
                )}



                </>
              }
              



            </div>

            <div className="column-league small">

              <div className="container-slide">
                {/* <FeatureMatch /> */}
                <Add />
                <RecentBlog />
              </div>
            </div>
          </div>
        </div>

      </div>
    </>
  );
}

export default Leaguelist;