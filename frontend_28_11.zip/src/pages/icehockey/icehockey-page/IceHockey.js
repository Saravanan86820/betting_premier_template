import React from "react";
import '../../../index.css';
import { Helmet } from 'react-helmet';
import IceHockeyScorelist from "./IceHockeyScorelist";

// import ScoreLopp from "../../home/ScoreLopp";


import Topleagues from "../../../sidebar/Topleagues";
import Alleagues from "../../../sidebar/Alleagues";
import Add from "../../../sidebar/Add";

function IceHockey() {



  return (
    <>

      <Helmet>
        <title>Ice Hockey News, Fixtures, Scores & Updates</title>
        <meta
          name="description" content=" Your one-stop destination for Ice Hockey news, fixtures, Standings, scores, and updates. Get the latest from the world of Ice Hockey, all in one place."
        />
      </Helmet>

      <div className="mvp-main-box-cont">
        <div className="container-scorelist container-betting-tools">
          <div className="container-score">

            <div className="column-score large">
              <div className="basketball-page-container" id="basketball-page">
                <IceHockeyScorelist />


                {/* <ScoreLopp/> */}
              </div>
            </div>

            <div className="column-score small">

              <div className="container-slide">

                {/* <FeatureMatch /> */}
                <Topleagues />
                <Add />
                <Alleagues />

              </div>

            </div>
          </div>
        </div>
      </div>

    </>
  );

}

export default IceHockey;