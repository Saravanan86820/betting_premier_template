import { Link, useLocation } from "react-router-dom";
import React, { useState, useEffect, useMemo } from 'react';
import Topleagues from "../../sidebar/Topleagues";
import Alleagues from "../../sidebar/Alleagues";
import Add from "../../sidebar/Add";
import useCountryList from "../country/useCountryList";
import Meta from "../content/Meta";
import DateSelector from "../date-selector/DateSelector";
import PageContent from "../content/PageContent";
import SimpleCard from "../score/SimpleCard";
import './Sports.css';
import Tab from "../tab/Tab";
import SortGames from "./SortGames";
import LatestBlog from '../../post/blog/LatestBlog';
import Footballblog from '../../post/blog/Footballblog';
import LocalTime from "../../utility/LocalTime";

import SkeletonMatchCard from '../../pages/loader/SkeletonMatchCard';

/**
 * Main page for sports
 * @returns {JSX.Element}
 */
export default function Sports() {
  const location = useLocation();

  // get sports name from url
  const sportsName = location.pathname.split("/")[1];

  // page name 
  const pageName = sportsName;

  // today's date in yyyy-mm-dd format
  const today = new Date().toISOString().split('T')[0];

  // get timezone offset
  const timezoneOffset = new Date().getTimezoneOffset();

  // generate 15 days (7 previous, today, 7 next)
  const [selectedDate, setSelectedDate] = useState(today);
  const days = [];
  for (let i = -7; i <= 7; i++) {
    const d = new Date();
    d.setDate(d.getDate() + i);
    days.push(d.toISOString().split('T')[0]);
  }

  // schedule state - only for the football content
  const [schedule, setSchedule] = useState([]);
  const [scheduleLoading, setScheduleLoading] = useState(true); // Renamed to be more specific
  const [error, setError] = useState(null);

  // useMemo to prevent unnecessary recreations of api config
  const apiConfig = useMemo(() => {
    return {
      api: `/api/sports/${sportsName}/gamebydate`,
      sendData: { date: selectedDate, offset: timezoneOffset }
    };
  }, [sportsName, selectedDate, timezoneOffset]);

  // Search term in the sport page
  const [searchTerm, setSearchTerm] = useState("");

  // get schedule data from api
  useEffect(() => {
    setSchedule([]);
    setScheduleLoading(true);
    setError(null);

    // abort controller to cancel fetch if component unmounts
    const controller = new AbortController();
    const signal = controller.signal;

    fetch(apiConfig.api, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(apiConfig.sendData),
      signal,
    })
      .then(response => response.json())
      .then(respData => {
        if (respData.status !== 'true')
          throw new Error(respData.message);
        setSchedule(respData.data);
        setScheduleLoading(false);
      })
      .catch(error => {
        if (error.name === 'AbortError') return; // fetch aborted
        setError(error);
        setScheduleLoading(false);
      });

    // Cleanup function cancels fetch if params change or component unmounts
    return () => {
      controller.abort();
    };
  }, [apiConfig]); // Only depend on apiConfig

  const { gameList, leagueList, leagueOrder } = SortGames(schedule, {
    mode: 'scheduled',
    selectedDate // pass as 'YYYY-MM-DD'
  });

  // get list of countries
  const countryList = useCountryList();
  
  // Show full page loading only on initial load
  if (!countryList || Object.keys(countryList).length === 0)
    return <div>Loading...</div>;

  return (
    <>
      <Meta pageName={sportsName} />

      <div className="mvp-main-box-cont" data-page= {sportsName?.toLowerCase()}>
          <div className="container-match-page">

            <div className="column-match main">
              <div className="container-match">
                <div className="column-match large_column  league_cont">
              <div className="bet-page-top">


                {sportsName === "football" && (
                  <Tab items={
                    [
                      { name: "ALL", link: `/${sportsName}`, active: true },
                      { name: "LIVE", link: `/${sportsName}/live` }
                    ]
                  } />
                )}

                <div className="search-bar--allmatch">

                    <input
                      type="text"
                      placeholder="Search team, league, match..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="sports-search-input"
                    />
                  </div>

                <DateSelector
                  days={days}
                  selectedDate={selectedDate}
                  setSelectedDate={setSelectedDate}
                />
              </div>

             

              {/* Only the football content area shows loading/error states */}
              <div className="football-page-container" id="football-page">
                {scheduleLoading ? (
                  <SkeletonMatchCard />
                  // <div className="schedule-loading">Loading schedule for {sportsName}...</div>
                ) : error ? (
                  <div className="schedule-error">Error: {error.toString()}</div>
                ) : (
                  <div className="league-section-main" data-game={sportsName}>
                    {/* loop through league list */}
                    {leagueOrder.map(leagueId => {
                      const league = leagueList[leagueId];
                      const country = countryList[league.country_code] || null;
                      const leagueLink = `/${sportsName}/${league.name}/${leagueId}`;

                      let games = gameList[leagueId] || [];

                      if (searchTerm.trim() !== "") {
                        const term = searchTerm.toLowerCase();
                                            
                        games = games.filter(game => {
                          const home = (game.home.display_name  || "").toLowerCase();
                          const away = (game.away.display_name || "").toLowerCase();
                          const leagueName = (league.display_name || "").toLowerCase();
                          const status = (game.status || "").toLowerCase();
                          const localTime = game.time ? LocalTime(game.time) : '';
                          const matchTime = (localTime.time || "");

                          
                        
                          return (
                            home.includes(term) ||
                            away.includes(term) ||
                            leagueName.includes(term) ||
                            status.includes(term) ||
                            matchTime.includes(term)
                          );
                        });
                      }

                      if (games.length === 0) return null;

                      

                      return (
                        <div className="league-section-row" key={leagueId} data-id={leagueId}>
                          <div className="league-list__header">
                            
                              <div className="league-list__flag">
                                <img
                                  src={`/bet-assets/site/image/country/${league.country_code}.svg`}
                                  alt={country.display_name || league.country_code}
                                  width="20"
                                  height="20"
                                  // className="country-icon"
                                  loading="lazy" />
                              </div>
                              <div className="league-list__league-info">
                                <Link to={leagueLink}>
                                  <span className="league-list__country-name">{country.display_name || league.country_code}</span>
                                  <h3 className="league-list__league-title">{league.display_name}</h3>
                                </Link>
                              </div>
                            
                          </div>

                          <div className="league-container sport-loop" id="sport_data-loop">
                            {/* loop through games */}
                            {games.map(game => {
                              return (<SimpleCard key={game.id} sports={sportsName} game={game} />);
                            })}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>

               <PageContent pageName={pageName} />

                </div>
                <div className="column-match small_column">
                <Topleagues />
                <Alleagues />
                </div>
              </div>
            </div>

            <div className="column-match side">
              <div className="container-slide">
                <Add />
                <LatestBlog />
                {/* <Footballblog /> */}
              </div>
            </div>
             
          </div>
      </div >
    </>
  );
};