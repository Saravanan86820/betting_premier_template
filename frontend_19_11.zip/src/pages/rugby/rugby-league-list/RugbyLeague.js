import React, { useState, useEffect } from 'react';

import { useParams } from 'react-router-dom';

import RugbyLeagueList from "./RugbyLeagueList";
import RugbyStandings from "./RugbyStandings";
import RugbyMatch from "./RugbyMatch";


import Topleagues from "../../../sidebar/Topleagues";
import Alleagues from "../../../sidebar/Alleagues";
import Add from "../../../sidebar/Add";
import RecentBlog from "../../../sidebar/RecentBlog";
import NewTopLeagues from '../../../sidebar/NewTopLeagues';


function RugbyLeague() {



  return (
    <>
      <div className="mvp-main-box-cont" id="more-blog-section">

        <div className="main-box-container">
          <div className="container-score">

            <div className="column-score large">
              <RugbyLeagueList />
              <RugbyStandings />
              <RugbyMatch />

            </div>

            <div className="column-score small">

              <div className="container-slide">

                <NewTopLeagues sports="rugby" />
                <Add />
                <Alleagues />
                <RecentBlog />
              </div>
            </div>
          </div>
        </div>

      </div>
    </>
  );
}

export default RugbyLeague;