import React, { useState, useEffect } from "react";
import '../../../index.css';
import { useParams, Link } from 'react-router-dom';
import LocalTime from "../../../utility/LocalTime";
// import { useLocation } from "react-router-dom";


const useFetchMatches = () => {


    //  const location = useLocation();
    //  const slug = location.pathname.split("/")[1]; 
     const dynamicSlug = "volleyball";


    const [data, setData] = useState([]);
    const [matches, setMatches] = useState([]);
    const [gameMatch, setGameMatch] = useState({});
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const [seasonIds, setSeasonIds] = useState([]);
    const [currentSeasonIndex, setCurrentSeasonIndex] = useState(0);
    const [fetchingInProgress, setFetchingInProgress] = useState(false); // New state to prevent double-fetching

    // const slugToIdMap = {
    //     football: "league-football",
    //     "ice-hockey": "league-ice-hockey",
    //     basketball: "basketball", // Example: Add new mappings as needed
    // };

    const league = `/api/widget/league-volleyball`;


    useEffect(() => {
        fetch(league, { method: "POST" })
            .then((response) => response.json())
            .then((json) => {
                //console.log("API response:", json); // Debugging

                if (json.status === "true" && json.data) {

                    // const leagueName  = slugToIdMap[dynamicSlug];

                    const targetData = json.data.find((item) => item.name  === "league-volleyball");

                    if (targetData && targetData.data) {
                        const parsedData = JSON.parse(targetData.data);
                        setData(parsedData);

                        const ids = parsedData.map(season => season.season_id);
                        setSeasonIds(ids);

                        if (ids.length > 0) {
                            // Start by fetching data for the first season
                            setCurrentSeasonIndex(0);
                        }

                    } else {
                        setError("Invalid data format or missing data.");
                    }
                } else {
                    setError("API response error.");
                }
                setLoading(false);
            })
            .catch((err) => {
                console.error("Error fetching data:", err);
                setError("Error fetching data");
                setLoading(false);
            });
    }, [dynamicSlug]);

    useEffect(() => {
        if (seasonIds.length === 0 || currentSeasonIndex >= seasonIds.length || fetchingInProgress) return;

        const fetchMatches = async () => {
            setFetchingInProgress(true); // Set to true to prevent another fetch during this process

            const seasonId = seasonIds[currentSeasonIndex];
            const allSeasonUrl = `/api/sports/${dynamicSlug}/season/${seasonId}/game`;
         //   console.log("allSeasonUrl",allSeasonUrl);
            try {
                const response = await fetch(allSeasonUrl, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ type: 'recent' })
                });

                const respData = await response.json();

               // console.log("respData",respData);
                
             
                if (!respData || respData.status !== 'true' || !respData.data || respData.data.length === 0) {
                  //  console.log(` ${seasonId} due to empty or invalid data.`);
                    setCurrentSeasonIndex(prevIndex => prevIndex + 1); // Move to the next season
                    setFetchingInProgress(false); // Allow the next fetch
                   // setError("season data not found");
                    return;
                }
    
             
                const currentTimeUTC = Math.floor(new Date().getTime() / 1000);

                let scheduleData = respData.data;
                //  let scheduleData = respData['data'];

                // Filter and sort for past and upcoming matches
                const lastMatches = scheduleData
                    .filter(game => game.time < currentTimeUTC)
                    .sort((a, b) => b.time - a.time)
                    .slice(0, 3)
                    .reverse();

                let selectedMatches = scheduleData
                    .filter(game => game.time > currentTimeUTC)
                    .sort((a, b) => a.time - b.time)
                    .slice(0, 3);

                if (selectedMatches.length > 0) {
                    selectedMatches = [...lastMatches, ...selectedMatches];
                } else {
                    selectedMatches = lastMatches.concat(
                        scheduleData
                            .filter(game => game.time < currentTimeUTC)
                            .sort((a, b) => b.time - a.time)
                            .slice(0, 6 - selectedMatches.length)
                    );
                }
                // Append matches for this season to the existing matches
                setMatches(prevMatches => [...prevMatches, ...selectedMatches]);

                // Move to the next season in the list
                setCurrentSeasonIndex(prevIndex => prevIndex + 1);
            } catch (err) {
                console.error(`Error fetching matches for season ${seasonId}:`, err);
               
            } finally {
                setFetchingInProgress(false); // Allow the next fetch to proceed
                setLoading(false);
    
            }
        };

        fetchMatches();
    }, [seasonIds, currentSeasonIndex, fetchingInProgress]); // Include fetchingInProgress as a dependency

    useEffect(() => {
        if (matches && matches.length > 0) {
            matches.forEach(match => fetchGameDetails(match.id));
        }
    }, [matches]);

    const fetchGameDetails = (matchId) => {
        const LeagueGame = `/api/sports/${dynamicSlug}/game/${matchId}`;
        fetch(LeagueGame, { method: 'POST' })
            .then(response => response.json())
            .then(json => {
                if (json && json.data) {
                    setGameMatch(prevState => ({
                        ...prevState,
                        [matchId]: json.data
                    }));
                    setLoading(false);
                } else {
                    const errorMessage = `Game data not found for match ${matchId}`;
                    console.error(errorMessage);
                    //setError(errorMessage);
                }
            })
            .catch(() => {
                const errorMessage = `Error fetching game data for match ${matchId}`;
                console.error(errorMessage);
                // setError(errorMessage);
            });
    };

    return { data, matches, gameMatch, loading, error,dynamicSlug };
};

export default useFetchMatches;
