import React from "react";
import "./Loader.css";

export default function SkeletonMatchPage() {
  return (
    <div className="bet-skeleton-match-page">

      {/* Match Header */}
      <div className="bet-match-header">
        <div className="bet-team-logo bet-skeleton-logo"></div>
        <div className="bet-score-section">
          <div className="bet-skeleton-line bet-score"></div>
          <div className="bet-skeleton-line bet-match-status"></div>
        </div>
        <div className="bet-team-logo bet-skeleton-logo"></div>
      </div>

      {/* Match Info */}
      <div className="bet-match-info">
        <div className="bet-info-left">
          <div className="bet-skeleton-line bet-referee"></div>
          <div className="bet-goal-stats">
            <div className="bet-skeleton-line bet-stat"></div>
            <div className="bet-skeleton-line bet-stat"></div>
            <div className="bet-skeleton-line bet-stat"></div>
            <div className="bet-skeleton-line bet-stat"></div>
            <div className="bet-skeleton-line bet-stat"></div>
          </div>
        </div>

        {/* Timeline / Events */}
        <div className="bet-info-right">
          {[1,2,3,4,5,6,7].map((i) => (
            <div className="bet-event-row" key={i}>
              <div className="bet-timeline-dot"></div>
              <div className="bet-skeleton-line bet-event-detail"></div>
            </div>
          ))}
        </div>
      </div>

    </div>
  );
}
