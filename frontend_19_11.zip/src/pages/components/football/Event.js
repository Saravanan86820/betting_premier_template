import React, { useEffect, useState } from 'react';
import '../Components.css';

function Event({ id, homeProvd_id, awayProvd_id, homeName, awayName }) {

  const [event, setEvent] = useState(null);  // Defaulting to an empty array
  const [loading, setLoading] = useState(false);

  const eventAPI = `/api/sports/football/game/${id}/stats`;

  useEffect(() => {
    fetch(eventAPI, { method: 'POST' })
      .then(response => response.json())
      .then(respData => {

        let statsdata = null;

        if (respData['status'] !== 'true') {
          return;
        }

        if (typeof respData['data'] !== 'object' || Object.keys(respData['data']).length === 0) {
          return;
        }


        respData = respData['data'];
        for (const key in respData) {
          if (!Object.prototype.hasOwnProperty.call(respData, key)) continue;
          const item = respData[key];

          if (item['type'] !== 'events') continue;
          // console.log("eventAPI", item);
          statsdata = item;
          setLoading(true);
        }

       // console.log(typeof statsdata);
        const statisticdata = statsdata ? JSON.parse(statsdata.data) : null;
      //  console.log("eventAPI", statisticdata);

        //   console.log("API response:", json);
        // console.log("lineupdata", statsdata);

        setEvent(statisticdata);  // Update lineups state
        setLoading(false);
      })
      .catch(err => {
        // console.error('Error fetching lineups:', err);
        setLoading(false);
      });
  }, [id]);

  if (loading) {
    return <div>Loading statistics...</div>;
  }

  if (!event || Object.keys(event).length === 0) return null;


  // const homeEvents = event.filter((e) => e.team.id === Number(homeProvd_id));
  // const awayEvents = event.filter((e) => e.team.id === Number(awayProvd_id));

  // console.log("homeEvents", homeEvents);
  // console.log("awayEvents", awayEvents);


  return (
    <>
      <div className="event">
         {/* Teams */}
         <div className="event__teams">
          <div className="event__team event__team--home">
            {homeName}
          </div>
          <div className="event__team event__team--away">
            {awayName}
          </div>
         </div>


        <div className="event__timeline">
          {event.map((e, index) => (
            <div className="event__row" data-id={e.team.id === Number(homeProvd_id)} key={`event-${index}`} >

                {e.type === "subst" ? (
                  <div className="event__item">
                    <div className="event__icon">
                      <img src="/bet-assets/site/image/event/substute_icon.svg" alt="Substitution" />
                    </div>
                    <div className="event__details">
                      <div className="event__in">In: {e.player.name ? e.player.name : "-"}</div>
                      <div className="event__out">Out: {e.assist.name ? e.assist.name : "-"}</div>
                    </div>
                    <div className="event__time">{e.time.elapsed}'<span className='event_extra-time'> {e.time.extra ? `+${e.time.extra}` : ''} </span></div>

                  </div>


                ) : e.type === "Goal" ? (

                  <div className="event__item">
                    <div className="event__icon">
                      <img src="/bet-assets/site/image/event/goal.svg" alt="Goal Icon" />
                    </div>
                    <div className="event__details">
                      <div className="event__player">{e.player.name ? e.player.name : "-"}</div>
                      <div className="event__assist">{e.assist.name ? e.assist.name : "-"}</div>
                    </div>
                    <div className="event__time">{e.time.elapsed}'<span className='event_extra-time'> {e.time.extra ? `+${e.time.extra}` : ''} </span></div>

                  </div>

                ) : e.type === "Card" ? (

                  <div className="event__item">
                    <div className="event__icon">
                      <span className={e.detail}> </span>
                    </div>
                    <div className="event__details">
                      <div className="event__player"> {e.player.name} </div>
                      <div className="event__assist"> {e.detail} </div>
                    </div>
                    <div className="event__time">{e.time.elapsed}'<span className='event_extra-time'> {e.time.extra ? `+${e.time.extra}` : ''} </span></div>

                  </div>

                ) : null}



            </div>

          ))}





        </div>

      </div>
    </>
  );
}

export default Event;
